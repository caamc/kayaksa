# KSA Assistant

The KSA Assistant is the chat tab in the KSA Toolbar task pane. It reads what you have selected, answers in the KSA voice, and offers one-click actions that put the result back into the document: a chart, a table, a RAG scorecard, an exhibit slide, an action title, a summary or a reply. It never acts on its own; every action is a button you press.

## What it does in each host

| Host | Context it reads | Suggested prompts | Actions it can offer |
|---|---|---|---|
| Excel | The selected range (a single cell expands to its data region). Capped at 500 rows × 30 columns; larger selections are sampled and the model is told so. | Summarise this data · Chart this with one highlight · Find outliers · Build a RAG scorecard | **Insert chart** (native Excel chart styled to the KSA rules: one Saffron highlight, zero baseline, Fog gridlines, value labels; no pies) · **Insert table** (written below the selection, KSA header, Indian number grouping) · **Apply RAG colours** (conditional formats with thresholds, or Green/Amber/Red labels) |
| PowerPoint | The selected shapes' text and tables; if nothing is selected, every shape on the current slide. Needs PowerPointApi 1.5 for selection, 1.8 for table values. | Write an action title for this slide · Turn this table into an exhibit · Tighten this text | **Insert exhibit slide** (new slide after the current one: EXHIBIT eyebrow, insight headline, subtitle, Saffron accent, native table, source line) · **Set action title** (replaces the selected shape's text, or the slide title) |
| Word | The selected text; if nothing is selected, the first 2,000 characters of the document. | Summarise into three bullets · Write a standfirst · Draft an executive summary | **Insert summary / bullets / standfirst / heading** (KSA fonts: Archivo body, Source Serif 4 standfirst) · **Replace selection** |
| Outlook | The open message body (first 4,000 characters) and subject. | Draft a reply · Make this shorter | **Insert into message** (compose mode only) |
| KSA Hub (browser, Teams) | Nothing. | What can the assistant do? | **Copy text** |

Charts from data are built in Excel. In PowerPoint the exhibit action builds a native table and the headline; for a native chart, build it in Excel from the same rows and paste it onto the slide (the slide library's chart presets are styled the same way).

The context strip above the chat shows exactly what will be sent ("Selected range B2:F14, 13 rows"). **Refresh** re-reads the selection; untick **Include** to ask a question without sending any document content.

## Setup

1. Deploy the proxy: `server/cloudflare-worker/README.md` (five minutes, free plan) or `server/azure-function/README.md`.
2. In the task pane open **Settings** (cog, top right) and fill in **Assistant endpoint** (the proxy URL, without `/chat`) and, if you set one, the **Assistant access token**. Settings are stored in the browser's local storage on that device only.
3. Open the **KSA Assistant** tab. Without an endpoint the tab runs in **demo mode**: a setup card explains the steps and replies are canned, but the actions work so you can try the flow.

### Trying the UI without an API key

`node tools/mock-assistant.js` starts a dependency-free mock on `http://localhost:8787` that implements `/chat` and `/health` with canned answers and one sample action per host (it even does a small real summary of an Excel range). Set the endpoint to `http://localhost:8787` and test every host. The task pane itself must be served over HTTPS for Office, but a plain HTTP localhost proxy is fine for desktop development.

## Privacy and security

**What is sent.** Each request contains the conversation so far (at most 20 turns), the host name, your display name from Settings if you entered one, and the selection shown in the context strip:

- Excel: cell values of the selected range (max 500 × 30; sampled beyond that). Formulas, comments and hidden sheets are not sent.
- PowerPoint: text of the selected shapes (or of the current slide) and table cell text. No images.
- Word: the selected text, or the first 2,000 characters of the body if nothing is selected.
- Outlook: the subject and the first 4,000 characters of the message body as plain text. No attachments, no recipients.

Untick **Include** to send nothing but your question. Nothing is sent until you press Send; the assistant does not watch the document.

**Where it goes.** The add-in calls only the endpoint you configured. The proxy adds the KSA system prompt and forwards the request to the Anthropic Messages API (`api.anthropic.com`). Anthropic's API data handling applies to that call; by default API inputs and outputs are not used to train models. Check Anthropic's current commercial terms for retention details that apply to your account.

**Nothing is stored.** The proxy keeps no copy of requests or replies; it has no database and no cache. The Worker/Function logs only HTTP status codes and short error messages, never the API key, the token or the content. The conversation lives in the task pane's memory and is gone when the pane closes or you press **Clear**.

**The API key never leaves the proxy.** It is a Cloudflare secret or an Azure app setting. `/health` reports whether a key is configured, not its value.

**Restrict who can call the proxy.**
- `ALLOWED_ORIGINS`: set it to the exact origin(s) that serve the add-in (for example `https://toolbar.kayaksa.com`). Requests from any other origin get 403 and no CORS headers, so browsers block them.
- `ASSISTANT_TOKEN`: a shared secret. When set, the proxy rejects requests without a matching `Authorization: Bearer` header. Give the same value to users in Settings. Rotate it by changing the secret and telling users the new value.
- Both together are the recommended setting for firm use. For a per-user identity (Entra ID), put the Function behind Azure App Service authentication or Cloudflare Access; the add-in sends the token header as is.

**Rendering is safe by construction.** Replies are inserted into the pane as text nodes and the markdown-lite (bold, bullets, tables, code) is converted to DOM by the add-in itself; model output is never set as HTML. Actions are validated twice: the proxy whitelists action types and fields and caps sizes (200 × 30 cells, 20k characters), and the add-in checks the type against the current host before showing a button.

## Limits

- 20 conversation turns kept and sent; older turns drop off. Clear resets.
- Context caps: 500 × 30 cells (Excel), 2,000 characters of body text (Word, when nothing is selected), 4,000 characters (Outlook), 40 shapes (PowerPoint). The proxy additionally truncates the serialised context at 60k characters.
- Replies are capped at 2,000 output tokens (`max_tokens`), roughly 1,500 words. Ask for the next part if a long draft is cut.
- Upstream timeout 55 s at the proxy, 60 s in the add-in.
- Charts: the Excel action enforces the KSA rules (no pies, zero baseline, one highlight) and warns when a chart has more than 12 bars or 5 donut segments. Line and area charts take the first value column per series; dual axes are never created.
- PowerPoint tables need PowerPointApi 1.8 (Microsoft 365 current channel); older versions get a tab-separated text box instead. Word bullet styles need WordApi 1.3; older versions get "•" prefixes.
- The assistant does not read charts, images, comments, tracked changes, formulas or other sheets.

## Cost

The proxy is the only metered part. Each question sends the system prompt (about 1,200 tokens), the conversation and the context. A typical Excel question on a 100 × 6 range is roughly 3,000 to 4,000 input tokens and 300 to 600 output tokens; a full 500 × 30 range can reach 40,000 input tokens, which is why larger selections are sampled. The status bar at the bottom of the pane shows the token count of the last reply so users can see what a question cost.

Ways to keep cost down: select only the rows you need, untick Include for general questions, use Clear to drop old turns, and set `MODEL` to a smaller model for routine drafting. Cloudflare Workers' free plan covers the proxy itself for a small team; Azure Consumption pricing is similarly negligible next to the model calls. Current per-token prices for each model are on Anthropic's pricing page.

## Troubleshooting

| Message | Cause and fix |
|---|---|
| "Could not reach the assistant proxy" | Wrong endpoint, the proxy is down, or your origin is not in `ALLOWED_ORIGINS`. Open `<endpoint>/health` in a browser. |
| "The access token is missing or wrong" | `ASSISTANT_TOKEN` is set on the proxy; enter the same value in Settings. |
| "The proxy has no ANTHROPIC_API_KEY secret" | Run `wrangler secret put ANTHROPIC_API_KEY` (or set the app setting on Azure). |
| "The assistant is busy right now" | Rate limit at the model API; wait a few seconds. |
| Actions do not appear | The model did not return an actions block, or the action type was for another host. Ask explicitly ("chart this"). |
| "Select something in the document first" | The action needed a selection (range, shape, text) and found none. |
