# Changelog

All notable changes to KSA Toolbar. Versions follow semantic versioning; the XML manifests carry a fourth digit (`1.0.0.0`).

## 1.0.0 (2026-10-16)

First release.

### Added
- KSA ribbon tab in PowerPoint, Word and Excel (add-in only manifest with a shared runtime) and in Outlook message compose (separate manifest); unified manifest with the KSA Hub personal tab for Teams and Microsoft 365.
- Task pane with search, favourites and fourteen sections: logo and colour, icons (48 service icons in six versions), industry icons (2,160 across 45 sectors), shapes (25), smart diagrams (12), infographics (10), charts (12), patterns (11 x 6 colourways), effects (17 presets), layouts (14), report layouts (10), templates (9) and the KSA Assistant.
- Ribbon commands: Insert logo, Apply KSA style, Chart style (Excel), Insert signature (Outlook).
- Host modules for PowerPoint (SVG, PNG, slides from the slide library, shapes, templates), Word (SVG, PNG, OOXML blocks, tables, HTML, new documents), Excel (styled native charts, shapes, tables, RAG formats, new workbooks) and Outlook (signature, HTML templates, PNG), with capability fallbacks on every path.
- KSA Assistant: chat with Office context and one-click actions (chart, table, RAG, exhibit slide, action title, summary, standfirst, reply); proxy for Cloudflare Workers and Azure Functions; dependency-free mock server.
- Templates: corporate presentation (19 slides), service proposal (deck and document), thought-leadership report, report layouts sampler, slide library (68 slides), Excel charts workbook, email templates, Office theme; KSA fonts.
- Power BI pack: theme JSON with visual defaults, 96 icon PNGs, layout guide and reference page render.
- Tooling: `build-library.py`, `check-library.py`, `set-base-url.py`, `serve.js`, `package-release.sh`, `teams/build-package.py`, template generators.
- Documentation: README, DEPLOY, SIDELOAD, ARCHITECTURE, ASSISTANT, this changelog, and the browser preview page.

### Known limitations
- Smart diagrams are grouped shapes, not native SmartArt; layouts are slides, not slide masters.
- Charts in Word are PNG exhibits; native charts are built in Excel or inserted as slides in PowerPoint.
- Outlook is compose-only and inserts PNG rather than SVG; the signature slot needs Mailbox 1.10.
- The Teams tab (hub mode) browses and downloads but cannot insert.
- `manifest.json` targets the `devPreview` schema; set the GA version before a production upload.
