# KSA Toolbar

The Kayak Strategic Advisors brand toolbar for Microsoft Office. It adds a **KSA** tab to the ribbon in PowerPoint, Word, Excel and Outlook, a task pane that holds every KSA brand asset, and the **KSA Assistant**, a chat panel that reads your selection and puts charts, tables, slides and text back into the document. The same app is packaged for **Teams** as the KSA Hub tab, and Power BI gets a theme and icon pack of its own.

Version 1.0.0. Plain HTML, CSS and ES modules; no build step; served from any static HTTPS host.

## Folder map

| Folder | What is in it |
|---|---|
| `manifest/` | `manifest.xml` (Word, PowerPoint, Excel), `manifest-outlook.xml` (Outlook compose), `manifest.json` (unified manifest for Teams and Microsoft 365), `icons/` |
| `src/` | The app: `taskpane.html` (shell), `taskpane.js` (router), `commands.js` (ribbon commands), `modules/` (host modules, library, brand, assistant), `ui/` (tokens, glyphs), `preview.html` (browser demo) |
| `assets/` | The catalogue `library.json` and everything it points at: logo, icons, industry icons, shapes, diagrams, infographics, charts, patterns, effects, layouts, templates, fonts |
| `server/` | The KSA Assistant proxy as a Cloudflare Worker (`cloudflare-worker/`) or an Azure Function (`azure-function/`) |
| `powerbi/` | `KSA_PowerBI_Theme.json`, the icon pack, `KSA_PowerBI_Guide.md`, `report-layout.png` |
| `teams/` | `build-package.py` (zips the Teams app) and its README |
| `tools/` | `build-library.py`, `check-library.py`, `set-base-url.py`, `serve.js`, `package-release.sh`, `make-templates/` |
| `docs/` | This file, `DEPLOY.md`, `SIDELOAD.md`, `ARCHITECTURE.md`, `ASSISTANT.md`, `CHANGELOG.md`, `BRIEF.md` |

## Quick start

```bash
node tools/serve.js                      # https://localhost:3000 once a certificate exists (see the file header), else http
open https://localhost:3000/src/preview.html      # browse the library without Office
python3 tools/set-base-url.py https://localhost:3000   # point the manifests at the dev server, then sideload (docs/SIDELOAD.md)
```

For the firm: host the folder on a static site, set the base URL, upload the manifests in the Microsoft 365 admin centre (`docs/DEPLOY.md`).

## The ribbon

Every host gets a **KSA** tab.

| Group | PowerPoint | Word | Excel | Outlook (compose) |
|---|---|---|---|---|
| Brand | Insert logo · Apply KSA style · KSA Toolbar (opens the pane) | Insert logo · Apply KSA style · KSA Toolbar | Insert logo · Apply KSA style · Chart style · KSA Toolbar | Insert signature |
| Library | Icons · Shapes · Smart diagrams · Infographics · Charts · Patterns · Layouts · Templates | same, with Report layouts instead of Layouts | same as PowerPoint | Email templates |
| Assistant | KSA Assistant | KSA Assistant | KSA Assistant | KSA Assistant |

The Library and Assistant buttons switch the one shared task pane to that section (and open it when closed). In Teams and in a browser the pane runs in hub mode: everything browses, Copy SVG and Download replace Insert.

## What the client asked for, and where it is

| Asked for | Delivered as | PowerPoint | Word | Excel | Outlook |
|---|---|---|---|---|---|
| 1. Icons | 48 KSA service icons in six versions (duotone, reversed, line deep, line black, line white, badge) and 2,160 industry icons across 45 sectors | editable SVG at the selection | editable SVG inline | SVG shape at the cell | PNG in the message |
| 2. Infographics | 10 blocks (big numbers, KPI cards, icon and stat rows, stepped numbers, percentage bars, before and after, risk heat map, RAG scorecard, India regions map, stat gauge) as slides of grouped, editable shapes | inserted as a slide | preview and download | preview and download | no |
| 3. Smart diagrams | 12 diagrams (process chevrons, cycle, funnel, roadmap, swimlane journey, 2 x 2 matrix, Venn, hub and spoke, decision tree, maturity ladder, pyramid, org chart) as grouped shapes; every box, arrow and label is a native shape | inserted as a slide | download | download | no |
| 4. Shapes | 25 brand shapes (blades, stem, delta, chevron wake, rules, dividers, labels, six cluster badges, stamps, markers) as editable SVG, with slide versions where a slide is better | SVG or slide | SVG | SVG shape | PNG |
| 5. Charts | 12 chart exhibits (column with highlight, grouped, stacked, sorted bar, bullet, donut, waterfall, line with benchmark, multi-line, area, combo, small multiples) | native chart on a library slide | PNG exhibit | native chart built from the spec and styled | no |
| 6. Design and effects | Effects tab: Headline, Standfirst, Card, Dark card, Beacon, Table, Chart, KSA theme presets, shadows e1 to e3, blade crop mask, duotone overlay, pattern panel | applied to the selection; crop, duotone and pattern as slides | applied to the selection | applied to the range, table or chart | no |
| 7. Patterns | 11 patterns x 6 colourways as seamless SVG tiles and 1920 x 1080 PNGs | PNG background or SVG | PNG | PNG | PNG |
| 8. Layouts | 14 slide layouts (title light and dark, agenda, divider, action title and exhibit, two column, three columns, four cards, comparison, timeline, big number, quote, team, closing) | inserted after the current slide | no | no | no |
| 9. Report layouts | 10 Word blocks (cover, chapter opener, two-column text, exhibit frame, data table, callout, sidebar box, pull quote, key takeaways, back cover) as OOXML | no | inserted at the cursor | no | no |
| 10. Effects (one click) | Apply KSA style on the ribbon: fonts, colours, lines and fills for the selection; Chart style in Excel | yes | yes | yes | no |
| 11. Assistant | KSA Assistant chat with Office context and one-click actions (see `ASSISTANT.md`) | exhibit slide, action title | summary, standfirst, bullets, replace | chart, table, RAG colours | reply into the message |
| 12. Corporate presentation | `KSA_Corporate_Presentation.pptx`, 19 slides with speaker notes, plus `KSA_Office_Theme.thmx` | opens as a new deck or inserts all slides | no | no | no |
| 13. Service proposal | `KSA_Service_Proposal.pptx` (14 slides) and `KSA_Service_Proposal.docx` | new deck | new document | no | no |
| 14. Thought leadership | `KSA_Thought_Leadership.docx` with the report layouts; `KSA_Report_Layouts.docx` as a sampler | no | new document | no | no |

Plus: logo and colour tab (22 logo files, palette with copy-to-clipboard), `KSA_Excel_Charts.xlsx` (every chart preset as a native Excel chart with a RAG scorecard), `KSA_Email_Templates.html` (signature, The Kayak Brief, closing block), the KSA fonts in `assets/fonts`, and the Power BI pack.

## What is and is not possible

- **Smart diagrams are grouped shapes, not SmartArt.** Office.js cannot create or edit native SmartArt. The slide-library diagrams are ordinary shapes: ungroup, edit text, recolour, add a step. They are inserted as slides (PowerPointApi 1.2); on hosts without that API the pane offers a download of the slide library.
- **Native charts are built in Excel and inserted as slides in PowerPoint.** Office.js creates charts in Excel only. In PowerPoint the chart exhibits are slides from the library with real, editable charts; in Word they are PNG exhibits (copy the Excel chart for a live one).
- **Layouts are slides, not slide masters.** Office.js cannot add a master layout; the corporate deck and `KSA_Office_Theme.thmx` carry the master, the library slides carry the layouts.
- **Outlook is compose-only, HTML only.** SVG is not supported in mail bodies, so icons and shapes go in as PNG; the signature uses `setSignatureAsync` where Mailbox 1.10 exists and the cursor otherwise. Outlook has no shared runtime, so the Assistant button opens the pane rather than switching an open one.
- **Power BI has no add-in model.** The theme JSON, icon PNGs and layout guide give the same look; a packaged custom visual would be a separate project (`powerbi/KSA_PowerBI_Guide.md`, section 7).
- **Teams shows the library, not the inserts.** Office.js is not present in a Teams tab; the KSA Hub tab browses, copies and downloads.
- **Fonts.** Archivo and Source Serif 4 must be installed on each PC (`assets/fonts`); Office falls back to Arial and Georgia otherwise. The task pane loads Archivo from Google Fonts.
- **Capability tiers.** Every action checks the requirement set first and falls back one step (SVG to PNG, slide insert to download, createDocument to insertFile, signature slot to cursor). Older hosts get a toast, never an error dialog. `ARCHITECTURE.md` lists the tiers.
- **No telemetry, no accounts.** Settings and favourites live in the browser's local storage on that device. The Assistant sends the selection only when you press Send, only to the proxy you configured (`ASSISTANT.md`, privacy section).

## Requirements

- Microsoft 365 apps (current or monthly enterprise channel) on Windows or Mac, Office on the web, new Outlook and classic Outlook on Windows. Office 2019 and 2021 perpetual load the pane and most inserts but lack the shared runtime, slide insert and some Excel chart formatting; they get the fallbacks.
- A static HTTPS host for this folder and, for the Assistant, a Cloudflare or Azure account for the proxy.
- Admin: the Microsoft 365 admin centre to deploy to the firm; nothing else to install on PCs apart from the fonts.
