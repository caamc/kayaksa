# Deploying KSA Toolbar

Four steps: host the static files, set the base URL in the manifests, deploy the Assistant proxy, and upload the manifests in the Microsoft 365 admin centre. Nothing is installed on users' PCs; Office downloads the add-in from your host when the KSA tab is used.

## 1. Host the static files

The whole folder is a static site. Upload it as is (the add-in uses relative paths, so any origin and any path prefix work). Requirements: HTTPS with a certificate browsers trust, correct MIME types for `.svg`, `.json`, `.pptx`, `.docx`, `.xlsx`, `.xml` and `.woff2`, and no authentication on the files (Office fetches them without cookies).

**GitHub Pages**

1. Create a repository (private is fine for the repository, but Pages publishes publicly; use the organisation's Pages or a custom domain).
2. Push the folder. Settings > Pages > Source: Deploy from a branch, `main`, root.
3. Add a custom domain (`toolbar.kayaksa.com`) with a CNAME to `<org>.github.io` and tick **Enforce HTTPS**. Pages serves the right MIME types and sets long caches; after each release bump `version` in the manifests so Office refreshes.

**Azure Static Web Apps**

1. Create a Static Web App (Free plan), connect the repository or upload with the SWA CLI: `swa deploy ./ --app-location . --env production`.
2. Add `staticwebapp.config.json` at the root if you want cache headers; the defaults are fine. Custom domains get managed certificates.
3. Staging environments give you a preview URL per pull request; point a test manifest at it with `set-base-url.py`.

**Cloudflare Pages**

1. Pages > Create a project > Upload assets (or connect Git), build command empty, output directory `/`.
2. Add the custom domain. Cloudflare serves `.pptx` and friends with the right types. If you also run the Worker proxy, both live under one account.

Keep `.git`, `node_modules` and `tools/make-templates/.cache` out of the upload (`tools/package-release.sh` builds a clean zip of exactly what should be hosted).

Check: open `https://<base>/src/taskpane.html?hub=1` in a browser. The pane should load the library ("2,405 assets" in the status bar) and the previews should render.

## 2. Set the base URL

```bash
python3 tools/set-base-url.py https://toolbar.kayaksa.com
```

This rewrites every absolute URL in `manifest/manifest.xml`, `manifest-outlook.xml` and `manifest.json` (icons, task pane, commands, Teams tab, `validDomains`). Run it again whenever the host changes. The manifests ship with the placeholder `https://ksa-toolbar.kayaksa.com`.

Then build the Teams package: `python3 teams/build-package.py` writes `teams/KSA-Toolbar-teams-app.zip`.

## 3. Deploy the Assistant proxy

The Assistant needs a small proxy that holds the Anthropic API key. Follow `server/cloudflare-worker/README.md` (five minutes) or `server/azure-function/README.md`. Set `ALLOWED_ORIGINS` to the exact origin from step 1 and, for firm use, an `ASSISTANT_TOKEN`. Users enter the proxy URL and token once in the pane's Settings; `docs/ASSISTANT.md` has the privacy notes to share with them.

Without a proxy the add-in still works; the Assistant tab runs in demo mode.

## 4. Centralised deployment (Microsoft 365 admin centre)

This is the firm-wide path. It needs a Global admin or an Office Apps admin, and users on Microsoft 365 Apps.

1. Open the Microsoft 365 admin centre > **Settings > Integrated apps > Upload custom apps**.
2. **Word, PowerPoint, Excel:** App type **Office Add-in**, **Upload manifest file (.xml) from device**, choose `manifest/manifest.xml`. Next: assign to **Entire organisation** or a group (a pilot group first is sensible). Accept the permissions (ReadWriteDocument). Finish.
3. **Outlook:** repeat with `manifest/manifest-outlook.xml`. It has the same id, which is expected; the admin centre lists it as a second deployment of the same app.
4. **Teams and the unified manifest:** App type **Teams app**, upload `teams/KSA-Toolbar-teams-app.zip`. This deploys the KSA Hub tab to Teams and, in Microsoft 365 tenants where unified-manifest add-ins are enabled, also the Outlook and Office parts. Deploy either the two XML manifests or the Teams package, not both at once for the same users, unless you want to test them side by side (the unified manifest's `alternates` entry hides the XML add-in where both are installed; see the note below).
5. Wait. Outlook on the web and Teams pick the app up within minutes; Word, PowerPoint and Excel on the desktop within 24 hours (restart the app; File > Get Add-ins > Admin Managed shows it). Users see the KSA tab with no action on their side. The **KSA Toolbar** button in the Brand group opens the pane; the Library and Assistant buttons switch the open pane to a section (they open it first if it is closed).

Notes:

- Centralised deployment caches manifests. After changing a manifest, bump `<Version>` (XML) or `version` (JSON) and use **Integrated apps > KSA Toolbar > Update** with the new file. Changing only the hosted files (`src/`, `assets/`) needs no manifest update, but desktop Office may serve cached JS for a day; a query string in the `SourceLocation` (for example `taskpane.html?v=1.0.1`) forces a reload.
- Access to the hosted files is anonymous. Do not put anything confidential in `assets/`.
- If the tenant blocks user-uploaded add-ins, centralised deployment still works; it is the admin's channel.

## Outlook specifics

- Classic Outlook on Windows needs Mailbox 1.3 (any supported Office). The signature slot (`setSignatureAsync`) needs Mailbox 1.10 (Microsoft 365 Apps build 16.0.13229 or later); older builds insert the signature at the cursor.
- The KSA tab appears in a new message or reply. Outlook on the web and new Outlook ignore custom tabs and show the three buttons under **Apps** in the message toolbar; that is normal.
- Outlook on Mac shows the buttons on the default tab; custom tabs are not supported there.

## Teams package

`teams/README.md` covers the Teams admin centre route and sideloading. Before a production upload, change `manifestVersion` in `manifest/manifest.json` from `devPreview` to the current GA version that supports Office add-ins (`1.17` or later) and the `$schema` URL to match, then rebuild the zip and validate it in the Teams Developer Portal (**Apps > Import app**).

## Updating a release

1. Change the files; run `python3 tools/check-library.py` after touching `assets/`.
2. Bump the version in the three manifests (`1.0.1.0` in XML, `1.0.1` in JSON) and add a line to `docs/CHANGELOG.md`.
3. Publish the static files; rebuild the Teams zip; update the apps in Integrated apps if a manifest changed.
4. `tools/package-release.sh` produces `KSA_Toolbar_v<version>.zip` for the archive.

## Checklist before go-live

- [ ] `https://<base>/src/taskpane.html?hub=1` loads over HTTPS with no mixed-content warnings.
- [ ] `https://<base>/manifest/icons/icon-80.png` and `/assets/library.json` return 200 with the right content types.
- [ ] `set-base-url.py` run; `grep -c ksa-toolbar.kayaksa.com manifest/*` returns 0.
- [ ] Proxy `/health` returns `keyConfigured: true` and the origin is allowed.
- [ ] Sideload test in each host (`docs/SIDELOAD.md` checklist) passed on at least one Windows PC and one Mac.
- [ ] Fonts distributed (Archivo, Source Serif 4) through Intune or the IT image.
- [ ] Pilot group assigned in Integrated apps; wider rollout after a week.
