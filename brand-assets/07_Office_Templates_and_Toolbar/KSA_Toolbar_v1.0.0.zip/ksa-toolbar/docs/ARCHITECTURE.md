# KSA Toolbar architecture

A static web app plus three manifests. No framework, no bundler: `src/` is served as is and runs in Office's web view (Edge WebView2 on Windows, Safari on Mac, the browser on the web) and in a plain browser for Teams and previews. Everything in `src/` references `assets/` with relative paths (`../assets/...`), so the host origin and path prefix are free to change.

```
ribbon button ─┬─ ExecuteFunction ──► src/commands.js ─► Office.actions.associate ─► host module (insert / applyBrand)
               │                                          └─ open_<view> / showAssistant ─► showAsTaskpane + window.ksaGo(view)
               └─ ShowTaskpane ("KSA Toolbar") ─► src/taskpane.html ─► taskpane.js (router) ─► modules/views.js ─► modules/insert.js ─► host module
                                                                                   └─ modules/assistant.js ─► server/ proxy ─► Anthropic API
                                                                                                             └─ assistant-actions.js ─► host APIs
assets/library.json ◄── tools/build-library.py ◄── assets folders + tools/make-templates/*-index.json
```

## Runtime and manifests

- `manifest/manifest.xml` (Word, PowerPoint, Excel) declares a **shared runtime**: `src/taskpane.html` is the long-lived runtime and the FunctionFile, so the task pane page loads both `taskpane.js` and `commands.js`. Ribbon commands and the pane share one JavaScript context. A shared runtime allows one task pane, so there is a single ShowTaskpane button per host ("KSA Toolbar" in the Brand group); the eight Library buttons and KSA Assistant are ExecuteFunction commands (`open_icons`, `open_report_layouts`, `showAssistant`, ...) that save `lastView`, call `Office.addin.showAsTaskpane()` and switch the open pane through `window.ksaGo(view)` (set by taskpane.js). Hosts without SharedRuntime 1.1 ignore the VersionOverrides and load the plain task pane from `DefaultSettings`.
- `manifest/manifest-outlook.xml` has no shared runtime (Outlook does not support one); commands run from `src/commands.html`, a page with no UI that loads `commands.js`.
- `manifest/manifest.json` is the unified manifest for Teams and Microsoft 365: one `general` runtime (page `taskpane.html`, script `commands.js`), `executeFunction` actions for the four commands and the `open_<view>` commands, `openPage` actions for the pane, ribbons per scope, and a personal tab for the KSA Hub.
- All three share the add-in id `3621f603-b231-485e-b851-211e85f2a864` and the base URL placeholder `https://ksa-toolbar.kayaksa.com` (`tools/set-base-url.py`).

## Modules

| File | Role |
|---|---|
| `src/taskpane.js` | Boot: `ready()` from host.js, host label, tab strip, loads the library, routes `?view=` / `?hub=1` / last view, search box. `go(viewId)` renders `views[viewId]` into `#view` and remembers `lastView`. |
| `src/commands.js` | The ribbon commands: `insertLogo`, `applyKsaStyle`, `applyChartStyle`, `showAssistant` and `open_<view>` for every section (`open_icons`, `open_industry_icons`, `open_report_layouts`, ...). Each is wrapped so it always calls `event.completed()` and reports errors to the console (and the Outlook notification bar). |
| `modules/host.js` | `ready()` (Office.onReady with a 4 s timeout for hub mode), `host()` (`powerpoint` / `word` / `excel` / `outlook` / `hub`), `caps()` (requirement-set flags), `toast()`, `setStatus()`, `fetchText/fetchBase64/resolve()`, `download()`, `copyText()`, `svgToPngBase64()`, `insertSvgAtSelection()` / `insertPngAtSelection()` (the universal `setSelectedDataAsync` path), `getSettings/saveSettings()` (localStorage key `ksa-toolbar-settings`), `el()`. |
| `modules/library.js` | `loadLibrary()`, `byCategory()`, `allowedIn(item, host)`, `search()`, `subcategories()`, favourites, `gallery()` and `tile()` rendering. |
| `modules/views.js` | Every screen: home, logo and colour, a generic category view with subcategory chips and detail cards, effects, templates, settings, search results, and the assistant mount. `detailView` builds the Insert / variant / size controls from the item and the host's capabilities. |
| `modules/insert.js` | The router. `kindFor(item)` picks the insert kind for the current host; `insertItem(item, options)` loads the host module on demand and calls `insert`; `fallback()` copies SVG or downloads when the host throws; `applyBrand(preset)`, `newFromTemplate(item)`. |
| `modules/insert-ppt.js` | PowerPoint: SVG (`shapes.addSvg` when present, else `setSelectedDataAsync` XmlSvg), PNG, slides from the slide library (`insertSlidesFromBase64` with `sourceSlideIds`, then `slideIndex`, then whole file and delete), geometric shapes from `spec`, chart slides, templates (new deck or append). `applyBrand` styles the selected shapes with the preset. |
| `modules/insert-word.js` | Word: inline SVG or PNG, OOXML blocks (`insertOoxml`), tables, HTML, templates (`createDocument` on WordApi 1.3, else `insertFileFromBase64`). `applyBrand` maps presets to fonts, colours and built-in heading styles; `styleTable` gives tables the KSA look. |
| `modules/insert-excel.js` | Excel: charts from a `spec` (type, series roles, highlight) styled by `styleChart` in capability tiers, SVG or PNG shapes, tables (`styleTable`), RAG conditional formats, `createWorkbook`. `applyBrand("chart")` restyles the selected chart or all charts on the sheet. |
| `modules/insert-outlook.js` | Outlook compose: signature (`setSignatureAsync` on Mailbox 1.10, else `setSelectedDataAsync`), HTML blocks with `{{tokens}}` filled from Settings and the mailbox profile, PNG as data URI, whole templates (subject and body). |
| `modules/assistant.js` | Chat UI, Office context capture per host (range values, slide shapes, selected text, message body), the context strip, calls to the proxy, markdown-lite rendering as DOM (never innerHTML of model output), action buttons. |
| `modules/assistant-actions.js` | Executes validated actions: `excel.chart`, `excel.table`, `excel.rag`, `ppt.exhibit`, `ppt.title`, `word.insert`, `word.replace`, `outlook.insert`, `copy`. |
| `modules/brand.js` | The tokens in code: `C` (colours), `PALETTE`, `CLUSTERS` (six service clusters), `DATA` (chart rules), `THEME` (Office theme slots), `FONTS`, `BRAND_PRESETS` (what Apply KSA style and the Effects tab do). |
| `ui/tokens.css`, `ui/icons.js` | The KSA design tokens (copied from the guidelines) and inline glyphs for the pane. |
| `src/preview.html` | The pane in hub mode inside a phone-width frame, for trying the library without Office. |

Host modules all export the same three functions: `insert(item, options)`, `applyBrand(preset)`, `newFromTemplate(item)`. They throw plain `Error`s with readable messages; the router turns a throw into a fallback and a toast. Nothing is ever left as an unhandled rejection.

## library.json

`assets/library.json` is the catalogue the pane reads (1.8 MB, 2,405 items, generated by `tools/build-library.py`, validated by `tools/check-library.py`).

```json
{
  "version": "1.0.0", "generated": "2026-10-16T12:00:00Z",
  "categories": [ { "id": "icons", "name": "Icons", "icon": "..." } ],
  "items": [
    {
      "id": "icon.strategy", "category": "icons", "subcategory": "KSA services", "name": "Strategy",
      "tags": ["strategy", "compass"], "preview": "assets/icons/preview/strategy.png",
      "formats": { "svg": "assets/icons/svg/duotone/ksa-icon-strategy.svg", "png": "assets/icons/png/duotone/ksa-icon-strategy.png",
                   "svgVariants": { "duotone": "...", "line-deep": "...", "line-white": "...", "reversed": "...", "badge": "..." } },
      "insert": { "powerpoint": "svg", "word": "svg", "excel": "svg", "outlook": "png" },
      "hosts": ["powerpoint", "word", "excel", "outlook"],
      "size": { "w": 96, "h": 96 }, "editable": true
    }
  ]
}
```

Fields: `id` (unique, `<category prefix>.<slug>`), `category` (one of the fixed ids below), `subcategory` (the chip row), `name`, `tags`, `preview` (PNG path), `formats` (paths per format and SVG variants), `insert` (insert kind per host, `default` as a wildcard), `hosts` (where it is shown), `size` (natural size in points or px), `editable`, and optionally `file` (the pptx/docx/xlsx/xml/html the item comes from), `slideIndex` (1-based, int or list), `sourceSlideIds` (numeric sldId strings), `spec` (chart or shape definition), `html`, `dark` (shown on Deep Current), `featured` (on the Home screen), `badge`, `note`.

Categories, fixed order: `logo`, `colours`, `icons`, `industry-icons`, `shapes`, `infographics`, `diagrams` (labelled "Smart diagrams"), `charts`, `patterns`, `effects`, `layouts`, `report-layouts`, `templates`, `assistant`.

## Insert kinds per host

| Kind | PowerPoint | Word | Excel | Outlook | Hub |
|---|---|---|---|---|---|
| `svg` | `shapes.addSvg` (PowerPointApi 1.8) or XmlSvg coercion (ImageCoercion 1.2); PNG when neither | XmlSvg coercion; PNG fallback | `sheet.shapes.addSvg` (ExcelApi 1.9); PNG fallback | not supported, uses `png` | Copy SVG |
| `png` | `addImage` or Image coercion (ImageCoercion 1.1) | `insertInlinePictureFromBase64` | `shapes.addImage` | data-URI `<img>` in the body | Download |
| `slide` | `insertSlidesFromBase64` (PowerPointApi 1.2) with `sourceSlideIds`, then `slideIndex`, then whole file minus unwanted slides | no | no | no | Download the slide library |
| `ooxml` | no | `insertOoxml` at the selection | no | no | Download the .docx |
| `chart` | as `slide` | PNG exhibit | `charts.add` from `spec` + `styleChart` | no | Download |
| `shape` | `addGeometricShape` from `spec` (PowerPointApi 1.4) | SVG | `shapes.addGeometricShape` | PNG | Copy SVG |
| `html` | no | `insertHtml` | no | `setSelectedDataAsync` Html | Copy |
| `template` | new presentation (all slides) or append | `createDocument` (WordApi 1.3), else `insertFileFromBase64` | `createWorkbook` (ExcelApi 1.8) | sets subject and body after confirmation | Download |
| `effect` | preset on the selected shapes (1.4/1.5) | preset on the selection | preset on range, table or chart | no | no |
| `signature` | no | no | no | `setSignatureAsync` (Mailbox 1.10), else cursor | no |
| `download` | the universal fallback: `openBrowserWindow` where available, else an `<a download>` link | | | | |

## Capability fallbacks

`caps()` in host.js evaluates once at start: `svgInsert` (ImageCoercion 1.2 in PowerPoint and Word), `imageInsert` (1.1), `pptApi`/`pptSlides`/`pptShapes`/`pptSelection` (PowerPointApi 1.1/1.2/1.4/1.5), `wordApi`/`wordCreateDoc` (1.1/1.3), `excelApi`/`excelShapes`/`excelCreateWb` (1.1/1.9/1.8), `mailbox`/`mailboxSignature` (1.1/1.10), `dialog`, `openBrowser`. Newer methods such as `shapes.addSvg` in PowerPoint are feature-detected at call time (`typeof shapes.addSvg === "function"` after `load`).

The order is always: best native insert, then a simpler native insert, then download or copy, each step announced by a toast. The detail view greys out options the host cannot do and labels the fallback ("Insert as PNG", "Download slide library"). Excel chart styling is tiered too: colours, fonts, gridlines and the legend on ExcelApi 1.1; borders, line weights, markers, gap width and the doughnut hole on 1.7; number formats on 1.8. Each tier is one sync, so an older host keeps what it managed.

## Adding an asset

1. Put the source file where its family lives (`assets/icons/svg/<variant>/`, `assets/patterns/<slug>/`, a new slide in `tools/make-templates/build-library.js`, a new block in `build-docx.js`).
2. For slides and Word blocks, add the id to `tools/make-templates/slide-library-index.json` or `report-layouts-index.json` with `slideIndex` or the block path, a `name`, `subcategory` and `tags`; for Excel charts add a `spec` to `CHART_SPECS` in `tools/build-library.py`.
3. `python3 tools/build-library.py --only <section>` regenerates previews and `library.json`; `python3 tools/check-library.py` validates ids, paths, previews and size.
4. Open the pane (hub mode is enough) and check the tile, the detail view and the insert kinds per host. Commit `library.json` with the asset.

No code change is needed for a new item of an existing kind. A new insert kind means a case in each host module's `insert()` and a row in the table above.

## Security notes

- The pane never renders model output or `library.json` strings as HTML; `el()` builds DOM nodes and text nodes.
- OOXML blocks and HTML templates are shipped files, not user input; the Outlook HTML inserts escape the Settings values.
- The Assistant proxy whitelists action types and caps sizes; the add-in checks each action against the current host before showing a button (`ASSISTANT.md`).
- `tools/serve.js` refuses paths outside the root and is for development only.
