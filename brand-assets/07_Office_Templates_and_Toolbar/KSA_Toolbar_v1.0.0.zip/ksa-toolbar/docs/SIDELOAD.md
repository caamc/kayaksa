# Sideloading KSA Toolbar for testing

Sideloading installs the add-in for one user on one machine, from a manifest file, without the admin centre. Use it for development and for the pre-release check. The hosted files must already be reachable over HTTPS (a public host, or `node tools/serve.js` with a trusted local certificate), and the manifests must point at them (`python3 tools/set-base-url.py <url>`).

## Local server first

```bash
mkdir -p tools/certs && openssl req -x509 -newkey rsa:2048 -nodes -days 825 \
  -keyout tools/certs/localhost.key -out tools/certs/localhost.crt -subj "/CN=localhost" \
  -addext "subjectAltName=DNS:localhost,IP:127.0.0.1"
node tools/serve.js                                  # https://localhost:3000
python3 tools/set-base-url.py https://localhost:3000
```

Trust the certificate: Windows, double-click `localhost.crt` > Install Certificate > Local Machine > Trusted Root Certification Authorities. macOS, Keychain Access > System > drag the file in > double-click > Trust > Always Trust. Office desktop uses the system store (Edge WebView2 on Windows, Safari's on Mac). If you already use `office-addin-dev-certs`, point `KSA_CERT` and `KSA_KEY` at `~/.office-addin-dev-certs/localhost.crt` and `.key`.

## Windows: Word, PowerPoint, Excel (shared folder catalogue)

1. Create a folder, for example `C:\KSA-addin`, and copy `manifest\manifest.xml` into it.
2. Share the folder: right-click > Properties > Sharing > Share > add yourself > Share. Note the network path (`\\PC-NAME\KSA-addin`).
3. In Word (or any of the three): File > Options > Trust Center > Trust Center Settings > Trusted Add-in Catalogs. Paste the network path into **Catalog Url**, Add catalog, tick **Show in Menu**, OK. Restart the app.
4. Home > Add-ins (or Insert > My Add-ins) > **Shared Folder** > KSA Toolbar > Add. The KSA tab appears; the task pane opens from it.
5. After a manifest change: remove the add-in (Insert > My Add-ins > right-click > Remove), clear `%LOCALAPPDATA%\Microsoft\Office\16.0\Wef\` and add it again.

## Mac: Word, PowerPoint, Excel (wef folder)

1. Copy `manifest/manifest.xml` into the app's `wef` folder (create the folder if it is missing):
   - Word: `~/Library/Containers/com.microsoft.Word/Data/Documents/wef`
   - PowerPoint: `~/Library/Containers/com.microsoft.Powerpoint/Data/Documents/wef`
   - Excel: `~/Library/Containers/com.microsoft.Excel/Data/Documents/wef`
2. Restart the app. Insert > Add-ins > My Add-ins > the KSA Toolbar entry under **Developer Add-ins**.
3. To refresh after a change, delete the file from `wef`, clear `~/Library/Containers/com.microsoft.<app>/Data/Library/Caches/` and copy it again.

## Office on the web

1. Open a document in Word, PowerPoint or Excel on the web (OneDrive or SharePoint).
2. Home > Add-ins > More Add-ins > **MY ADD-INS** > **Upload My Add-in** > choose `manifest/manifest.xml`.
3. The KSA tab appears for that document in this browser session. Office on the web reads the manifest each time, so changes show after a reload; the hosted files must be on a public HTTPS host (localhost works only when the browser trusts the certificate and the manifest points at it).

## Outlook

**Outlook on the web and new Outlook:** Settings (cog) > **Accounts > Manage add-ins** (or **Get add-ins > My add-ins > Custom Addins > Add a custom add-in > Add from file**) and choose `manifest/manifest-outlook.xml`. Allow the warning. Open a new message; the buttons are under **Apps** in the toolbar (web) or on the ribbon's KSA tab (classic Windows).

**Classic Outlook on Windows:** the same web page installs it for the mailbox; restart Outlook. Alternatively File > Manage Add-ins opens that page.

Admin note: `OWA mailbox policy > Allow users to install custom add-ins` must be on, or sideloading is blocked. The signature slot needs Mailbox 1.10; check Help > About for the build.

## Teams (custom app)

1. `python3 teams/build-package.py` (after `set-base-url.py`).
2. Teams > Apps > **Manage your apps** > **Upload an app** > **Upload a custom app** > `teams/KSA-Toolbar-teams-app.zip` > Add. "Upload custom apps" must be allowed in the Teams app setup policy.
3. The KSA Hub tab opens in the app. A unified-manifest sideload also registers the Outlook and Office parts for your account on tenants that have unified-manifest add-ins enabled; give it a few minutes and open a new message in Outlook on the web.

## Testing checklist per host

Run through this on at least one Windows PC and one Mac before deployment. The expected text in brackets is the toast or status that appears.

**All hosts**
- [ ] KSA tab shows with the three groups; KSA Toolbar opens the pane; each Library button switches it to the right section, also when the pane is closed.
- [ ] Pane loads ("2,405 assets" in the status bar), search finds "chevron" and "pharma", favourites persist after closing the pane.
- [ ] Settings: name, title, phone, Assistant endpoint and token save and survive a restart.
- [ ] KSA Assistant: demo mode shows the setup card; with the endpoint set, "What can you do?" replies and the status bar shows a token count.

**PowerPoint**
- [ ] Insert logo on an empty slide ("Inserted").
- [ ] Icons > Strategy > Insert: an editable SVG shape; Insert as PNG also works.
- [ ] Smart diagrams > Process, 4 chevrons: a slide appears after the current one with grouped shapes; ungroup works.
- [ ] Charts > Column with highlight: a slide with a native chart; Chart Design tab is available.
- [ ] Layouts > Agenda and Templates > Corporate presentation (new deck or all slides).
- [ ] Select a text box, Apply KSA style: Archivo, Deep Current; Effects > Card on a rectangle.
- [ ] Patterns > any > Insert as background PNG.

**Word**
- [ ] Insert logo in a paragraph; Icons insert inline SVG; Report layouts > Cover block inserts at the cursor with the right fonts.
- [ ] Charts > Column with highlight inserts the PNG exhibit.
- [ ] Templates > Thought leadership opens a new document (WordApi 1.3) or inserts the file.
- [ ] Select two paragraphs, Apply KSA style; Effects > Standfirst.

**Excel**
- [ ] Select a range with a header row and numbers, Charts > Column with highlight: a native chart with one Saffron bar, Fog gridlines, zero baseline.
- [ ] Select the chart, Chart style: colours and fonts restyled; with nothing selected every chart on the sheet is restyled.
- [ ] Insert logo at a cell (SVG shape on ExcelApi 1.9, PNG otherwise).
- [ ] Effects > Table on a range: table with the Deep Current header; Templates > Excel charts workbook opens a new workbook.
- [ ] Assistant: "Chart this with one highlight" on a selected range returns an Insert chart action that works.

**Outlook (new message)**
- [ ] Insert signature: KSA signature with the details from Settings ("Signature inserted"; cursor insert on older builds).
- [ ] Email templates > The Kayak Brief inserts the HTML at the cursor; Signature block too.
- [ ] Icons > any > Insert places a PNG; Assistant "Draft a reply" returns Insert into message.

**Teams or browser (hub mode)**
- [ ] `src/preview.html` renders the pane; Insert buttons read Copy SVG and Download and both work; templates download.

**Fallbacks (on an older Office, or by blocking an API in DevTools)**
- [ ] Without PowerPointApi 1.2 a slide item offers "Download slide library" instead of an error.
- [ ] Without ImageCoercion 1.2 an icon inserts as PNG with a toast saying so.
- [ ] Library unreachable: the pane shows "Library unavailable" and stays usable.
