# KSA Toolbar — build brief for contributors

Root: `/tmp/claude-0/-home-claude/ec76a86b-014e-5555-9af7-d447705a7cba/scratchpad/addin/ksa-toolbar/`  (call it `ROOT`)
Scratchpad with all source brand material: `/tmp/claude-0/-home-claude/ec76a86b-014e-5555-9af7-d447705a7cba/scratchpad/` (call it `S`).

We are building **KSA Toolbar**: a Microsoft Office Add-in (Office.js) for **Kayak Strategic Advisors (KSA)**, a new strategy
and risk consulting boutique in India (domain kayaksa.com, no clients yet, no invented client names). It adds a **"KSA" ribbon
tab** in PowerPoint, Word, Excel and Outlook, with a task pane that holds every KSA brand asset, plus a **KSA Assistant**
chatbot for data analysis, visualisation and reporting. The same app is packaged for **Teams** (as a "KSA Hub" tab) with the
unified manifest. Power BI gets a separate theme/asset pack (Office add-ins do not run in Power BI).

## Non-negotiables
- **No build step for the web app.** Plain HTML + CSS + ES modules (`<script type="module">`), Office.js from the CDN
  (`https://appsforoffice.microsoft.com/lib/1/hosted/office.js`), no framework, no bundler. It must run from any static HTTPS host
  (GitHub Pages, Azure Static Web Apps, Cloudflare Pages). Everything is relative-path so the host base URL can change.
- Modern browsers only (Edge WebView2 in Office): ES2020, CSS grid/flex, `fetch`, no transpiling.
- **Progressive capability:** every action checks `Office.context.requirements.isSetSupported(...)` or feature detection and falls
  back (e.g. SVG insert → PNG insert; slide insert unsupported → download link). Never throw an unhandled error; show a toast.
- Host detection via `Office.context.host` (`PowerPoint`, `Word`, `Excel`, `Outlook`) and a `hub` mode when `Office.js` is not
  present (Teams tab / browser preview): the library still browses and downloads; insert buttons become "Copy SVG" / "Download".
- **Brand:** use the KSA design tokens (`S/vg/out/KSA_Design_Tokens/ksa-tokens.css` → copy to `ROOT/src/ui/tokens.css`).
  Colours: Deep Current #0E2F3C, Open Water #17807E, Beacon Saffron #EE9B1E, Sea Mist #EEF4F1, Storm Slate #3E5563, Fog #D4DEE2,
  Riverstone #8B9A9C, Kelp Green #4B7A4E, Red Clay #B4472F, Tidewater Blue #2D6A9F, Burnished Gold #9C630E, Dusk Plum #5E4B78,
  Estuary Sand #D8C5A1, Shallows #5DB2AB, Spray #CDE8E3, Deep Lagoon #0B5654, Undertow #1F4B5F, Haze #FBEBCD, Dawn #F5C46D.
  Fonts in Office files: **Archivo** (headings) and **Source Serif 4** (standfirsts/quotes) with Arial/Georgia fallbacks; in the
  task pane UI use Archivo via Google Fonts with a `Segoe UI, Arial` fallback.
- Six service clusters (colour, icon key): 1 Strategy, Deal & Transactions (#17807E, strategy) · 2 Tax & Regulatory (#9C630E,
  regulatory) · 3 Crisis & Resilience (#3E5563, risk) · 4 Technology & AI (#2D6A9F, technology) · 5 Managed Services
  (#4B7A4E, briefcase) · 6 International Desk (#5E4B78, globe).
- Chart rules (from the guidelines): primary series Open Water, highlight Beacon Saffron (one per chart), context Riverstone,
  gridlines Fog 1px, zero baseline, no pies/3D/dual axes, categorical order #17807E #2D6A9F #4B7A4E #3E5563 #D8C5A1 #5E4B78
  #5DB2AB #9AAD5A, donut thickness 18%, lines 2px, benchmark dashed Storm Slate.
- Plain, confident British English in all UI copy. No em dashes in copy. No lorem ipsum. Placeholders in square brackets.

## Folder layout (fixed — do not rename)
```
ROOT/
  manifest/                 manifest.xml (Word+Excel+PowerPoint), manifest-outlook.xml, manifest.json (unified: Teams+Office), icons/
  src/
    taskpane.html           the app shell (loaded by every host; ?view=hub for Teams/browser)
    taskpane.css            imports ui/tokens.css; all UI styles
    taskpane.js             boot: Office.onReady → host detection → router → render
    commands.html / commands.js   ribbon function-commands (no UI): e.g. applyBrandToSelection, insertLogo
    modules/
      host.js               detectHost(), caps(), toast(), download(), copy()
      library.js            load assets/library.json, search/filter, gallery rendering, favourites (localStorage)
      brand.js              tokens, palettes, applyBrand helpers (fonts/colours per host)
      insert-ppt.js         PowerPoint insertion (SVG, image, slides-from-base64, shapes, charts via slide library, apply brand)
      insert-word.js        Word insertion (SVG/PNG, OOXML blocks, tables, styles, createDocument from template)
      insert-excel.js       Excel insertion (charts + KSA styling, shapes/SVG, tables, RAG conditional format, createWorkbook)
      insert-outlook.js     Outlook (signatures, HTML blocks, templates)
      assistant.js          KSA Assistant chat UI + Office context + actions
      assistant-actions.js  executes structured actions returned by the assistant (chart, exhibit slide, summary, table)
    ui/
      tokens.css            KSA design tokens (copied)
      icons.js              inline UI glyphs for the pane
  assets/
    library.json            THE CATALOGUE (schema below) — generated by tools/build-library.py, committed
    logo/      svg + png (full colour, reversed, mono, identifier, monogram, app icon)
    icons/     KSA 48 service icons (svg, 6 variants) + industry icons (45 sectors × 48, svg duotone only, in subfolders)
    patterns/  11 patterns × colourways: tile svg + 1920x1080 png (from S/vg/out/KSA_Brand_Patterns)
    shapes/    editable brand shapes as SVG previews + ppt-slide ids (blades, chevrons, delta, badges, dividers, marks)
    diagrams/  "Smart diagrams" previews (png) + slide ids in templates/KSA_Slide_Library.pptx
    infographics/  previews + slide ids
    charts/    chart presets: preview png + spec json (type, options) + slide ids
    layouts/   slide layouts + report (Word) layouts previews + ids
    effects/   effect presets json (shadow e1-e3, blade crop mask svg, duotone, pattern overlay)
    templates/ KSA_Corporate_Presentation.pptx, KSA_Service_Proposal.pptx/.docx, KSA_Thought_Leadership.docx,
               KSA_Slide_Library.pptx (every insertable slide: layouts, charts, diagrams, infographics, shapes, effects),
               KSA_Report_Layouts.docx, KSA_Excel_Charts.xlsx, KSA_Email_Templates.html, previews/*.png
  server/
    cloudflare-worker/      assistant proxy (wrangler.toml, src/index.js), README
    azure-function/         same proxy as an Azure Function (optional alternative)
  powerbi/                  ksa-powerbi-theme.json, icons png pack, KSA_PowerBI_Guide.md, sample report layout images
  teams/                    teams-app-package build script + README (zips manifest.json + icons)
  tools/                    build-library.py (writes assets/library.json from the assets folders), serve.js (local https dev server),
                            make-templates/ (pptxgenjs / docx-js scripts that generate the templates)
  docs/                     README.md, DEPLOY.md, SIDELOAD.md, ARCHITECTURE.md, ASSISTANT.md, CHANGELOG.md
```

## library.json schema (fixed)
```json
{ "version": "1.0.0", "generated": "2026-10-16T…",
  "categories": [ {"id":"icons","name":"Icons","icon":"…"}, … ],
  "items": [
    { "id": "icon.strategy", "category": "icons", "subcategory": "KSA services", "name": "Strategy",
      "tags": ["strategy","compass"], "preview": "assets/icons/preview/strategy.png",
      "formats": { "svg": "assets/icons/svg/duotone/ksa-icon-strategy.svg", "png": "assets/icons/png/duotone/ksa-icon-strategy.png",
                   "svgVariants": {"duotone":"…","line-deep":"…","line-white":"…","reversed":"…","badge":"…"} },
      "insert": { "powerpoint": "svg", "word": "svg", "excel": "svg", "outlook": "png" },
      "hosts": ["powerpoint","word","excel","outlook"],
      "size": { "w": 96, "h": 96 },
      "editable": true }
  ]
}
```
`insert` kinds: `svg` (XmlSvg coercion / addSvg), `png` (image), `slide` (insertSlidesFromBase64 from `file` with `slideIds`),
`ooxml` (Word insertOoxml from `file`), `chart` (Excel: build chart from `spec`), `html` (Outlook), `template` (new document:
Word createDocument / Excel createWorkbook / PowerPoint insert all slides), `effect` (apply preset to selection), `shape`
(PowerPoint/Excel geometric shape built from `spec`), `download` (fallback). Items may carry `file` (relative path),
`slideIds` (array of pptx slide ids, as numbers 256+ in presentation.xml order OR the 1-based index; use `slideIndex`
1-based for clarity: `"slideIndex": [3]`), `spec` (object), `html` (string path).

Categories (ids fixed): `logo`, `colours`, `icons`, `industry-icons`, `shapes`, `infographics`, `diagrams` (shown as "Smart
diagrams"), `charts`, `patterns`, `effects`, `layouts`, `report-layouts`, `templates`, `assistant`.

## Office.js capabilities to use (checked facts; use requirement sets defensively)
- Universal icon insert: `Office.context.document.setSelectedDataAsync(svgString, {coercionType: Office.CoercionType.XmlSvg}, cb)`
  (ImageCoercion 1.2 — PowerPoint and Word). Image: `coercionType: Office.CoercionType.Image` with base64 PNG (ImageCoercion 1.1).
- PowerPoint: `PowerPoint.run`: `context.presentation.insertSlidesFromBase64(base64, {formatting:"KeepSourceFormatting"|"UseDestinationTheme", sourceSlideIds:[...], targetSlideId})`
  (PowerPointApi 1.2); `slide.shapes.addGeometricShape(PowerPoint.GeometricShapeType.rectangle,{left,top,width,height})`,
  `addLine`, `addTextBox` (1.4); `shape.fill.setSolidColor("#hex")`, `shape.lineFormat.color/weight/visible`,
  `shape.textFrame.textRange.font.{name,size,color,bold}`; `context.presentation.getSelectedShapes()` and
  `getSelectedSlides()` (1.5); `slide.shapes.addSvg(svgXml, {left,top,width,height})` and `addImage(base64)` exist in newer
  PowerPointApi (1.8) — feature-detect (`typeof shapes.addSvg === "function"` after load) and fall back to setSelectedDataAsync.
  Slide ids for sourceSlideIds come from reading the pptx `ppt/presentation.xml` sldId list (`id="256"`) and
  `ppt/slides/slideN.xml` names; our build tool records them in library.json as `sourceSlideIds` (strings like "256#…"? NO:
  the API accepts the slide id strings as PowerPoint reports them: `"{sldId}#{rId-less}"` is not needed; use the numeric id as a
  string, e.g. "257"). To be safe, provide BOTH `sourceSlideIds` (numeric strings) and `slideIndex`; the code tries ids then falls
  back to inserting the whole file and deleting unwanted slides (delete via `slide.delete()` 1.2).
- Word: `Word.run`: `context.document.getSelection().insertInlinePictureFromBase64(b64, "End")`, `insertOoxml(pkg, "End")`,
  `insertTable(rows, cols, "End", values)`, `insertParagraph`, `paragraph.styleBuiltIn = Word.Style.heading1`, `font.name/size/color`;
  `context.application.createDocument(base64).open()` (WordApi 1.3) for templates; `document.body.insertFileFromBase64`
  (WordApi 1.1? insertFileFromBase64 exists on Body/Range, 1.1).
- Excel: `Excel.run`: `sheet.charts.add(Excel.ChartType.columnClustered, range, "Auto")`; `chart.series.getItemAt(i).format.fill.setSolidColor`,
  `chart.axes.valueAxis.majorGridlines.format.line.color`, `chart.title.text/format.font`, `chart.legend.visible`,
  `chart.dataLabels.showValue`; `sheet.shapes.addSvg(xml)` (ExcelApi 1.9) and `addGeometricShape`; `sheet.tables.add(range, true)`,
  `table.style = "TableStyleLight1"`; `range.conditionalFormats.add(Excel.ConditionalFormatType.cellValue)`;
  `Excel.createWorkbook(base64)` (ExcelApi 1.8); `range.numberFormat`.
- Outlook: `Office.context.mailbox.item.body.setSignatureAsync(html, {coercionType: Office.CoercionType.Html})` (Mailbox 1.10),
  `item.body.setSelectedDataAsync(html, {coercionType: Office.CoercionType.Html})`, `item.subject.setAsync`.
- Dialog for OAuth/API key entry: `Office.context.ui.displayDialogAsync`. Downloads: `Office.context.ui.openBrowserWindow(url)`
  where available, else an `<a download>` link.

## Templates (pptxgenjs / docx-js; follow /mnt/skills/public/pptx/SKILL.md and /mnt/skills/public/docx/SKILL.md)
- 16:9, LAYOUT_WIDE 13.333×7.5 in. Theme fonts Archivo / Archivo; body Arial fallback is automatic in Office if Archivo is missing,
  so ALSO ship the fonts (S/build/pkg/KSA_Logo_Package/05_Fonts) in ROOT/assets/fonts and tell users to install them.
- Native, editable: charts via `addChart`, diagrams/infographics as grouped shapes (`addShape`, `addText`, `addImage` for icons),
  tables via `addTable`. Theme colours: dk1 0E2F3C, lt1 FFFFFF, dk2 3E5563, lt2 EEF4F1, accent1 17807E, accent2 EE9B1E,
  accent3 2D6A9F, accent4 4B7A4E, accent5 9C630E, accent6 5E4B78, hlink 0B5654, folHlink 5E4B78.
- Content from the KSA corporate deck (see `S/deck2/project/slides/*.html`) and the guideline book (S/vg). No client names.

## App shell already written (read before adding anything)
`src/taskpane.html`, `src/taskpane.css`, `src/taskpane.js` (router + tabs), `src/modules/host.js` (ready(), host(), caps(),
toast(), fetchText/fetchBase64/resolve(), download(), copyText(), svgToPngBase64(), insertSvgAtSelection(), insertPngAtSelection(),
getSettings/saveSettings(), el()), `src/modules/library.js` (loadLibrary, byCategory, search, gallery, favourites),
`src/modules/insert.js` (router: insertItem(item,{kind,variant}), applyBrand(preset), newFromTemplate(item), fallback()),
`src/modules/views.js` (all screens; detailView; categoryView), `src/modules/brand.js` (C, PALETTE, CLUSTERS, DATA, THEME, FONTS,
BRAND_PRESETS). Host modules must export `insert(item, options)`, `applyBrand(preset)`, `newFromTemplate(item)`; options.kind is
one of the insert kinds in the schema. `assistant.js` must export `render(container, ctx)`.
Source material locations: KSA 48 icons: `S/icons/out/KSA_Monogram_and_Icons/02_Icons/{SVG/<variant>/, PNG_256px/<variant>/}`;
industry icons: `S/ind/out/KSA_Industry_Icons/NN_Industry/{SVG/<variant>/, PNG_1024px/, Web/}` + `KSA_Industry_Icon_Index.csv`;
patterns: `S/vg/out/KSA_Brand_Patterns/NN_Name/*`; logos already in `ROOT/assets/logo`; fonts in `ROOT/assets/fonts`;
Kayak icon drawing code `S/icons/icons.py` (svg(name, base, accent, size)); pattern code `S/vg/patterns.py`;
guideline page renders `S/vg/png/NN.png` (for reference of diagrams, infographics, charts, badges, dividers: pages 28–44, 57–58).
