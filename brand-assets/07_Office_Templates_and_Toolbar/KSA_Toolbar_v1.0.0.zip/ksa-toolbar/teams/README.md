# KSA Toolbar: Teams and Microsoft 365 app package

One zip, built from the unified manifest, installs KSA Toolbar everywhere Microsoft 365 reads it:

- **Teams**: a personal tab called **KSA Hub** that browses, copies and downloads every brand asset (no Office.js, so no insert buttons).
- **Outlook** (new Outlook, Outlook on the web, and classic Outlook on Windows with the unified manifest enabled): the KSA tab in message compose.
- **Word, PowerPoint and Excel** (Microsoft 365 current channel): the KSA ribbon tab, the same one the XML manifest adds.

## Build

```bash
python3 tools/set-base-url.py https://your-host.example.com   # once, after the static site is live
python3 teams/build-package.py                                 # writes teams/KSA-Toolbar-teams-app.zip
```

The script checks icon sizes (`color.png` 192 x 192, `outline.png` 32 x 32 transparent) and string lengths, then zips `manifest.json`, `color.png` and `outline.png` at the root of the archive. Nothing else goes in the package; the add-in itself is served from the base URL.

## Upload for the whole firm (recommended)

Microsoft 365 admin centre: **Settings > Integrated apps > Upload custom apps > App type: Teams app (or "Office Add-in" for the XML manifests) > Upload manifest file (.zip)**.

1. Choose the zip, let the wizard read the manifest, and pick **Entire organisation** or specific users or groups.
2. Review the permissions it lists (Document, Workbook, Presentation and Mailbox ReadWrite for the signed-in user; no Graph permissions).
3. Finish. Office apps pick it up within a few hours (Outlook and Teams usually within minutes, desktop Word, PowerPoint and Excel at the next launch, at most 24 hours).

Updating: bump `version` in `manifest/manifest.json`, rebuild the zip, then **Integrated apps > KSA Toolbar > Update app** and upload the new package. The id must not change.

## Upload in Teams only

Teams admin centre: **Teams apps > Manage apps > Upload new app**, choose the zip. Then set the app's availability under **Permission policies** or **Setup policies** (pin it so the KSA Hub tab appears for everyone). This path makes the Teams tab available; the Outlook and Office parts are also deployed by Microsoft 365, but managing them from Integrated apps is clearer.

## Sideload for yourself (testing)

Teams: **Apps > Manage your apps > Upload an app > Upload a custom app** and pick the zip (requires the "Upload custom apps" policy). The KSA Hub tab appears under the app; Outlook on the web shows the KSA tab in a new message within a few minutes because custom Teams app uploads also register the add-in for your account.

## Schema version

`manifest.json` uses `"manifestVersion": "devPreview"` and the `vDevPreview` schema so that every Office add-in feature validates. Before a production upload, switch both to the current GA version that supports Office add-ins (`1.17` or later, see the Microsoft Learn page "Office Add-ins with the unified app manifest for Microsoft 365"), rebuild the package and re-validate with the Teams Developer Portal (**Apps > Import app**), which reports schema errors with line numbers.
