#!/usr/bin/env python3
"""Build the Teams / Microsoft 365 app package for KSA Toolbar.

Zips manifest/manifest.json (as manifest.json) with manifest/icons/color.png and outline.png into
teams/KSA-Toolbar-teams-app.zip. The package is what you upload in the Teams admin centre or the
Microsoft 365 admin centre (Integrated apps). Standard library only.

Usage:  python3 teams/build-package.py [--out path.zip] [--check-only]
"""
import argparse
import json
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
MANIFEST = os.path.join(ROOT, "manifest", "manifest.json")
ICONS = os.path.join(ROOT, "manifest", "icons")
DEFAULT_OUT = os.path.join(ROOT, "teams", "KSA-Toolbar-teams-app.zip")


def png_size(path):
    """Return (width, height) of a PNG without any imaging library."""
    with open(path, "rb") as f:
        head = f.read(24)
    if head[:8] != b"\x89PNG\r\n\x1a\n" or head[12:16] != b"IHDR":
        raise SystemExit(f"{path} is not a PNG")
    return int.from_bytes(head[16:20], "big"), int.from_bytes(head[20:24], "big")


def check(manifest):
    problems = []
    icons = manifest.get("icons", {})
    for key, expect in (("color", (192, 192)), ("outline", (32, 32))):
        name = icons.get(key)
        if not name:
            problems.append(f"icons.{key} missing")
            continue
        path = os.path.join(ICONS, name)
        if not os.path.exists(path):
            problems.append(f"icons.{key} -> {path} not found")
            continue
        size = png_size(path)
        if size != expect:
            problems.append(f"icons.{key} is {size[0]}x{size[1]}, Teams expects {expect[0]}x{expect[1]}")
    if len(manifest.get("name", {}).get("short", "")) > 30:
        problems.append("name.short longer than 30 characters")
    if len(manifest.get("name", {}).get("full", "")) > 100:
        problems.append("name.full longer than 100 characters")
    if len(manifest.get("description", {}).get("short", "")) > 80:
        problems.append("description.short longer than 80 characters")
    if len(manifest.get("description", {}).get("full", "")) > 4000:
        problems.append("description.full longer than 4000 characters")
    if len(manifest.get("developer", {}).get("name", "")) > 32:
        problems.append("developer.name longer than 32 characters")
    if "ksa-toolbar.kayaksa.com" in json.dumps(manifest):
        print("note: manifest still uses the placeholder base URL https://ksa-toolbar.kayaksa.com "
              "(run tools/set-base-url.py <url> before deploying)")
    return problems


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=DEFAULT_OUT)
    ap.add_argument("--check-only", action="store_true")
    args = ap.parse_args()

    with open(MANIFEST, "r", encoding="utf-8") as f:
        manifest = json.load(f)
    problems = check(manifest)
    for p in problems:
        print("error:", p)
    if problems:
        sys.exit(1)
    if args.check_only:
        print("manifest.json and icons look fine")
        return

    os.makedirs(os.path.dirname(args.out), exist_ok=True)
    with zipfile.ZipFile(args.out, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(MANIFEST, "manifest.json")
        z.write(os.path.join(ICONS, manifest["icons"]["color"]), manifest["icons"]["color"])
        z.write(os.path.join(ICONS, manifest["icons"]["outline"]), manifest["icons"]["outline"])
    size = os.path.getsize(args.out)
    print(f"wrote {args.out} ({size:,} bytes): manifest.json, {manifest['icons']['color']}, {manifest['icons']['outline']}")
    print(f"app id {manifest['id']}, version {manifest['version']}, manifestVersion {manifest['manifestVersion']}")


if __name__ == "__main__":
    main()
