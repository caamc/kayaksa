/* insert-outlook.js — Outlook host module for the KSA Toolbar (compose mode only).
 *
 * Exports:
 *   insert(item, { kind, variant, size })  → Promise<string>   "html" | "signature" | "png" | "template"
 *       kinds: "html" (HTML block with {{tokens}} filled from settings) | "signature" (KSA signature) |
 *              "png" (inline data-URI image) | "template" (sets subject + whole body after confirmation)
 *   applyBrand()                           → always throws "Not available in Outlook"
 *   newFromTemplate(item)                  → Promise<void>     same as insert(item, { kind: "template" })
 *   buildSignatureHtml(profile)            → string            pure: { name, title, phone, email, logoUrl, website }
 *   fillTokens(html, profile)              → string            pure: replaces {{name}} {{title}} {{phone}} {{email}} {{website}} {{logo}}
 *   signatureProfile()                     → profile from saved settings + the mailbox user profile
 *   LOGO_PATH                              relative path of the PNG logo used in signatures
 *
 * Every public function wraps Office calls in try/catch and throws a plain Error with a readable message.
 */
import { caps, fetchText, fetchBase64, resolve, getSettings } from "./host.js";
import { C } from "./brand.js";

export const LOGO_PATH = "assets/logo/KSA_Logo_Full_FullColour.png";
const WEBSITE = "kayaksa.com";
const FONT = "Archivo, Arial, Helvetica, sans-serif";

/* ---------- pure helpers ---------- */
export function escapeHtml(s) {
  return String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}
function clean(v, fallback) { const s = String(v ?? "").trim(); return s || fallback; }

/** Build the KSA email signature (600px table, inline styles, Arial fallback). */
export function buildSignatureHtml(profile = {}) {
  const name = escapeHtml(clean(profile.name, "[Full Name]"));
  const title = escapeHtml(clean(profile.title, "[Designation]"));
  const phone = clean(profile.phone, "");
  const email = clean(profile.email, "");
  const website = clean(profile.website, WEBSITE);
  const logo = escapeHtml(clean(profile.logoUrl, LOGO_PATH));
  const contact = [];
  if (phone) contact.push(`<a href="tel:${escapeHtml(phone.replace(/[^+\d]/g, ""))}" style="color:${C.slate};text-decoration:none">${escapeHtml(phone)}</a>`);
  if (email) contact.push(`<a href="mailto:${escapeHtml(email)}" style="color:${C.slate};text-decoration:none">${escapeHtml(email)}</a>`);
  contact.push(`<a href="https://www.${escapeHtml(website)}" style="color:${C.slate};text-decoration:none">${escapeHtml(website)}</a>`);
  const sep = `<span style="color:${C.river}">&nbsp;&nbsp;|&nbsp;&nbsp;</span>`;
  return [
    `<table cellpadding="0" cellspacing="0" border="0" role="presentation" style="width:600px;max-width:600px;border-collapse:collapse;font-family:${FONT};mso-table-lspace:0;mso-table-rspace:0">`,
    `<tr>`,
    `<td style="padding:0 18px 0 0;vertical-align:middle;width:150px"><a href="https://www.${escapeHtml(website)}" style="text-decoration:none"><img src="${logo}" width="150" height="48" alt="Kayak Strategic Advisors" style="display:block;border:0;width:150px;height:48px;outline:none"></a></td>`,
    `<td style="width:2px;padding:0;vertical-align:middle">`,
    `<table cellpadding="0" cellspacing="0" border="0" role="presentation" style="border-collapse:collapse;width:2px">`,
    `<tr><td style="width:2px;height:30px;background-color:${C.water};font-size:0;line-height:0;mso-line-height-rule:exactly">&nbsp;</td></tr>`,
    `<tr><td style="width:2px;height:30px;background-color:${C.saffron};font-size:0;line-height:0;mso-line-height-rule:exactly">&nbsp;</td></tr>`,
    `</table></td>`,
    `<td style="padding:0 0 0 18px;vertical-align:middle">`,
    `<div style="font-family:${FONT};font-size:15px;line-height:20px;font-weight:700;color:${C.deep}">${name}</div>`,
    `<div style="font-family:${FONT};font-size:12px;line-height:18px;color:${C.water}">${title}</div>`,
    `<div style="font-family:${FONT};font-size:12px;line-height:18px;color:${C.slate};padding-top:6px">${contact.join(sep)}</div>`,
    `</td>`,
    `</tr>`,
    `</table>`,
  ].join("");
}

/** Replace {{name}} {{title}} {{phone}} {{email}} {{website}} {{logo}} (case-insensitive, spaces allowed). */
export function fillTokens(html, profile = {}) {
  const map = {
    name: clean(profile.name, "[Full Name]"), title: clean(profile.title, "[Designation]"), designation: clean(profile.title, "[Designation]"),
    phone: clean(profile.phone, "[Mobile]"), email: clean(profile.email, "[email]"), website: clean(profile.website, WEBSITE),
    logo: clean(profile.logoUrl, LOGO_PATH), signature: profile.signatureHtml || "",
  };
  return String(html).replace(/\{\{\s*([a-z]+)\s*\}\}/gi, (m, key) => {
    const k = key.toLowerCase();
    if (!(k in map)) return m;
    return k === "logo" || k === "signature" ? map[k] : escapeHtml(map[k]);
  });
}

/* ---------- Office plumbing ---------- */
function mailItem() {
  const it = typeof Office !== "undefined" ? Office?.context?.mailbox?.item : null;
  if (!it) throw new Error("Open or compose an email first");
  return it;
}
function requireCompose(it) {
  if (!it.body || typeof it.body.setSelectedDataAsync !== "function") throw new Error("This works while composing an email. Open a new message or reply first");
}
function call(fn, ...args) {
  return new Promise((resolveP, reject) => {
    try {
      fn(...args, (res) => {
        if (res && res.status === Office.AsyncResultStatus.Succeeded) resolveP(res.value);
        else reject(new Error(res?.error?.message || "Outlook did not accept the change"));
      });
    } catch (e) { reject(e); }
  });
}
function hostUserEmail() {
  try { return Office?.context?.mailbox?.userProfile?.emailAddress || ""; } catch { return ""; }
}
function hostUserName() {
  try { return Office?.context?.mailbox?.userProfile?.displayName || ""; } catch { return ""; }
}
export function signatureProfile() {
  const s = getSettings();
  return {
    name: s.userName || hostUserName(),
    title: s.userTitle || "",
    phone: s.userPhone || "",
    email: s.userEmail || hostUserEmail(),
    website: WEBSITE,
    logoUrl: resolve(LOGO_PATH),
  };
}
function ensureHtmlCoercion() {
  if (typeof Office === "undefined" || !Office.CoercionType?.Html) throw new Error("HTML insert is not available in this Outlook");
}

/* ---------- insert ---------- */
export async function insert(item, options = {}) {
  const kind = options.kind || "html";
  try {
    switch (kind) {
      case "html": return await insertHtml(item);
      case "signature": return await insertSignature(item);
      case "png": return await insertPng(item, options);
      case "template": return await applyTemplate(item);
      default: throw new Error(`Outlook cannot insert "${kind}" items`);
    }
  } catch (e) {
    throw e instanceof Error ? e : new Error(String(e));
  }
}

async function insertHtml(item) {
  const path = item.html || item.file;
  if (!path) throw new Error("This item has no HTML to insert");
  const it = mailItem(); requireCompose(it); ensureHtmlCoercion();
  if (!caps().mailbox) throw new Error("This needs Outlook 2016 or Microsoft 365");
  const profile = signatureProfile();
  const html = fillTokens(await fetchText(path), { ...profile, signatureHtml: buildSignatureHtml(profile) });
  await call(it.body.setSelectedDataAsync.bind(it.body), html, { coercionType: Office.CoercionType.Html });
  return "html";
}

async function insertSignature(item = {}) {
  const it = mailItem(); requireCompose(it); ensureHtmlCoercion();
  const profile = signatureProfile();
  let html;
  if (item.file && /\.html?$/i.test(item.file)) html = fillTokens(await fetchText(item.file), { ...profile, signatureHtml: buildSignatureHtml(profile) });
  else html = buildSignatureHtml(profile);
  const canSign = caps().mailboxSignature && typeof it.body.setSignatureAsync === "function";
  if (canSign) {
    try { await call(it.body.setSignatureAsync.bind(it.body), html, { coercionType: Office.CoercionType.Html }); return "signature"; }
    catch (e) { console.warn("setSignatureAsync failed, inserting at the cursor instead", e); }
  }
  await call(it.body.setSelectedDataAsync.bind(it.body), html, { coercionType: Office.CoercionType.Html });
  return "signature";
}

async function insertPng(item, options = {}) {
  const f = item.formats || {};
  const path = (options.variant && f.pngVariants?.[options.variant]) || f.png;
  if (!path) throw new Error("This item has no PNG version for email");
  const it = mailItem(); requireCompose(it); ensureHtmlCoercion();
  const base64 = await fetchBase64(path);
  const width = Number(options.size) || (item.category === "logo" ? 160 : Math.min(Number(item.size?.w) || 96, 600));
  const html = `<img src="data:image/png;base64,${base64}" width="${width}" alt="${escapeHtml(item.name || "")}" style="display:inline-block;border:0;width:${width}px;height:auto">`;
  await call(it.body.setSelectedDataAsync.bind(it.body), html, { coercionType: Office.CoercionType.Html });
  return "png";
}

/** Whole-message template: subject + body replaced after the user confirms. */
async function applyTemplate(item) {
  const path = item.html || item.file;
  if (!path) throw new Error("This template has no HTML file");
  const it = mailItem(); requireCompose(it); ensureHtmlCoercion();
  const profile = signatureProfile();
  const raw = await fetchText(path);
  const html = fillTokens(raw, { ...profile, signatureHtml: buildSignatureHtml(profile) });
  const subject = item.spec?.subject || (raw.match(/<title[^>]*>([^<]*)<\/title>/i) || [])[1]?.trim() || item.name || "";
  let ok = true;
  try { ok = window.confirm(`Replace the current message with the "${item.name || "KSA"}" template?`); } catch { ok = true; }
  if (!ok) throw new Error("Kept the current message");
  if (subject && it.subject && typeof it.subject.setAsync === "function") {
    try { await call(it.subject.setAsync.bind(it.subject), fillTokens(subject, profile)); } catch (e) { console.warn("subject not set", e); }
  }
  if (typeof it.body.setAsync === "function") await call(it.body.setAsync.bind(it.body), html, { coercionType: Office.CoercionType.Html });
  else await call(it.body.setSelectedDataAsync.bind(it.body), html, { coercionType: Office.CoercionType.Html });
  return "template";
}

export async function newFromTemplate(item) { await applyTemplate(item); }

export async function applyBrand() { throw new Error("Not available in Outlook"); }
