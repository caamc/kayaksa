/* insert-ppt.js — PowerPoint host module for the KSA Toolbar.
 *
 * Exports (the three the router in insert.js expects, plus helpers that are safe to unit-test):
 *   insert(item, { kind, variant, size, formatting })  → Promise<string>  how it was inserted ("svg", "png", "slides", "shape"…)
 *       kinds: "svg" | "png" | "slide" | "chart" | "shape" | "template"
 *   applyBrand(preset)                                  → Promise<void>    style the selected shapes (BRAND_PRESETS semantics)
 *   newFromTemplate(item)                               → Promise<void>    append every slide of item.file (KeepSourceFormatting)
 *   getActiveSlide(context)                             → Promise<{ slide, id, index, count }>
 *   emuToPt(emu), ptToEmu(pt), inToPt(inches), toPt(value)  unit helpers (the API works in points)
 *   svgAspect(svgText)                                  → { w, h } intrinsic size parsed from width/height or viewBox
 *   OFFICE_TO_KSA                                       stock Office theme colours → KSA colours (used by the "ksa-theme" preset)
 *   remapColour(hex)                                    → KSA colour or null when the colour is not a stock Office default
 *
 * Every public function wraps Office calls in try/catch and throws a plain Error with a readable message;
 * the router falls back to copy/download when we throw. Nothing here touches the DOM except via host.js helpers.
 */
import { caps, fetchText, fetchBase64, insertSvgAtSelection, insertPngAtSelection, svgToPngBase64 } from "./host.js";
import { C, FONTS } from "./brand.js";

/* ---------- units ---------- */
export const EMU_PER_PT = 12700;
export function emuToPt(emu) { return Number(emu) / EMU_PER_PT; }
export function ptToEmu(pt) { return Math.round(Number(pt) * EMU_PER_PT); }
export function inToPt(inches) { return Number(inches) * 72; }
/** Accepts points (numbers up to ~2000), EMU (large integers) or strings like "2in", "120pt", "3cm". */
export function toPt(value, fallback = 0) {
  if (value === null || value === undefined || value === "") return fallback;
  if (typeof value === "string") {
    const m = value.trim().match(/^(-?[\d.]+)\s*(pt|in|cm|mm|px|emu)?$/i);
    if (!m) return fallback;
    const n = parseFloat(m[1]); const u = (m[2] || "pt").toLowerCase();
    return u === "in" ? n * 72 : u === "cm" ? n * 72 / 2.54 : u === "mm" ? n * 72 / 25.4 : u === "px" ? n * 0.75 : u === "emu" ? n / EMU_PER_PT : n;
  }
  const n = Number(value);
  if (!Number.isFinite(n)) return fallback;
  return Math.abs(n) > 20000 ? n / EMU_PER_PT : n; // anything that large can only be EMU
}

/* Standard 16:9 slide in points (13.333 in × 7.5 in). The API does not expose the slide size, so we assume this. */
export const SLIDE = { w: 960, h: 540 };

/* ---------- stock Office colours → KSA (upper-case keys) ---------- */
export const OFFICE_TO_KSA = {
  // Office 2013–2022 theme
  "#4472C4": C.water, "#ED7D31": C.saffron, "#A5A5A5": C.river, "#FFC000": C.dawn, "#5B9BD5": C.tide, "#70AD47": C.kelp,
  "#44546A": C.slate, "#E7E6E6": C.mist, "#0563C1": C.lagoon, "#954F72": C.plum,
  // Office 2023 theme
  "#156082": C.tide, "#E97132": C.saffron, "#196B24": C.kelp, "#0F9ED5": C.shallows, "#A02B93": C.plum, "#4EA72E": C.lichen,
  "#0E2841": C.deep, "#E8E8E8": C.mist, "#467886": C.lagoon, "#96607D": C.plum,
  // Office 2007–2010 theme
  "#4F81BD": C.water, "#C0504D": C.clay, "#9BBB59": C.kelp, "#8064A2": C.plum, "#4BACC6": C.shallows, "#F79646": C.saffron,
  "#1F497D": C.deep, "#EEECE1": C.mist,
  // plain black text → Deep Current
  "#000000": C.deep,
};
export function remapColour(hex) {
  if (!hex || typeof hex !== "string") return null;
  const k = hex.trim().toUpperCase();
  const key = k.startsWith("#") ? k : "#" + k;
  return OFFICE_TO_KSA[key] || null;
}

/* ---------- SVG size ---------- */
export function svgAspect(svgText) {
  const head = String(svgText || "").slice(0, 2000);
  const num = (s) => { const m = String(s || "").match(/-?[\d.]+/); return m ? parseFloat(m[0]) : NaN; };
  const vb = head.match(/viewBox\s*=\s*["']\s*([-\d.]+)[\s,]+([-\d.]+)[\s,]+([-\d.]+)[\s,]+([-\d.]+)/i);
  let w = num((head.match(/\swidth\s*=\s*["']([^"']+)/i) || [])[1]);
  let h = num((head.match(/\sheight\s*=\s*["']([^"']+)/i) || [])[1]);
  if ((!w || !h) && vb) { w = parseFloat(vb[3]); h = parseFloat(vb[4]); }
  if (!w || !h) return { w: 1, h: 1 };
  return { w, h };
}

/* ---------- Office.js plumbing ---------- */
function isSet(name, version) {
  try { return !!(Office?.context?.requirements?.isSetSupported(name, version)); } catch { return false; }
}
function readable(e) {
  const code = e?.code || e?.name || "";
  const known = {
    ApiNotFound: "This feature is not available in your version of PowerPoint",
    ApiNotAvailable: "This feature is not available in your version of PowerPoint",
    InvalidArgument: "PowerPoint rejected one of the values (check the slide ids or sizes)",
    ItemNotFound: "The slide or shape could not be found",
    AccessDenied: "PowerPoint did not allow this action",
    GeneralException: "PowerPoint reported a general error",
  };
  const base = known[code] || e?.message || String(e);
  const dbg = e?.debugInfo?.errorLocation ? ` (${e.debugInfo.errorLocation})` : "";
  return base + dbg;
}
/** PowerPoint.run with readable errors. */
async function run(fn) {
  if (typeof PowerPoint === "undefined" || !caps().pptApi) throw new Error("This needs PowerPoint 2019 or Microsoft 365");
  try { return await PowerPoint.run(fn); }
  catch (e) { throw new Error(readable(e)); }
}

/** The selected slide (first of the selection) or the first slide when nothing is selected. */
export async function getActiveSlide(context) {
  const slides = context.presentation.slides;
  slides.load("items/id");
  let selected = null;
  if (caps().pptSelection && typeof context.presentation.getSelectedSlides === "function") {
    try { selected = context.presentation.getSelectedSlides(); selected.load("items/id"); } catch { selected = null; }
  }
  await context.sync();
  const ids = slides.items.map((s) => s.id);
  if (!ids.length) throw new Error("The presentation has no slides yet. Add a slide first");
  let id = ids[0];
  if (selected && selected.items && selected.items.length) id = selected.items[0].id;
  const index = Math.max(0, ids.indexOf(id));
  return { slide: slides.items[index], id, index, count: ids.length };
}

function pathFor(item, variant, kind) {
  const f = item.formats || {};
  if (kind === "png") return (variant && f.pngVariants?.[variant]) || f.png || null;
  return (variant && f.svgVariants?.[variant]) || f.svg || null;
}
function defaultWidth(item, options) {
  if (options.size) return toPt(options.size);
  const cat = item.category || "";
  if (cat === "patterns") return SLIDE.w;
  if (cat === "logo") return /monogram|identifier|app/i.test(item.name || "") ? 72 : 216;
  if (cat === "icons" || cat === "industry-icons") return 72;
  const w = toPt(item.size?.w, 0);
  return w > 0 ? Math.min(w, SLIDE.w) : 240;
}
function placement(width, height, item) {
  if ((item.category || "") === "patterns") return { left: 0, top: 0, width: SLIDE.w, height: SLIDE.h };
  const w = Math.min(width, SLIDE.w - 40), h = Math.min(height, SLIDE.h - 40);
  return { left: Math.round((SLIDE.w - w) / 2), top: Math.round((SLIDE.h - h) / 2), width: Math.round(w), height: Math.round(h) };
}
/** Patterns go behind everything else; setZOrder is newer than addSvg, so it gets its own sync. */
async function sendToBack(context, shape) {
  try { shape.setZOrder("SendToBack"); await context.sync(); }
  catch (e) { console.info("KSA Toolbar: could not send the pattern to the back", readable(e)); }
}
function hasShapeApi(shapes, name) {
  return isSet("PowerPointApi", "1.8") && typeof shapes?.[name] === "function";
}

/* ---------- insert ---------- */
export async function insert(item, options = {}) {
  const kind = options.kind || "svg";
  try {
    switch (kind) {
      case "svg": return await insertSvg(item, options);
      case "png": return await insertPng(item, options);
      case "slide":
      case "chart": return await insertSlides(item, options);
      case "shape": return await insertShape(item, options);
      case "template": await newFromTemplate(item); return "slides";
      default: throw new Error(`PowerPoint cannot insert "${kind}" items`);
    }
  } catch (e) {
    throw e instanceof Error ? e : new Error(String(e));
  }
}

async function insertSvg(item, options) {
  const path = pathFor(item, options.variant, "svg");
  if (!path) return insertPng(item, options);
  const svg = await fetchText(path);
  const { w, h } = svgAspect(svg);
  const width = defaultWidth(item, options);
  const box = placement(width, width * h / w, item);
  // Preferred: PowerPointApi 1.8 addSvg on the active slide (keeps the SVG editable and lets us place it)
  if (caps().pptApi && isSet("PowerPointApi", "1.8")) {
    try {
      const done = await run(async (context) => {
        const { slide } = await getActiveSlide(context);
        if (!hasShapeApi(slide.shapes, "addSvg")) return false;
        const shape = slide.shapes.addSvg(svg, box);
        shape.name = `KSA ${item.name || "graphic"}`;
        await context.sync();
        if (item.category === "patterns") await sendToBack(context, shape);
        return true;
      });
      if (done) return "svg";
    } catch (e) { console.warn("addSvg failed, falling back to XmlSvg coercion", e); }
  }
  try { return await insertSvgAtSelection(svg, 1024); }
  catch (e) { throw new Error(`Could not insert the SVG: ${e.message || e}`); }
}

async function insertPng(item, options) {
  const png = pathFor(item, options.variant, "png");
  let base64;
  if (png) base64 = await fetchBase64(png);
  else {
    const svgPath = pathFor(item, options.variant, "svg");
    if (!svgPath) throw new Error("This item has no image to insert");
    base64 = await svgToPngBase64(await fetchText(svgPath), 1024);
  }
  const width = defaultWidth(item, options);
  const ratio = item.size?.w && item.size?.h ? item.size.h / item.size.w : (item.category === "patterns" ? 9 / 16 : 1);
  const box = placement(width, width * ratio, item);
  if (caps().pptApi && isSet("PowerPointApi", "1.8")) {
    try {
      const done = await run(async (context) => {
        const { slide } = await getActiveSlide(context);
        if (!hasShapeApi(slide.shapes, "addImage")) return false;
        const shape = slide.shapes.addImage(base64, box);
        shape.name = `KSA ${item.name || "image"}`;
        await context.sync();
        if (item.category === "patterns") await sendToBack(context, shape);
        return true;
      });
      if (done) return "png";
    } catch (e) { console.warn("addImage failed, falling back to Image coercion", e); }
  }
  try { return await insertPngAtSelection(base64); }
  catch (e) { throw new Error(`Could not insert the image: ${e.message || e}`); }
}

/** Insert slides from item.file after the current slide. Tries sourceSlideIds, then whole-file insert + delete. */
async function insertSlides(item, options) {
  if (!item.file || !/\.pptx$/i.test(item.file)) throw new Error("This item has no slide file to insert");
  if (!caps().pptSlides) throw new Error("Inserting slides needs PowerPoint 2021 or Microsoft 365");
  const base64 = await fetchBase64(item.file);
  const formatting = options.formatting || item.formatting || "KeepSourceFormatting";
  const ids = (item.sourceSlideIds || item.slideIds || []).map(String).filter(Boolean);
  const wanted = (item.slideIndex || []).map(Number).filter((n) => n >= 1);

  if (ids.length) {
    try {
      await run(async (context) => {
        const { id } = await getActiveSlide(context);
        context.presentation.insertSlidesFromBase64(base64, { formatting, sourceSlideIds: ids, targetSlideId: id });
        await context.sync();
      });
      return "slides";
    } catch (e) {
      console.warn("sourceSlideIds insert failed, inserting the whole file instead", e);
      if (!wanted.length) throw new Error(`Could not insert the slides: ${e.message}`);
    }
  }
  // Fallback: insert the whole file after the current slide and delete the slides we did not want.
  await run(async (context) => {
    const before = await getActiveSlide(context);
    context.presentation.insertSlidesFromBase64(base64, { formatting, targetSlideId: before.id });
    await context.sync();
    const slides = context.presentation.slides;
    slides.load("items/id");
    await context.sync();
    const added = slides.items.length - before.count;
    if (added <= 0 || !wanted.length) return;
    const keep = new Set(wanted);
    const victims = [];
    for (let j = 1; j <= added; j++) if (!keep.has(j)) victims.push(slides.items[before.index + j]);
    for (const s of victims) s.delete();
    if (victims.length) await context.sync();
  });
  return "slides";
}

const SHAPE_TYPES = { rectangle: "Rectangle", ellipse: "Ellipse", chevron: "Chevron", diamond: "Diamond", roundRectangle: "RoundRectangle", triangle: "Triangle", hexagon: "Hexagon", pentagon: "Pentagon", rightArrow: "RightArrow", parallelogram: "Parallelogram" };

/** Geometric shape, line or text box from item.spec. Sizes are points (or EMU/strings, see toPt). */
async function insertShape(item, options) {
  if (!caps().pptShapes) throw new Error("Adding shapes needs PowerPoint 2021 or Microsoft 365");
  const spec = { ...(item.spec || {}), ...(options.spec || {}) };
  const type = String(spec.shape || "rectangle");
  const w = toPt(spec.w, type === "line" ? 240 : 160), h = toPt(spec.h, type === "line" ? 0 : 96);
  const box = placement(w, h || 0.75, item);
  if (type === "line") box.height = Math.round(h);
  await run(async (context) => {
    const { slide } = await getActiveSlide(context);
    let shape;
    if (type === "line") {
      shape = slide.shapes.addLine(PowerPoint.ConnectorType.straight, box);
      shape.lineFormat.color = spec.line || spec.fill || C.slate;
      shape.lineFormat.weight = toPt(spec.lineWeight, 1.5);
      if (spec.dash) shape.lineFormat.dashStyle = spec.dash;
    } else if (type === "textbox") {
      shape = slide.shapes.addTextBox(spec.text || "[Text]", box);
      if (spec.fill) shape.fill.setSolidColor(spec.fill); else shape.fill.clear();
      shape.lineFormat.visible = false;
    } else {
      // PowerPoint.GeometricShapeType values are the plain strings ("Rectangle", "Chevron"…), so pass them directly.
      shape = slide.shapes.addGeometricShape(SHAPE_TYPES[type] || SHAPE_TYPES.rectangle, box);
      shape.fill.setSolidColor(spec.fill || C.water);
      if (spec.line) { shape.lineFormat.visible = true; shape.lineFormat.color = spec.line; shape.lineFormat.weight = toPt(spec.lineWeight, 1); }
      else shape.lineFormat.visible = false;
      if (spec.text) shape.textFrame.textRange.text = spec.text;
    }
    shape.name = `KSA ${item.name || type}`;
    if (type !== "line") {
      const font = shape.textFrame.textRange.font;
      font.name = spec.font || FONTS.heading;
      if (spec.fontSize || spec.size) font.size = toPt(spec.fontSize || spec.size, 14);
      font.color = spec.color || (type === "textbox" ? C.deep : C.white);
      if (spec.bold !== undefined) font.bold = !!spec.bold;
      if (spec.align) { try { shape.textFrame.textRange.paragraphFormat.horizontalAlignment = spec.align; } catch { /* optional */ } }
      try { shape.textFrame.verticalAlignment = spec.valign || "Middle"; } catch { /* optional */ }
    }
    await context.sync();
  });
  return "shape";
}

/* ---------- apply brand ---------- */
const TEXT_TYPES = new Set(["GeometricShape", "TextBox", "Callout", "Freeform", "Placeholder"]);

export async function applyBrand(preset = {}) {
  if (!preset || typeof preset !== "object") throw new Error("No preset given");
  if (preset.id === "chart") throw new Error("Use the Charts tab to insert a KSA-styled chart in PowerPoint");
  if (!caps().pptSelection) throw new Error("Applying styles to a selection needs Microsoft 365 PowerPoint");
  const onlyShadow = preset.shadow && !preset.fill && !preset.line && !preset.font && !preset.color && preset.id !== "ksa-theme";
  if (onlyShadow) throw new Error("Shadows are not available through the PowerPoint API yet. Use Shape Format > Shape Effects > Shadow");
  if (preset.shadow) console.info("KSA Toolbar: shadow presets are not supported by the PowerPoint API; applied the rest of the preset");

  await run(async (context) => {
    let shapes = context.presentation.getSelectedShapes();
    shapes.load("items/id,items/name,items/type");
    await context.sync();
    if (!shapes.items.length && preset.id === "ksa-theme") {
      const { slide } = await getActiveSlide(context);
      shapes = slide.shapes; shapes.load("items/id,items/name,items/type");
      await context.sync();
    }
    if (!shapes.items.length) throw new Error("Select one or more shapes first");
    let touched = 0; const problems = [];
    for (const shape of shapes.items) {
      try {
        if (preset.id === "ksa-theme") await themeShape(context, shape);
        else await styleShape(context, shape, preset);
        touched++;
      } catch (e) { problems.push(`${shape.name || shape.type}: ${readable(e)}`); }
    }
    if (!touched) throw new Error(problems[0] || "Nothing in the selection could be styled");
    if (problems.length) console.warn("KSA Toolbar: some shapes were skipped", problems);
  });
}

async function styleShape(context, shape, preset) {
  const textual = TEXT_TYPES.has(shape.type);
  if (shape.type === "Line") {
    if (preset.line) { shape.lineFormat.color = preset.line; if (preset.lineWeight) shape.lineFormat.weight = preset.lineWeight; }
    await context.sync(); return;
  }
  if (shape.type === "Image" || shape.type === "Group" || shape.type === "Table" || shape.type === "Chart") {
    if (preset.line) { shape.lineFormat.visible = true; shape.lineFormat.color = preset.line; shape.lineFormat.weight = preset.lineWeight || 1; }
    else if (preset.line === null && preset.fill) shape.lineFormat.visible = false;
    await context.sync(); return;
  }
  if (preset.fill) shape.fill.setSolidColor(preset.fill);
  if (preset.line) { shape.lineFormat.visible = true; shape.lineFormat.color = preset.line; shape.lineFormat.weight = preset.lineWeight || 1; }
  else if (preset.line === null) shape.lineFormat.visible = false;
  if (textual) {
    const font = shape.textFrame.textRange.font;
    if (preset.font) font.name = preset.font;
    if (preset.color) font.color = preset.color;
    if (preset.bold !== undefined) font.bold = !!preset.bold;
    if (preset.size) font.size = preset.size;
  }
  await context.sync();
}

async function themeShape(context, shape) {
  const textual = TEXT_TYPES.has(shape.type);
  if (shape.type === "Line") {
    shape.lineFormat.load("color"); await context.sync();
    const mapped = remapColour(shape.lineFormat.color);
    if (mapped && mapped !== C.deep) shape.lineFormat.color = mapped;
    await context.sync(); return;
  }
  if (!textual) return;
  shape.fill.load("type,foregroundColor");
  shape.lineFormat.load("visible,color");
  const font = shape.textFrame.textRange.font;
  font.load("name,color");
  await context.sync();
  if (shape.fill.type === "Solid") {
    const mapped = remapColour(shape.fill.foregroundColor);
    if (mapped && mapped !== C.deep) shape.fill.setSolidColor(mapped);
  }
  if (shape.lineFormat.visible) {
    const mapped = remapColour(shape.lineFormat.color);
    if (mapped) shape.lineFormat.color = mapped;
  }
  font.name = FONTS.heading;
  const fc = remapColour(font.color);
  if (fc) font.color = fc;
  await context.sync();
}

/* ---------- templates ---------- */
export async function newFromTemplate(item) {
  if (!item?.file || !/\.pptx$/i.test(item.file)) throw new Error("This template is not a PowerPoint file");
  if (!caps().pptSlides) throw new Error("Inserting slides needs PowerPoint 2021 or Microsoft 365");
  const base64 = await fetchBase64(item.file);
  await run(async (context) => {
    const slides = context.presentation.slides;
    slides.load("items/id");
    await context.sync();
    const opts = { formatting: "KeepSourceFormatting" };
    if (slides.items.length) opts.targetSlideId = slides.items[slides.items.length - 1].id;
    context.presentation.insertSlidesFromBase64(base64, opts);
    await context.sync();
  });
}
