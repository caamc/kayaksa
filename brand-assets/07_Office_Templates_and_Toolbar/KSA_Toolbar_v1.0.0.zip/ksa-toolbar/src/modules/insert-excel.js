/* insert-excel.js — Excel host module for the KSA Toolbar.
 *
 * Exports:
 *   insert(item, { kind, variant, size, spec })  → Promise<string>  "svg" | "png" | "chart" | "shape" | "table" | "rag" | "workbook"
 *       kinds: "svg" | "png" | "chart" | "shape" | "table" | "rag" | "template"
 *   applyBrand(preset)                           → Promise<void>    ids: "chart" (restyle selected/all charts), "table" (table at the
 *                                                                  selection), "ksa-theme" (fonts + tables + charts on the active sheet),
 *                                                                  anything else: fill/font/border on the selected range
 *   newFromTemplate(item)                        → Promise<void>    Excel.createWorkbook(base64) (ExcelApi 1.8), else throws so the
 *                                                                  router offers a download
 *   styleChart(context, chart, spec, info)       (inside Excel.run) KSA chart rules in capability tiers; info = { chartType, seriesCount }
 *   styleTable(context, table)                   (inside Excel.run) KSA table look in capability tiers
 *   CHART_TYPES                                  spec.chartType → Excel.ChartType value
 *   RAG_RULES                                    default "On track / At risk / Off track" conditional-format rules
 *   chartColours(chartType, seriesCount, spec)   → { series: [...], highlight } pure helper for the colour plan
 *
 * Every public function wraps Office calls in try/catch and throws a plain Error with a readable message.
 */
import { caps, fetchText, fetchBase64, svgToPngBase64 } from "./host.js";
import { C, DATA, FONTS } from "./brand.js";
import { svgAspect, toPt } from "./insert-ppt.js";

export const CHART_TYPES = {
  columnClustered: "ColumnClustered", columnStacked: "ColumnStacked", columnStacked100: "ColumnStacked100",
  barClustered: "BarClustered", barStacked: "BarStacked", line: "Line", lineMarkers: "LineMarkers",
  doughnut: "Doughnut", area: "Area", areaStacked: "AreaStacked", scatter: "XYScatter", xyscatter: "XYScatter",
};
const TINT = { kelp: "#E4EEE4", gold: "#FBEBCD", clay: "#F6DED8" };
export const RAG_RULES = [
  { text: "On track", fill: TINT.kelp, color: C.kelp },
  { text: "Complete", fill: TINT.kelp, color: C.kelp },
  { text: "Green", fill: TINT.kelp, color: C.kelp },
  { text: "At risk", fill: TINT.gold, color: C.gold },
  { text: "Amber", fill: TINT.gold, color: C.gold },
  { text: "Off track", fill: TINT.clay, color: C.clay },
  { text: "Red", fill: TINT.clay, color: C.clay },
];
const FONT = { axis: { name: FONTS.heading, size: 10, color: C.slate }, title: { name: FONTS.heading, size: 12, bold: true, color: C.deep } };

/* ---------- plumbing ---------- */
function isSet(name, version) {
  try { return !!(Office?.context?.requirements?.isSetSupported(name, version)); } catch { return false; }
}
function readable(e) {
  const code = e?.code || e?.name || "";
  const known = {
    ApiNotFound: "This feature is not available in your version of Excel",
    ApiNotAvailable: "This feature is not available in your version of Excel",
    InvalidArgument: "Excel rejected one of the values (check the selection)",
    ItemNotFound: "The selection could not be found",
    ItemAlreadyExists: "There is already a table here",
    AccessDenied: "Excel did not allow this action (the sheet may be protected)",
    InvalidSelection: "Select a range of cells first",
    GeneralException: "Excel reported a general error",
  };
  return known[code] || e?.message || String(e);
}
async function run(fn) {
  if (typeof Excel === "undefined" || !caps().excelApi) throw new Error("This needs Excel 2016 or Microsoft 365");
  try { return await Excel.run(fn); }
  catch (e) { throw new Error(readable(e)); }
}
function pathFor(item, variant, kind) {
  const f = item.formats || {};
  if (kind === "png") return (variant && f.pngVariants?.[variant]) || f.png || null;
  return (variant && f.svgVariants?.[variant]) || f.svg || null;
}
function defaultWidth(item, options) {
  if (options.size) return toPt(options.size, 96);
  const cat = item.category || "";
  if (cat === "logo") return /monogram|identifier|app/i.test(item.name || "") ? 48 : 160;
  if (cat === "icons" || cat === "industry-icons") return 40;
  const w = toPt(item.size?.w, 0);
  return w > 0 ? Math.min(w, 480) : 160;
}
/** The selected range with its geometry loaded; single cells grow to the surrounding region when `expand` is set. */
async function selection(context, expand = false) {
  let range = context.workbook.getSelectedRange();
  range.load("address,rowCount,columnCount");
  await context.sync();
  if (expand && range.rowCount * range.columnCount === 1 && isSet("ExcelApi", "1.7")) {
    range = range.getSurroundingRegion();
    range.load("address,rowCount,columnCount");
    await context.sync();
  }
  if (isSet("ExcelApi", "1.7")) { range.load("left,top,width,height"); await context.sync(); }
  return range;
}

/* ---------- insert ---------- */
export async function insert(item, options = {}) {
  const kind = options.kind || "svg";
  try {
    switch (kind) {
      case "svg": return await insertSvg(item, options);
      case "png": return await insertPng(item, options);
      case "chart": return await insertChart(item, options);
      case "shape": return await insertShape(item, options);
      case "table": return await insertTable(item, options);
      case "rag": return await insertRag(item, options);
      case "template": await newFromTemplate(item); return "workbook";
      default: throw new Error(`Excel cannot insert "${kind}" items`);
    }
  } catch (e) {
    throw e instanceof Error ? e : new Error(String(e));
  }
}

async function insertSvg(item, options) {
  const path = pathFor(item, options.variant, "svg");
  if (!path) return insertPng(item, options);
  if (!caps().excelShapes) return insertPng(item, options);
  const svg = await fetchText(path);
  const { w, h } = svgAspect(svg);
  const width = defaultWidth(item, options);
  try {
    await run(async (context) => {
      const sheet = context.workbook.worksheets.getActiveWorksheet();
      const range = await selection(context);
      const shape = sheet.shapes.addSvg(svg);
      shape.name = `KSA ${item.name || "graphic"}`;
      shape.width = width; shape.height = width * h / w;
      shape.left = Number(range.left) || 0; shape.top = Number(range.top) || 0;
      shape.lockAspectRatio = true;
      await context.sync();
    });
    return "svg";
  } catch (e) {
    console.warn("addSvg failed, inserting PNG instead", e);
    return insertPng(item, options);
  }
}

async function insertPng(item, options) {
  if (!caps().excelShapes) throw new Error("Inserting pictures needs Excel 2021 or Microsoft 365");
  const png = pathFor(item, options.variant, "png");
  let base64, ratio = item.size?.w && item.size?.h ? item.size.h / item.size.w : 1;
  if (png) base64 = await fetchBase64(png);
  else {
    const svgPath = pathFor(item, options.variant, "svg");
    if (!svgPath) throw new Error("This item has no image to insert");
    const svg = await fetchText(svgPath);
    const a = svgAspect(svg); ratio = a.h / a.w;
    base64 = await svgToPngBase64(svg, 1024);
  }
  const width = defaultWidth(item, options);
  await run(async (context) => {
    const sheet = context.workbook.worksheets.getActiveWorksheet();
    const range = await selection(context);
    const shape = sheet.shapes.addImage(base64);
    shape.name = `KSA ${item.name || "image"}`;
    shape.width = width; shape.height = width * ratio;
    shape.left = Number(range.left) || 0; shape.top = Number(range.top) || 0;
    shape.lockAspectRatio = true;
    await context.sync();
  });
  return "png";
}

/* ---------- charts ---------- */
/** Colour plan: single series = Open Water (+ Saffron on the last point when highlightLast); multi = categorical order. */
export function chartColours(chartType, seriesCount, spec = {}) {
  const type = String(chartType || "");
  const categorical = DATA.categorical;
  if (/doughnut|pie/i.test(type)) return { series: [DATA.primary], points: categorical, highlight: spec.highlightLast ? DATA.highlight : null, byPoint: true };
  if (seriesCount <= 1) return { series: [DATA.primary], highlight: spec.highlightLast ? DATA.highlight : null, byPoint: !!spec.highlightLast };
  const series = Array.from({ length: seriesCount }, (_, i) => categorical[i % categorical.length]);
  if (spec.highlightLast) series[seriesCount - 1] = DATA.highlight;
  return { series, highlight: spec.highlightLast ? DATA.highlight : null, byPoint: false };
}

async function insertChart(item, options) {
  const spec = { ...(item.spec || {}), ...(options.spec || {}) };
  const type = CHART_TYPES[spec.chartType] || CHART_TYPES[String(spec.chartType || "").replace(/^[A-Z]/, (c) => c.toLowerCase())] || "ColumnClustered";
  await run(async (context) => {
    const sheet = context.workbook.worksheets.getActiveWorksheet();
    const range = await selection(context, true);
    if (range.rowCount * range.columnCount < 2) throw new Error("Select the data for the chart first (a header row plus values)");
    const chart = sheet.charts.add(type, range, spec.seriesBy || "Auto");
    chart.name = `KSA ${item.name || "chart"}`;
    chart.load("chartType"); chart.series.load("count");
    await context.sync();
    try {
      chart.height = toPt(spec.height, 260); chart.width = toPt(spec.width, 440);
      if (isSet("ExcelApi", "1.7") && Number.isFinite(range.left)) { chart.left = range.left + range.width + 16; chart.top = range.top; }
      await context.sync();
    } catch (e) { console.info("KSA Toolbar: chart placement skipped", readable(e)); }
    await styleChart(context, chart, { ...spec, title: spec.title ?? item.title ?? "" }, { chartType: chart.chartType, seriesCount: chart.series.count });
  });
  return "chart";
}

/** Apply the KSA chart rules in capability tiers (ExcelApi 1.1, then 1.7, then 1.8), one sync per tier so an
 * unsupported property on an older Excel never undoes the basics. Call inside Excel.run.
 * spec: { title, valueFormat, highlightLast, dataLabels, legend, zeroBaseline }  info: { chartType, seriesCount } */
export async function styleChart(context, chart, spec = {}, info = {}) {
  const type = String(info.chartType || spec.chartType || "");
  const n = Number(info.seriesCount) || 1;
  const round = /doughnut|pie/i.test(type);
  const line = /^line|scatter/i.test(type);
  const scatter = /scatter/i.test(type);
  const plan = chartColours(type, n, spec);
  const tier = async (name, fn) => {
    try { fn(); await context.sync(); }
    catch (e) { console.info(`KSA Toolbar: chart styling tier "${name}" skipped:`, readable(e)); }
  };
  const font = (f, t) => { f.name = t.name; f.size = t.size; f.color = t.color; if (t.bold) f.bold = true; };

  // Tier 1: ExcelApi 1.1
  await tier("basics", () => {
    chart.format.fill.setSolidColor(C.white);
    font(chart.format.font, FONT.axis);
    if (spec.title !== undefined && spec.title !== null && spec.title !== "") { chart.title.visible = true; chart.title.text = String(spec.title); }
    else if (spec.title === "") chart.title.visible = false;
    font(chart.title.format.font, FONT.title);
    const show = spec.legend !== undefined ? !!spec.legend : (n > 1 || round);
    chart.legend.visible = show;
    if (show) { chart.legend.position = "Bottom"; font(chart.legend.format.font, FONT.axis); }
    if (!round) {
      const v = chart.axes.valueAxis, c = chart.axes.categoryAxis;
      v.majorGridlines.visible = true; v.majorGridlines.format.line.color = DATA.grid; v.minorGridlines.visible = false;
      font(v.format.font, FONT.axis);
      if (spec.zeroBaseline !== false && !scatter) v.minimum = 0;
      c.majorGridlines.visible = false; c.format.line.color = DATA.benchmark;
      font(c.format.font, FONT.axis);
    }
    for (let i = 0; i < n; i++) {
      const series = chart.series.getItemAt(i);
      const colour = plan.series[i] || plan.series[plan.series.length - 1];
      if (line) series.format.line.color = colour; else series.format.fill.setSolidColor(colour);
    }
    chart.dataLabels.showValue = !!spec.dataLabels;
    if (spec.dataLabels) { font(chart.dataLabels.format.font, FONT.axis); if (!round) chart.dataLabels.position = "OutsideEnd"; }
  });

  // Tier 2: ExcelApi 1.7 (borders, line weights, markers, tick marks, gap width, doughnut hole)
  await tier("1.7", () => {
    chart.format.border.lineStyle = "None";
    chart.title.horizontalAlignment = "Left";
    chart.title.left = 0;
    if (!round) {
      const v = chart.axes.valueAxis, c = chart.axes.categoryAxis;
      v.majorGridlines.format.line.weight = 0.75;
      v.format.line.lineStyle = "None";
      v.majorTickMark = "None";
      c.format.line.weight = 1;
      c.majorTickMark = "None";
    }
    for (let i = 0; i < n; i++) {
      const series = chart.series.getItemAt(i);
      const colour = plan.series[i] || plan.series[plan.series.length - 1];
      if (scatter) { series.markerStyle = "Circle"; series.markerSize = 6; series.markerForegroundColor = colour; series.markerBackgroundColor = colour; series.format.line.lineStyle = "None"; }
      else if (line) { series.format.line.weight = 2; series.markerStyle = "None"; series.smooth = false; }
      else { series.format.line.lineStyle = "None"; if (/column|bar/i.test(type)) series.gapWidth = 60; }
      if (round) series.doughnutHoleSize = 82;
    }
  });

  // Tier 3: ExcelApi 1.8 (number formats)
  if (spec.valueFormat) {
    await tier("1.8", () => {
      if (!round) chart.axes.valueAxis.numberFormat = String(spec.valueFormat);
      if (spec.dataLabels) chart.dataLabels.numberFormat = String(spec.valueFormat);
    });
  }

  await colourPoints(context, chart, plan);
  return plan;
}

/** Point colours (doughnut slices, highlighted last bar) need the point count, so this runs after a sync. */
async function colourPoints(context, chart, plan) {
  if (!plan?.byPoint) return;
  try {
    const first = chart.series.getItemAt(0);
    const points = first.points; points.load("count");
    await context.sync();
    const count = points.count || 0;
    for (let i = 0; i < count; i++) {
      const p = points.getItemAt(i);
      let colour = plan.points ? plan.points[i % plan.points.length] : plan.series[0];
      if (plan.highlight && i === count - 1) colour = plan.highlight;
      p.format.fill.setSolidColor(colour);
    }
    await context.sync();
    if (plan.points) {
      try { for (let i = 0; i < count; i++) points.getItemAt(i).format.border.color = C.white; await context.sync(); }
      catch { /* ExcelApi 1.7 */ }
    }
  } catch (e) { console.info("KSA Toolbar: point colours skipped", readable(e)); }
}

/* ---------- shapes ---------- */
const SHAPE_TYPES = { rectangle: "Rectangle", ellipse: "Ellipse", chevron: "Chevron", diamond: "Diamond", roundRectangle: "RoundRectangle", triangle: "Triangle", hexagon: "Hexagon", rightArrow: "RightArrow" };

async function insertShape(item, options) {
  if (!caps().excelShapes) throw new Error("Adding shapes needs Excel 2021 or Microsoft 365");
  const spec = { ...(item.spec || {}), ...(options.spec || {}) };
  const type = String(spec.shape || "rectangle");
  const w = toPt(spec.w, type === "line" ? 200 : 160), h = toPt(spec.h, type === "line" ? 0 : 80);
  await run(async (context) => {
    const sheet = context.workbook.worksheets.getActiveWorksheet();
    const range = await selection(context);
    const left = Number(range.left) || 0, top = Number(range.top) || 0;
    let shape;
    if (type === "line") {
      shape = sheet.shapes.addLine(left, top, left + w, top + h, "Straight");
      shape.lineFormat.color = spec.line || spec.fill || C.slate; shape.lineFormat.weight = toPt(spec.lineWeight, 1.5);
      if (spec.dash) shape.lineFormat.dashStyle = spec.dash;
    } else if (type === "textbox") {
      shape = sheet.shapes.addTextBox(spec.text || "[Text]");
      shape.left = left; shape.top = top; shape.width = w; shape.height = h;
      if (spec.fill) shape.fill.setSolidColor(spec.fill); else shape.fill.clear();
      shape.lineFormat.visible = false;
    } else {
      shape = sheet.shapes.addGeometricShape(SHAPE_TYPES[type] || SHAPE_TYPES.rectangle);
      shape.left = left; shape.top = top; shape.width = w; shape.height = h;
      shape.fill.setSolidColor(spec.fill || C.water);
      if (spec.line) { shape.lineFormat.visible = true; shape.lineFormat.color = spec.line; shape.lineFormat.weight = toPt(spec.lineWeight, 1); }
      else shape.lineFormat.visible = false;
      if (spec.text) shape.textFrame.textRange.text = spec.text;
    }
    shape.name = `KSA ${item.name || type}`;
    if (type !== "line") {
      const font = shape.textFrame.textRange.font;
      font.name = spec.font || FONTS.heading;
      font.size = toPt(spec.fontSize || spec.size, 12);
      font.color = spec.color || (type === "textbox" ? C.deep : C.white);
      if (spec.bold !== undefined) font.bold = !!spec.bold;
      try { shape.textFrame.verticalAlignment = spec.valign || "Middle"; shape.textFrame.horizontalAlignment = spec.align || "Center"; } catch { /* optional */ }
    }
    await context.sync();
  });
  return "shape";
}

/* ---------- tables ---------- */
async function insertTable(item, options) {
  const spec = { ...(item.spec || {}), ...(options.spec || {}) };
  await run(async (context) => {
    const sheet = context.workbook.worksheets.getActiveWorksheet();
    const range = await selection(context, true);
    const existing = await tableAt(context, sheet, range);
    if (existing) { await styleTable(context, existing); return; }
    if (range.rowCount < 2) throw new Error("Select at least a header row and one data row");
    const table = sheet.tables.add(range, spec.hasHeaders !== false);
    await context.sync();
    await styleTable(context, table);
  });
  return "table";
}

/** Table styling in tiers (ExcelApi 1.1 → 1.3 → 1.9): Deep Current header, white bold Archivo; Storm Slate body;
 * Fog hairline borders; no banding, no filter buttons. Call inside Excel.run. */
export async function styleTable(context, table) {
  const tier = async (name, fn) => {
    try { fn(); await context.sync(); }
    catch (e) { console.info(`KSA Toolbar: table styling tier "${name}" skipped:`, readable(e)); }
  };
  await tier("basics", () => {
    table.style = "TableStyleLight1";
    const h = table.getHeaderRowRange();
    h.format.fill.color = C.deep; h.format.font.color = C.white; h.format.font.bold = true; h.format.font.name = FONTS.heading; h.format.font.size = 10;
    h.format.verticalAlignment = "Center";
    const b = table.getDataBodyRange();
    b.format.font.name = FONTS.heading; b.format.font.color = C.slate; b.format.font.size = 10; b.format.fill.clear();
    const all = table.getRange();
    for (const loc of ["EdgeTop", "EdgeBottom", "EdgeLeft", "EdgeRight", "InsideHorizontal", "InsideVertical"]) {
      const border = all.format.borders.getItem(loc); border.style = "Continuous"; border.color = C.fog; border.weight = "Thin";
    }
  });
  await tier("1.3", () => { table.showBandedRows = false; table.showBandedColumns = false; });
  await tier("1.9", () => { table.showFilterButton = false; });
}

async function tableAt(context, sheet, range) {
  try {
    const tables = sheet.tables; tables.load("items/name");
    await context.sync();
    if (!tables.items.length) return null;
    const probes = tables.items.map((t) => { const i = range.getIntersectionOrNullObject(t.getRange()); i.load("isNullObject"); return i; });
    await context.sync();
    const idx = probes.findIndex((p) => !p.isNullObject);
    return idx >= 0 ? tables.items[idx] : null;
  } catch { return null; }
}

/* ---------- RAG conditional formatting ---------- */
async function insertRag(item, options) {
  const spec = { ...(item.spec || {}), ...(options.spec || {}) };
  const rules = Array.isArray(spec.rules) && spec.rules.length ? spec.rules : RAG_RULES;
  await run(async (context) => {
    const range = await selection(context);
    if (spec.replace !== false) { try { range.conditionalFormats.clearAll(); } catch { /* optional */ } }
    for (const r of rules) {
      if (r.text) {
        const cf = range.conditionalFormats.add("ContainsText");
        cf.textComparison.format.fill.color = r.fill;
        cf.textComparison.format.font.color = r.color;
        if (r.bold) cf.textComparison.format.font.bold = true;
        cf.textComparison.rule = { operator: r.operator || "Contains", text: String(r.text) };
      } else if (r.formula1 !== undefined) {
        const cf = range.conditionalFormats.add("CellValue");
        cf.cellValue.format.fill.color = r.fill;
        cf.cellValue.format.font.color = r.color;
        cf.cellValue.rule = { formula1: String(r.formula1), formula2: r.formula2 !== undefined ? String(r.formula2) : undefined, operator: r.operator || "EqualTo" };
      }
    }
    range.format.font.name = FONTS.heading;
    await context.sync();
  });
  return "rag";
}

/* ---------- apply brand ---------- */
export async function applyBrand(preset = {}) {
  if (!preset || typeof preset !== "object") throw new Error("No preset given");
  if (preset.shadow && !preset.fill && !preset.font && !preset.color) throw new Error("Shadows are not available through the Excel API. Use Shape Format > Shape Effects");
  if (preset.id === "chart") return brandCharts();
  if (preset.id === "table") return brandTable();
  if (preset.id === "ksa-theme") return brandSheet();
  await run(async (context) => {
    const range = await selection(context);
    const f = range.format;
    const spec = preset.id === "headline" ? { font: FONTS.heading, color: C.deep, bold: true, size: 20 }
      : preset.id === "standfirst" ? { font: FONTS.serif, color: C.slate, size: 12, bold: false }
      : preset;
    if (spec.fill) f.fill.color = spec.fill;
    if (spec.font) f.font.name = spec.font;
    if (spec.size) f.font.size = spec.size;
    if (spec.color) f.font.color = spec.color;
    if (spec.bold !== undefined) f.font.bold = !!spec.bold;
    if (spec.line) {
      for (const loc of ["EdgeTop", "EdgeBottom", "EdgeLeft", "EdgeRight"]) { const b = f.borders.getItem(loc); b.style = "Continuous"; b.color = spec.line; b.weight = "Thin"; }
    }
    if (preset.id === "headline" || preset.id === "standfirst") { try { f.verticalAlignment = "Center"; } catch { /* optional */ } }
    await context.sync();
  });
}

async function brandCharts() {
  await run(async (context) => {
    const wb = context.workbook;
    let charts = [];
    if (isSet("ExcelApi", "1.9") && typeof wb.getActiveChartOrNullObject === "function") {
      try { const c = wb.getActiveChartOrNullObject(); c.load("isNullObject"); await context.sync(); if (!c.isNullObject) charts = [c]; } catch { charts = []; }
    }
    if (!charts.length) {
      const coll = wb.worksheets.getActiveWorksheet().charts; coll.load("items/name"); await context.sync(); charts = coll.items;
    }
    if (!charts.length) throw new Error("Select a chart first, or add one from the Charts tab");
    await restyleCharts(context, charts);
  });
}
async function restyleCharts(context, charts) {
  for (const chart of charts) {
    chart.load("chartType"); chart.series.load("count"); chart.title.load("visible,text");
  }
  await context.sync();
  for (const chart of charts) {
    const spec = { title: chart.title.visible ? chart.title.text : "", highlightLast: false };
    await styleChart(context, chart, spec, { chartType: chart.chartType, seriesCount: chart.series.count });
  }
}

async function brandTable() {
  await run(async (context) => {
    const sheet = context.workbook.worksheets.getActiveWorksheet();
    const range = await selection(context);
    const table = await tableAt(context, sheet, range);
    if (!table) throw new Error("Select a cell inside a table first, or insert a KSA table from the library");
    await styleTable(context, table);
  });
}

/** "ksa-theme": Archivo on the used range, header styling when the first row is bold, KSA look on every table and chart. */
async function brandSheet() {
  await run(async (context) => {
    const sheet = context.workbook.worksheets.getActiveWorksheet();
    const used = sheet.getUsedRangeOrNullObject();
    used.load("isNullObject,rowCount");
    await context.sync();
    if (used.isNullObject) throw new Error("The active sheet is empty");
    used.format.font.name = FONTS.heading;
    const first = used.getRow(0);
    first.load("format/font/bold");
    await context.sync();
    if (first.format.font.bold === true) {
      first.format.fill.color = C.deep; first.format.font.color = C.white; first.format.font.bold = true;
    }
    await context.sync();
    try {
      const tables = sheet.tables; tables.load("items/name"); await context.sync();
      for (const t of tables.items) await styleTable(context, t);
    } catch (e) { console.info("KSA Toolbar: tables skipped", readable(e)); }
    try {
      const charts = sheet.charts; charts.load("items/name"); await context.sync();
      if (charts.items.length) await restyleCharts(context, charts.items);
    } catch (e) { console.info("KSA Toolbar: charts skipped", readable(e)); }
  });
}

/* ---------- templates ---------- */
export async function newFromTemplate(item) {
  if (!item?.file || !/\.(xlsx|xltx|xlsm)$/i.test(item.file)) throw new Error("This template is not an Excel file");
  if (!caps().excelCreateWb || typeof Excel === "undefined" || typeof Excel.createWorkbook !== "function") {
    throw new Error("Creating a workbook needs Excel 2019 or Microsoft 365");
  }
  const base64 = await fetchBase64(item.file);
  try { await Excel.createWorkbook(base64); }
  catch (e) { throw new Error(`Could not open the template: ${readable(e)}`); }
}
