/* insert.js — routes an insert request to the right host module. Every host module exports:
 *   insert(item, options) → Promise<string>   (options: { variant, formatting, size })
 *   applyBrand(preset)   → Promise<void>      (apply KSA styling to the current selection)
 *   newFromTemplate(item)→ Promise<void>      (open/insert a whole template)
 * When a host cannot insert a kind, it throws; this router falls back to download/copy. */
import { host, isOffice, toast, download, copyText, fetchText } from "./host.js";

const loaders = {
  powerpoint: () => import("./insert-ppt.js"),
  word: () => import("./insert-word.js"),
  excel: () => import("./insert-excel.js"),
  outlook: () => import("./insert-outlook.js"),
};

export async function hostModule() {
  const h = host();
  if (!isOffice() || !loaders[h]) return null;
  return loaders[h]();
}

export function kindFor(item) {
  const h = host();
  const k = item.insert?.[h] || item.insert?.default;
  return k || (item.formats?.svg ? "svg" : item.formats?.png ? "png" : "download");
}

export async function insertItem(item, options = {}) {
  const mod = await hostModule();
  if (!mod) return fallback(item, options);
  try {
    const how = await mod.insert(item, { kind: kindFor(item), ...options });
    toast(`Inserted ${item.name}${how && how !== "ok" ? " (" + how + ")" : ""}`, "ok");
    return how;
  } catch (e) {
    console.warn("insert failed, falling back", e);
    toast(`${e.message || "Could not insert here"}. Offering a download instead.`, "error", 3600);
    return fallback(item, options);
  }
}

export async function fallback(item, options = {}) {
  const v = options.variant;
  const path = (v && item.formats?.svgVariants?.[v]) || item.file || item.formats?.svg || item.formats?.png || item.preview;
  if (!path) { toast("Nothing to download for this item", "error"); return "none"; }
  if (options.copy && /\.svg$/i.test(path)) { await copyText(await fetchText(path)); return "copied"; }
  await download(path, `${item.id}${path.slice(path.lastIndexOf("."))}`);
  return "downloaded";
}

export async function applyBrand(preset) {
  const mod = await hostModule();
  if (!mod?.applyBrand) { toast("Select something in PowerPoint, Word or Excel to apply KSA styling", "error"); return; }
  try { await mod.applyBrand(preset); toast("KSA styling applied", "ok"); }
  catch (e) { toast(e.message || "Nothing selected", "error"); }
}

export async function newFromTemplate(item) {
  const mod = await hostModule();
  if (!mod?.newFromTemplate) return fallback(item);
  try { await mod.newFromTemplate(item); toast(`${item.name} ready`, "ok"); }
  catch (e) { toast(`${e.message || "Could not open template"}. Downloading instead.`, "error"); return fallback(item); }
}
