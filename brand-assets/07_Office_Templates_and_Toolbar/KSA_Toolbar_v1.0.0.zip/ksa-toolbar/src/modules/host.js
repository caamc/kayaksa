/* host.js — host detection, capability flags and small UI utilities shared by every module. */

const state = { host: "hub", platform: "web", officeReady: false, caps: {} };

/** Resolve once Office.js is ready (or immediately when running outside Office, e.g. Teams tab / browser). */
export function ready() {
  return new Promise((resolve) => {
    if (typeof Office === "undefined" || !Office.onReady) { finish(null); return; }
    const timer = setTimeout(() => finish(null), 4000); // Office.js present but no host (plain browser)
    Office.onReady((info) => { clearTimeout(timer); finish(info); });
    function finish(info) {
      if (info && info.host) {
        state.officeReady = true;
        state.host = String(info.host).toLowerCase(); // powerpoint | word | excel | outlook
        state.platform = String(info.platform || "web").toLowerCase();
      } else {
        state.host = "hub";
      }
      state.caps = computeCaps();
      document.getElementById("app")?.setAttribute("data-host", state.host);
      resolve(state);
    }
  });
}

export function host() { return state.host; }
export function isOffice() { return state.officeReady; }
export function caps() { return state.caps; }

function isSet(name, version) {
  try { return !!(Office?.context?.requirements?.isSetSupported(name, version)); } catch { return false; }
}

function computeCaps() {
  const h = state.host;
  const c = {
    svgInsert: isSet("ImageCoercion", "1.2") && (h === "powerpoint" || h === "word"),
    imageInsert: isSet("ImageCoercion", "1.1") && h !== "outlook",
    pptApi: isSet("PowerPointApi", "1.1"),
    pptSlides: isSet("PowerPointApi", "1.2"),
    pptShapes: isSet("PowerPointApi", "1.4"),
    pptSelection: isSet("PowerPointApi", "1.5"),
    wordApi: isSet("WordApi", "1.1"),
    wordCreateDoc: isSet("WordApi", "1.3"),
    excelApi: isSet("ExcelApi", "1.1"),
    excelShapes: isSet("ExcelApi", "1.9"),
    excelCreateWb: isSet("ExcelApi", "1.8"),
    mailbox: isSet("Mailbox", "1.1"),
    mailboxSignature: isSet("Mailbox", "1.10"),
    dialog: isSet("DialogApi", "1.1"),
    openBrowser: isSet("OpenBrowserWindowApi", "1.1"),
  };
  return c;
}

/* ---------- UI helpers ---------- */
let toastTimer;
export function toast(message, kind = "info", ms = 2600) {
  const el = document.getElementById("toast");
  if (!el) return;
  el.textContent = message;
  el.className = "toast show" + (kind === "error" ? " toast--error" : kind === "ok" ? " toast--ok" : "");
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.className = "toast"; }, ms);
}
export function setStatus(text) { const s = document.getElementById("status"); if (s) s.textContent = text; }

/** Fetch a relative asset as text. Paths in library.json are relative to ROOT (one level above /src). */
export async function fetchText(path) {
  const r = await fetch(resolve(path));
  if (!r.ok) throw new Error(`Could not load ${path} (${r.status})`);
  return r.text();
}
export async function fetchBase64(path) {
  const r = await fetch(resolve(path));
  if (!r.ok) throw new Error(`Could not load ${path} (${r.status})`);
  const buf = await r.arrayBuffer();
  let bin = ""; const bytes = new Uint8Array(buf);
  for (let i = 0; i < bytes.length; i += 0x8000) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000));
  return btoa(bin);
}
export function resolve(path) {
  if (/^https?:/i.test(path)) return path;
  return new URL("../" + path.replace(/^\.?\//, ""), document.baseURI).href;
}

/** Download a file (hub/browser mode, or as a fallback inside Office). */
export async function download(path, filename) {
  const url = resolve(path);
  if (isOffice() && caps().openBrowser) {
    try { Office.context.ui.openBrowserWindow(url); return; } catch { /* fall through */ }
  }
  const a = document.createElement("a");
  a.href = url; a.download = filename || path.split("/").pop(); a.target = "_blank"; a.rel = "noopener";
  document.body.appendChild(a); a.click(); a.remove();
}

export async function copyText(text) {
  try { await navigator.clipboard.writeText(text); toast("Copied to clipboard", "ok"); return true; }
  catch { toast("Copy is not available here", "error"); return false; }
}

/** Convert an SVG string to a PNG base64 (no data: prefix) at the given pixel width. */
export function svgToPngBase64(svgText, width = 512) {
  return new Promise((resolveP, reject) => {
    const img = new Image();
    const blob = new Blob([svgText], { type: "image/svg+xml;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    img.onload = () => {
      const ratio = img.naturalHeight && img.naturalWidth ? img.naturalHeight / img.naturalWidth : 1;
      const canvas = document.createElement("canvas");
      canvas.width = width; canvas.height = Math.round(width * ratio);
      canvas.getContext("2d").drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      resolveP(canvas.toDataURL("image/png").split(",")[1]);
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error("SVG could not be rasterised")); };
    img.src = url;
  });
}

/** Insert SVG at the selection using the host-neutral coercion API; falls back to PNG. */
export function insertSvgAtSelection(svgText, pngWidth = 512) {
  return new Promise(async (resolveP, reject) => {
    if (caps().svgInsert) {
      Office.context.document.setSelectedDataAsync(svgText, { coercionType: Office.CoercionType.XmlSvg }, async (res) => {
        if (res.status === Office.AsyncResultStatus.Succeeded) return resolveP("svg");
        try { resolveP(await insertPngAtSelection(await svgToPngBase64(svgText, pngWidth))); } catch (e) { reject(e); }
      });
      return;
    }
    try { resolveP(await insertPngAtSelection(await svgToPngBase64(svgText, pngWidth))); } catch (e) { reject(e); }
  });
}
export function insertPngAtSelection(base64) {
  return new Promise((resolveP, reject) => {
    if (!caps().imageInsert) return reject(new Error("Image insert is not supported in this host"));
    Office.context.document.setSelectedDataAsync(base64, { coercionType: Office.CoercionType.Image, imageWidth: 240 }, (res) => {
      res.status === Office.AsyncResultStatus.Succeeded ? resolveP("png") : reject(new Error(res.error?.message || "Insert failed"));
    });
  });
}

/* settings persisted per user */
const KEY = "ksa-toolbar-settings";
export function getSettings() { try { return JSON.parse(localStorage.getItem(KEY) || "{}"); } catch { return {}; } }
export function saveSettings(patch) { const s = { ...getSettings(), ...patch }; try { localStorage.setItem(KEY, JSON.stringify(s)); } catch { /* ignore */ } return s; }

export function el(tag, attrs = {}, children = []) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === "class") n.className = v;
    else if (k === "html") n.innerHTML = v;
    else if (k.startsWith("on") && typeof v === "function") n.addEventListener(k.slice(2), v);
    else if (v !== undefined && v !== null) n.setAttribute(k, v);
  }
  for (const c of [].concat(children)) if (c !== null && c !== undefined) n.append(c.nodeType ? c : document.createTextNode(String(c)));
  return n;
}
