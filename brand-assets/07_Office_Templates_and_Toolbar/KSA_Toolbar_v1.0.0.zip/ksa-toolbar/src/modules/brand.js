/* brand.js — KSA tokens shared by every host module. */
export const C = {
  deep: "#0E2F3C", water: "#17807E", saffron: "#EE9B1E", mist: "#EEF4F1", slate: "#3E5563", tide: "#2D6A9F", kelp: "#4B7A4E",
  sand: "#D8C5A1", clay: "#B4472F", river: "#8B9A9C", lagoon: "#0B5654", shallows: "#5DB2AB", spray: "#CDE8E3", gold: "#9C630E",
  dawn: "#F5C46D", haze: "#FBEBCD", undertow: "#1F4B5F", drizzle: "#7A96A3", fog: "#D4DEE2", plum: "#5E4B78", lichen: "#9AAD5A",
  coral: "#E2735C", white: "#FFFFFF", paper: "#FBFCFB", tealRev: "#3FB0A9",
};
export const PALETTE = [
  { name: "Deep Current", hex: C.deep }, { name: "Open Water", hex: C.water }, { name: "Beacon Saffron", hex: C.saffron }, { name: "Sea Mist", hex: C.mist },
  { name: "Storm Slate", hex: C.slate }, { name: "Tidewater Blue", hex: C.tide }, { name: "Kelp Green", hex: C.kelp }, { name: "Estuary Sand", hex: C.sand },
  { name: "Red Clay", hex: C.clay }, { name: "Riverstone", hex: C.river }, { name: "Deep Lagoon", hex: C.lagoon }, { name: "Shallows", hex: C.shallows },
  { name: "Spray", hex: C.spray }, { name: "Burnished Gold", hex: C.gold }, { name: "Dawn", hex: C.dawn }, { name: "Haze", hex: C.haze },
  { name: "Undertow", hex: C.undertow }, { name: "Drizzle", hex: C.drizzle }, { name: "Fog", hex: C.fog }, { name: "Dusk Plum", hex: C.plum },
  { name: "Lichen", hex: C.lichen }, { name: "Coral Flare", hex: C.coral },
];
export const CLUSTERS = [
  { id: 1, name: "Strategy, Deal & Transactions", short: "Strategy & Deals", hex: C.water, icon: "strategy" },
  { id: 2, name: "Tax & Regulatory", short: "Tax & Regulatory", hex: C.gold, icon: "regulatory" },
  { id: 3, name: "Crisis & Resilience", short: "Crisis & Resilience", hex: C.slate, icon: "risk" },
  { id: 4, name: "Technology & AI", short: "Technology & AI", hex: C.tide, icon: "technology" },
  { id: 5, name: "Managed Services", short: "Managed Services", hex: C.kelp, icon: "briefcase" },
  { id: 6, name: "International Desk", short: "International Desk", hex: C.plum, icon: "globe" },
];
export const DATA = {
  primary: C.water, highlight: C.saffron, context: C.river, grid: C.fog, benchmark: C.slate,
  categorical: [C.water, C.tide, C.kelp, C.slate, C.sand, C.plum, C.shallows, C.lichen],
  sequential: [C.spray, C.shallows, C.water, C.lagoon, C.deep],
  warm: [C.haze, C.dawn, C.saffron, C.gold],
  diverging: [C.clay, C.coral, C.fog, C.shallows, C.water],
  risk: [C.kelp, C.lichen, C.dawn, C.saffron, C.coral, C.clay],
};
export const FONTS = { heading: "Archivo", body: "Archivo", serif: "Source Serif 4", fallbackSans: "Arial", fallbackSerif: "Georgia" };
export const THEME = { dk1: C.deep, lt1: C.white, dk2: C.slate, lt2: C.mist, accent1: C.water, accent2: C.saffron, accent3: C.tide, accent4: C.kelp, accent5: C.gold, accent6: C.plum, hlink: C.lagoon, folHlink: C.plum };

/* Effect / brand presets understood by every host's applyBrand(preset) */
export const BRAND_PRESETS = {
  default: { id: "ksa-default", fill: C.mist, line: null, font: FONTS.heading, color: C.deep },
  theme: { id: "ksa-theme" },
  card: { id: "card", fill: C.white, line: C.fog, lineWeight: 1, font: FONTS.heading, color: C.deep, shadow: "e1" },
  cardDark: { id: "card-dark", fill: C.deep, line: null, font: FONTS.heading, color: C.white },
  beacon: { id: "beacon", fill: C.saffron, line: null, color: C.deep, font: FONTS.heading },
  headline: { id: "headline", font: FONTS.heading, color: C.deep, bold: true, size: 28 },
  standfirst: { id: "standfirst", font: FONTS.serif, color: C.slate, size: 16 },
  chart: { id: "chart" },
  table: { id: "table" },
  shadowE1: { id: "shadow", shadow: "e1" }, shadowE2: { id: "shadow", shadow: "e2" }, shadowE3: { id: "shadow", shadow: "e3" },
};
