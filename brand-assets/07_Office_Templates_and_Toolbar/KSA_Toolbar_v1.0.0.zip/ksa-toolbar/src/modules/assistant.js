/* assistant.js — KSA Assistant: chat UI, Office context capture and structured actions.
 * render(container, ctx). Talks to the proxy in server/ (POST {assistantUrl}/chat). Nothing is rendered with innerHTML
 * from model output: replies are escaped as text nodes and the markdown-lite is converted into DOM here. */
import { el, toast, getSettings, caps, host, isOffice } from "./host.js";
import { run as runAction, labelFor, allowedHere } from "./assistant-actions.js";

const MAX_TURNS = 20;            // user+assistant pairs kept in memory and sent
const REQUEST_TIMEOUT_MS = 60000;
const EXCEL_MAX_ROWS = 500, EXCEL_MAX_COLS = 30;
const WORD_BODY_CHARS = 2000, OUTLOOK_BODY_CHARS = 4000, PPT_SHAPE_CHARS = 4000;

const PROMPTS = {
  excel: ["Summarise this data", "Chart this with one highlight", "Find outliers", "Build a RAG scorecard"],
  powerpoint: ["Write an action title for this slide", "Turn this table into an exhibit", "Tighten this text"],
  word: ["Summarise into three bullets", "Write a standfirst", "Draft an executive summary"],
  outlook: ["Draft a reply", "Make this shorter"],
  hub: ["What can the assistant do?", "How do I deploy the proxy?"],
};
const HOST_NAMES = { excel: "Excel", powerpoint: "PowerPoint", word: "Word", outlook: "Outlook", hub: "KSA Hub" };

/* Conversation lives for the task-pane session (module scope survives tab changes). */
const session = { messages: [], include: true, context: null, busy: false, demo: false };

export async function render(container, ctx) {
  const h = ctx.host || host();
  const settings = getSettings();
  const endpoint = String(settings.assistantUrl || "").trim().replace(/\/+$/, "");
  session.demo = !endpoint;

  const root = el("div", { class: "chat" });
  container.append(root);

  if (session.demo) root.append(setupCard(ctx));

  /* ---- context strip ---- */
  const ctxText = el("span", {}, "Reading context…");
  const includeBox = el("input", { type: "checkbox", id: "chatInclude" });
  includeBox.checked = session.include;
  includeBox.addEventListener("change", () => { session.include = includeBox.checked; paintContext(); });
  const refreshBtn = el("button", { class: "btn btn--ghost btn--sm", type: "button", onclick: () => refreshContext(true) }, "Refresh");
  root.append(el("div", { class: "chat__context" }, [
    ctxText,
    el("span", { style: "display:inline-flex;gap:6px;align-items:center;flex:0 0 auto" }, [
      el("label", { class: "switch", for: "chatInclude", title: "Send the selection with your question" }, [includeBox, "Include"]),
      refreshBtn,
    ]),
  ]));

  /* ---- suggested prompts ---- */
  const chips = el("div", { class: "chips", style: "margin:0 0 8px" });
  for (const p of PROMPTS[h] || PROMPTS.hub) chips.append(el("button", { class: "chip", type: "button", onclick: () => send(p) }, p));
  root.append(chips);

  /* ---- log ---- */
  const log = el("div", { class: "chat__log", role: "log", "aria-live": "polite" });
  root.append(log);
  if (!session.messages.length) {
    addSys(`Ask about the data or text you have selected in ${HOST_NAMES[h] || "Office"}. Replies can include one-click actions.`);
  } else {
    for (const m of session.messages) addMessage(m.role, m.content, m.actions);
  }

  /* ---- composer ---- */
  const input = el("textarea", { rows: "2", placeholder: "Ask the KSA Assistant…", "aria-label": "Message", style: "flex:1;min-height:40px;max-height:120px;padding:8px 10px;border:1px solid var(--line);border-radius:var(--radius-sm);resize:vertical;font:inherit" });
  input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey) { e.preventDefault(); send(input.value); } });
  const sendBtn = el("button", { class: "btn btn--primary", type: "button", onclick: () => send(input.value) }, "Send");
  const clearBtn = el("button", { class: "btn btn--ghost btn--sm", type: "button", title: "Clear the conversation", onclick: clear }, "Clear");
  root.append(el("div", { class: "chat__composer" }, [input, el("div", { style: "display:flex;flex-direction:column;gap:6px" }, [sendBtn, clearBtn])]));

  await refreshContext(false);

  /* ---------- behaviour ---------- */
  async function refreshContext(announce) {
    refreshBtn.disabled = true;
    ctxText.textContent = "Reading context…";
    try { session.context = await readContext(h); }
    catch (e) { console.warn("context read failed", e); session.context = { kind: "none", label: "Could not read the selection" }; }
    refreshBtn.disabled = false;
    paintContext();
    if (announce) toast("Context refreshed", "ok", 1200);
  }
  function paintContext() {
    const c = session.context || { label: "No document context" };
    ctxText.textContent = session.include ? c.label : `Not sending context (${c.label})`;
    ctxText.title = session.include ? "This is sent with your next message" : "Tick Include to send the selection";
  }

  function addSys(text) { const n = el("div", { class: "msg msg--sys" }, text); log.append(n); scroll(); return n; }
  function addMessage(role, content, actions) {
    const n = el("div", { class: "msg " + (role === "user" ? "msg--user" : "msg--bot") });
    if (role === "user") { n.textContent = content; }
    else { n.style.whiteSpace = "normal"; n.append(renderMarkdown(content)); if (actions?.length) n.append(actionBar(actions)); }
    log.append(n); scroll(); return n;
  }
  function actionBar(actions) {
    const bar = el("div", { class: "chat__actions" });
    for (const a of actions) {
      if (!allowedHere(a, h)) continue;
      const b = el("button", { class: "btn btn--secondary btn--sm", type: "button" }, labelFor(a));
      b.addEventListener("click", async () => { b.disabled = true; try { await runAction(a, { host: h }); } finally { b.disabled = false; } });
      bar.append(b);
    }
    if (!bar.childElementCount) return document.createDocumentFragment();
    return bar;
  }
  function scroll() { log.scrollTop = log.scrollHeight; }
  function clear() { session.messages = []; log.innerHTML = ""; addSys("Conversation cleared."); input.focus(); }

  async function send(text) {
    text = String(text || "").trim();
    if (!text || session.busy) return;
    session.busy = true; sendBtn.disabled = true; input.value = "";
    session.messages.push({ role: "user", content: text });
    addMessage("user", text);
    if (session.include && !session.context) await refreshContext(false);
    const typing = el("div", { class: "msg msg--bot" }, el("span", { class: "typing" }, [el("i"), el("i"), el("i")]));
    log.append(typing); scroll();
    try {
      const payload = buildPayload(h, settings);
      const res = session.demo ? await demoReply(text, h, session.context) : await callProxy(endpoint, settings.assistantToken, payload);
      typing.remove();
      const actions = (res.actions || []).filter((a) => a && typeof a.type === "string");
      session.messages.push({ role: "assistant", content: res.reply, actions });
      trim();
      addMessage("assistant", res.reply, actions);
      if (res.usage?.input_tokens) setUsage(res.usage);
    } catch (e) {
      typing.remove();
      console.warn("assistant request failed", e);
      session.messages.pop(); // let the user retry the same question
      addSys(`Could not get a reply: ${e.message || e}`);
      toast(e.message || "The assistant is unavailable", "error", 3600);
      input.value = text;
    } finally {
      session.busy = false; sendBtn.disabled = false; input.focus();
    }
  }
  function trim() {
    const max = MAX_TURNS * 2;
    if (session.messages.length > max) session.messages = session.messages.slice(session.messages.length - max);
  }
  function setUsage(u) { const s = document.getElementById("status"); if (s) s.textContent = `Assistant: ${u.input_tokens} in / ${u.output_tokens} out tokens`; }
}

/* ---------- setup card (no endpoint configured) ---------- */
function setupCard(ctx) {
  const card = el("div", { class: "detail", style: "margin-bottom:10px" });
  card.append(el("h2", {}, "Connect the KSA Assistant"));
  card.append(el("p", {}, "The assistant talks to a small proxy you deploy yourself (Cloudflare Worker or Azure Function), so the API key never sits in Office. Add its address in Settings."));
  card.append(el("p", { class: "hint" }, "Until then you are in demo mode: replies are canned, but every button and action works so you can try the flow."));
  const row = el("div", { class: "btnrow" });
  row.append(el("button", { class: "btn btn--primary btn--sm", type: "button", onclick: () => ctx.go("settings") }, "Open Settings"));
  row.append(el("a", { class: "btn btn--ghost btn--sm", href: "../docs/ASSISTANT.md", target: "_blank", rel: "noopener" }, "Read the setup guide"));
  card.append(row);
  return card;
}

/* ---------- request ---------- */
function buildPayload(h, settings) {
  const c = session.include ? session.context : null;
  const selection = { kind: c?.kind || "none" };
  if (c?.kind === "range") Object.assign(selection, { address: c.address, sheet: c.sheet, rowCount: c.rowCount, colCount: c.colCount, sampled: !!c.sampled, rows: c.rows });
  else if (c?.kind === "text") Object.assign(selection, { source: c.source, words: c.words, text: c.text });
  else if (c?.kind === "shapes") Object.assign(selection, { slide: c.slide, scope: c.scope, shapes: c.shapes, tables: c.tables });
  else if (c?.kind === "message") Object.assign(selection, { subject: c.subject, text: c.text });
  return {
    messages: session.messages.map((m) => ({ role: m.role, content: m.content })),
    context: { host: h, selection, settings: { userName: settings.userName || "" } },
    actions: true,
  };
}

async function callProxy(endpoint, token, payload) {
  const headers = { "Content-Type": "application/json" };
  if (token) headers.Authorization = "Bearer " + token;
  const ac = new AbortController();
  const timer = setTimeout(() => ac.abort(), REQUEST_TIMEOUT_MS);
  try {
    const r = await fetch(endpoint + "/chat", { method: "POST", headers, body: JSON.stringify(payload), signal: ac.signal });
    const data = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(data?.error?.message || `The assistant proxy returned ${r.status}`);
    if (typeof data.reply !== "string") throw new Error("The proxy sent an unexpected response");
    return { reply: data.reply, actions: Array.isArray(data.actions) ? data.actions : [], usage: data.usage };
  } catch (e) {
    if (e.name === "AbortError") throw new Error("The assistant took too long to answer. Please try again.");
    if (e instanceof TypeError) throw new Error("Could not reach the assistant proxy. Check the endpoint in Settings and that your origin is allowed.");
    throw e;
  } finally { clearTimeout(timer); }
}

/* ---------- document context (feature-detected per host) ---------- */
async function readContext(h) {
  if (!isOffice()) return { kind: "none", label: "No document context" };
  if (h === "excel" && caps().excelApi && typeof Excel !== "undefined") return readExcel();
  if (h === "word" && caps().wordApi && typeof Word !== "undefined") return readWord();
  if (h === "powerpoint" && typeof PowerPoint !== "undefined") return readPowerPoint();
  if (h === "outlook" && caps().mailbox) return readOutlook();
  return { kind: "none", label: "No document context" };
}

async function readExcel() {
  return Excel.run(async (c) => {
    let r = c.workbook.getSelectedRange();
    r.load("address,rowCount,columnCount,cellCount");
    await c.sync();
    if (r.cellCount === 1 && typeof r.getSurroundingRegion === "function") {
      try { const s = r.getSurroundingRegion(); s.load("address,rowCount,columnCount,cellCount"); await c.sync(); r = s; } catch { /* keep single cell */ }
    }
    const sampled = r.rowCount > EXCEL_MAX_ROWS || r.columnCount > EXCEL_MAX_COLS;
    const rows = Math.min(r.rowCount, EXCEL_MAX_ROWS), cols = Math.min(r.columnCount, EXCEL_MAX_COLS);
    const take = sampled ? r.getCell(0, 0).getResizedRange(rows - 1, cols - 1) : r;
    take.load("values");
    await c.sync();
    const full = r.address || "";
    const bang = full.lastIndexOf("!");
    const address = bang >= 0 ? full.slice(bang + 1) : full, sheet = bang >= 0 ? full.slice(0, bang).replace(/^'|'$/g, "") : "";
    const values = (take.values || []).map((row) => row.map((v) => (typeof v === "string" ? v.slice(0, 500) : v)));
    const label = `Selected range ${address}, ${r.rowCount} row${r.rowCount === 1 ? "" : "s"}` + (sampled ? ` (sampled: first ${rows} × ${cols} sent)` : "");
    return { kind: "range", address, sheet, rows: values, rowCount: r.rowCount, colCount: r.columnCount, sampled, label };
  });
}

async function readWord() {
  return Word.run(async (c) => {
    const sel = c.document.getSelection();
    sel.load("text");
    await c.sync();
    let text = String(sel.text || "").trim(), source = "selection";
    if (!text) {
      const b = c.document.body; b.load("text"); await c.sync();
      text = String(b.text || "").trim().slice(0, WORD_BODY_CHARS); source = "document";
    }
    const words = text ? text.split(/\s+/).length : 0;
    const label = source === "selection" ? `Selected text (${words} word${words === 1 ? "" : "s"})` : words ? `Start of document (${words} words, nothing selected)` : "Empty document";
    return { kind: "text", text, words, source, label };
  });
}

async function readPowerPoint() {
  if (!caps().pptSelection) return { kind: "none", label: "Selection reading needs PowerPointApi 1.5" };
  return PowerPoint.run(async (c) => {
    const selShapes = c.presentation.getSelectedShapes();
    selShapes.load("items/id,items/name,items/type");
    const selSlides = c.presentation.getSelectedSlides();
    selSlides.load("items/id");
    const all = c.presentation.slides;
    all.load("items/id");
    await c.sync();
    const slideNo = selSlides.items.length ? all.items.findIndex((s) => s.id === selSlides.items[0].id) + 1 : null;
    let items = selShapes.items, scope = "selection";
    if (!items.length && selSlides.items.length) {
      const sh = selSlides.items[0].shapes; sh.load("items/id,items/name,items/type"); await c.sync();
      items = sh.items; scope = "slide";
    }
    const shapes = [], tables = [];
    for (const s of items.slice(0, 40)) {
      const type = String(s.type || "");
      if (/table/i.test(type) && typeof s.getTable === "function") {
        try { const t = s.getTable(); t.load("values"); await c.sync(); tables.push({ name: s.name, rows: t.values }); continue; } catch { /* fall through to text */ }
      }
      try {
        const tr = s.textFrame.textRange; tr.load("text"); await c.sync();
        const text = String(tr.text || "").trim();
        if (text) shapes.push({ name: s.name, type, text: text.slice(0, PPT_SHAPE_CHARS) });
        else if (/table/i.test(type)) tables.push({ name: s.name, rows: [] });
      } catch { /* pictures and groups have no text frame */ }
    }
    const where = slideNo ? `Slide ${slideNo}` : "Current slide";
    const label = `${where}: ${shapes.length} shape${shapes.length === 1 ? "" : "s"}, ${tables.length} table${tables.length === 1 ? "" : "s"}${scope === "selection" ? " (selected)" : ""}`;
    return { kind: "shapes", slide: slideNo, scope, shapes, tables, label };
  });
}

function readOutlook() {
  return new Promise((resolve) => {
    const item = Office.context?.mailbox?.item;
    if (!item?.body?.getAsync) return resolve({ kind: "none", label: "No message open" });
    const finish = (subject, text) => {
      const words = text ? text.split(/\s+/).length : 0;
      resolve({ kind: "message", subject, text, label: `Current message (${words} word${words === 1 ? "" : "s"})` });
    };
    const withSubject = (cb) => {
      if (typeof item.subject === "string") return cb(item.subject);
      if (item.subject?.getAsync) return item.subject.getAsync((r) => cb(r.status === Office.AsyncResultStatus.Succeeded ? String(r.value || "") : ""));
      cb("");
    };
    item.body.getAsync(Office.CoercionType.Text, (res) => {
      const text = res.status === Office.AsyncResultStatus.Succeeded ? String(res.value || "").trim().slice(0, OUTLOOK_BODY_CHARS) : "";
      withSubject((subject) => finish(subject, text));
    });
  });
}

/* ---------- demo mode (no endpoint): canned replies with one sample action per host ---------- */
async function demoReply(text, h, context) {
  await new Promise((r) => setTimeout(r, 500));
  const seen = context?.kind === "range" ? `I can see ${context.rowCount} rows × ${context.colCount} columns at ${context.address}.`
    : context?.kind === "text" ? `I can see ${context.words} words of ${context.source === "selection" ? "selected" : "document"} text.`
    : context?.kind === "shapes" ? `I can see ${context.shapes.length} text shape${context.shapes.length === 1 ? "" : "s"} and ${context.tables.length} table${context.tables.length === 1 ? "" : "s"} on the slide.`
    : context?.kind === "message" ? "I can see the open message." : "No document context is attached.";
  const reply = [
    `**Demo mode.** ${seen}`,
    "",
    "To get real answers, deploy the proxy in `server/cloudflare-worker` (or `server/azure-function`), then paste its URL into **Settings → Assistant endpoint**:",
    "",
    "1. `cd server/cloudflare-worker && npx wrangler login`",
    "2. `npx wrangler secret put ANTHROPIC_API_KEY`",
    "3. `npx wrangler deploy` and copy the `*.workers.dev` URL",
    "",
    "The proxy sends only what the context strip shows, stores nothing, and can be locked to your origin. See docs/ASSISTANT.md.",
    "",
    "Try the sample action below to see how actions work.",
  ].join("\n");
  const sample = {
    excel: { type: "excel.chart", chartType: "column", title: "[Insight headline: what the data shows]", highlight: 0 },
    powerpoint: { type: "ppt.title", text: "[Action title: the one-sentence takeaway of this slide]" },
    word: { type: "word.insert", style: "bullets", text: "- [First finding]\n- [Second finding]\n- [Recommended next step]" },
    outlook: { type: "outlook.insert", text: "Thank you for your note.\n\n[Reply]\n\nKind regards,\n[Full Name]" },
    hub: { type: "copy", text: "KSA Assistant demo: deploy the proxy to enable real replies." },
  };
  return { reply, actions: [sample[h] || sample.hub] };
}

/* ---------- markdown-lite → DOM (no innerHTML) ---------- */
const BLOCK_START = /^\s*(\||#{1,4}\s|[-*•]\s|\d+[.)]\s|```)/;
export function renderMarkdown(src) {
  const frag = document.createDocumentFragment();
  const lines = String(src ?? "").replace(/\r\n?/g, "\n").split("\n");
  let i = 0;
  while (i < lines.length) {
    const line = lines[i];
    if (!line.trim()) { i++; continue; }
    if (/^\s*\|/.test(line)) {
      const rows = [];
      while (i < lines.length && /^\s*\|/.test(lines[i])) rows.push(lines[i++]);
      frag.append(table(rows));
      continue;
    }
    const hm = line.match(/^\s*(#{1,4})\s+(.*)$/);
    if (hm) { frag.append(el("div", { style: "font-weight:700;margin:6px 0 2px" }, inline(hm[2]))); i++; continue; }
    if (/^\s*```/.test(line)) {
      i++; const buf = [];
      while (i < lines.length && !/^\s*```/.test(lines[i])) buf.push(lines[i++]);
      i++;
      frag.append(el("pre", { style: "white-space:pre-wrap;font-size:11px;background:var(--ksa-sea-mist);padding:6px 8px;border-radius:4px;margin:4px 0;overflow:auto" }, buf.join("\n")));
      continue;
    }
    const li = /^\s*([-*•]|\d+[.)])\s+/;
    if (li.test(line)) {
      const ordered = /^\s*\d+[.)]\s+/.test(line);
      const list = el(ordered ? "ol" : "ul", { style: "margin:4px 0 6px 18px;padding:0" });
      while (i < lines.length && li.test(lines[i])) list.append(el("li", { style: "margin:2px 0" }, inline(lines[i++].replace(li, ""))));
      frag.append(list);
      continue;
    }
    const buf = [];
    while (i < lines.length && lines[i].trim() && !BLOCK_START.test(lines[i])) buf.push(lines[i++]);
    const p = el("p", { style: "margin:0 0 6px" });
    buf.forEach((l, k) => { if (k) p.append(el("br")); p.append(inline(l)); });
    frag.append(p);
  }
  return frag;
}
const INLINE = /(\*\*[^*\n]+\*\*|`[^`\n]+`|(?:^|(?<=\s))\*[^*\s][^*\n]*\*)/g;
function inline(text) {
  const frag = document.createDocumentFragment();
  let last = 0, m;
  INLINE.lastIndex = 0;
  while ((m = INLINE.exec(text))) {
    if (m.index > last) frag.append(document.createTextNode(text.slice(last, m.index)));
    const t = m[0];
    if (t.startsWith("**")) frag.append(el("strong", {}, t.slice(2, -2)));
    else if (t.startsWith("`")) frag.append(el("code", { style: "font-size:11px;background:var(--ksa-sea-mist);padding:0 3px;border-radius:3px" }, t.slice(1, -1)));
    else frag.append(el("em", {}, t.slice(1, -1)));
    last = m.index + t.length;
  }
  if (last < text.length) frag.append(document.createTextNode(text.slice(last)));
  return frag;
}
function table(rows) {
  const cells = (l) => l.trim().replace(/^\|/, "").replace(/\|$/, "").split("|").map((c) => c.trim());
  const body = rows.filter((l) => !/^\s*\|?\s*:?-{2,}/.test(l)).map(cells);
  const wrap = el("div", { style: "overflow:auto" });
  const t = el("table");
  body.forEach((r, idx) => {
    const tr = el("tr");
    for (const c of r) tr.append(el(idx === 0 ? "th" : "td", {}, inline(c)));
    t.append(tr);
  });
  wrap.append(t);
  return wrap;
}
