/* views.js — every task-pane screen. VIEWS[id](container, ctx). ctx = { host, library, settings, params, go, toast } */
import { el, resolve, isOffice, caps, toast, copyText, download, getSettings, saveSettings } from "./host.js";
import { byCategory, subcategories, gallery, favourites, toggleFavourite } from "./library.js";
import { insertItem, applyBrand, newFromTemplate, kindFor } from "./insert.js";
import { PALETTE, CLUSTERS, BRAND_PRESETS } from "./brand.js";

/* ---------- tiny glyph set for the pane UI ---------- */
const G = {
  settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><circle cx="12" cy="12" r="5"/><path d="M12 2.5V6M12 18v3.5M2.5 12H6M18 12h3.5M5.3 5.3l2.5 2.5M16.2 16.2l2.5 2.5M18.7 5.3l-2.5 2.5M7.8 16.2l-2.5 2.5"/></svg>',
  star: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 3.5l2.6 5.6 6.1.7-4.5 4.2 1.2 6-5.4-3-5.4 3 1.2-6L3.3 9.8l6.1-.7z"/></svg>',
  back: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M15 5l-7 7 7 7"/></svg>',
  copy: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="8" y="8" width="12" height="12"/><path d="M16 8V4H4v12h4"/></svg>',
  download: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 4v12M7 11l5 5 5-5M4 20h16"/></svg>',
};
export function glyph(name) { return G[name] || ""; }

const CAT_INFO = {
  logo: ["Logo & colour", "The KAYAK logo, identifier, monogram and the KSA palette."],
  icons: ["Icons", "48 KSA service and interface icons on the 24-grid, in six versions."],
  "industry-icons": ["Industry icons", "2,160 icons across the 45 IBEF industries: value chain, services, advisory and digital."],
  shapes: ["Shapes", "Blades, chevrons, deltas, badges, dividers and marks, fully editable."],
  diagrams: ["Smart diagrams", "Editable grouped-shape diagrams: processes, cycles, matrices, funnels and maps."],
  infographics: ["Infographics", "Editable infographic blocks: big numbers, timelines, comparisons, scorecards."],
  charts: ["Charts", "Native, editable charts styled to the KSA data rules."],
  patterns: ["Patterns", "Eleven seamless brand patterns in six colourways."],
  effects: ["Effects", "One-click KSA styling for the selection: fills, lines, type, shadows and crops."],
  layouts: ["Layouts", "Slide layouts for decks and sheet layouts for Excel."],
  "report-layouts": ["Report layouts", "Word page layouts: covers, chapter openers, exhibits, tables, back pages."],
  templates: ["Templates", "The corporate presentation, service proposal, thought-leadership report and more."],
};

/* ---------- shared pieces ---------- */
function header(title, lead, backTo) {
  const h = el("div", { class: "section" });
  if (backTo) h.append(el("button", { class: "btn btn--ghost btn--sm", html: G.back + " Back", onclick: backTo }));
  h.append(el("h2", { style: "margin:6px 0 2px;font-size:16px" }, title));
  if (lead) h.append(el("p", { style: "margin:0;color:var(--body)" }, lead));
  return h;
}
function section(title, node, linkText, onLink) {
  const s = el("div", { class: "section" });
  const t = el("div", { class: "section__title" }, [el("span", {}, title)]);
  if (linkText) t.append(el("a", { href: "#", onclick: (e) => { e.preventDefault(); onLink(); } }, linkText));
  s.append(t, node);
  return s;
}
function hubNotice(ctx) {
  if (isOffice()) return null;
  return el("div", { class: "notice" }, "You are browsing outside Office. Inserting is replaced by copy and download.");
}
function chipRow(labels, active, onPick) {
  const row = el("div", { class: "chips" });
  for (const l of labels) row.append(el("button", { class: "chip", "aria-pressed": String(l === active), onclick: () => onPick(l) }, l));
  return row;
}

/** Generic category browser with subcategory chips and a detail panel. */
function categoryView(catId) {
  return async (container, ctx) => {
    const [title, lead] = CAT_INFO[catId] || [catId, ""];
    const items = byCategory(ctx.library, catId, ctx.host);
    container.append(header(title, lead));
    const n = hubNotice(ctx); if (n) container.append(n);
    const subs = subcategories(items);
    let active = ctx.params.sub || "All";
    const body = el("div");
    const chips = subs.length > 1 ? chipRow(["All", ...subs.map(([k]) => k)], active, (l) => { active = l; draw(); }) : null;
    if (chips) container.append(chips);
    container.append(body);
    function draw() {
      body.innerHTML = "";
      chips?.querySelectorAll(".chip").forEach((c) => c.setAttribute("aria-pressed", String(c.textContent === active)));
      const list = active === "All" ? items : items.filter((it) => (it.subcategory || "Other") === active);
      const wide = ["layouts", "report-layouts", "templates", "infographics", "diagrams", "charts", "patterns"].includes(catId);
      body.append(gallery(list, (it) => detailView(container, ctx, it, () => { container.innerHTML = ""; categoryView(catId)(container, { ...ctx, params: { sub: active } }); }), { wide, list: catId === "templates" || catId === "effects" }));
    }
    draw();
  };
}

/** Detail panel for one item: preview, variants, insert/copy/download. */
export function detailView(container, ctx, it, back) {
  container.innerHTML = "";
  container.append(header(it.name, it.description || it.subcategory || "", back));
  const dark = it.dark || /reversed|white/i.test(it.name);
  const panel = el("div", { class: "detail" });
  const prev = el("div", { class: "detail__preview" + (dark ? " detail__preview--dark" : "") }, el("img", { alt: it.name, src: resolve(it.preview || it.formats?.svg || it.formats?.png || "") }));
  panel.append(prev);
  let variant = it.defaultVariant || null;
  const variants = it.formats?.svgVariants ? Object.keys(it.formats.svgVariants) : (it.variants ? Object.keys(it.variants) : []);
  if (variants.length) {
    variant = variant || variants[0];
    panel.append(el("div", { class: "hint" }, "Version"));
    panel.append(chipRow(variants, variant, (v) => {
      variant = v;
      panel.querySelectorAll(".chip").forEach((c) => c.setAttribute("aria-pressed", String(c.textContent === v)));
      const src = it.formats?.svgVariants?.[v] || it.variants?.[v]?.preview; if (src) prev.querySelector("img").src = resolve(src);
      prev.className = "detail__preview" + (/white|reversed/i.test(v) ? " detail__preview--dark" : "");
    }));
  }
  const row = el("div", { class: "btnrow" });
  const kind = kindFor(it);
  if (isOffice() && kind !== "download") {
    const label = kind === "template" ? (ctx.host === "powerpoint" ? "Insert all slides" : "New document") : kind === "effect" ? "Apply to selection" : "Insert";
    row.append(el("button", { class: "btn btn--primary", onclick: async (e) => { e.target.disabled = true; try { kind === "template" ? await newFromTemplate(it) : kind === "effect" ? await applyBrand(it.spec) : await insertItem(it, { variant }); } finally { e.target.disabled = false; } } }, label));
    if (kind === "slide" && it.slideIndex?.length > 1) row.append(el("span", { class: "hint" }, `${it.slideIndex.length} slides`));
  }
  if (it.formats?.svg || it.formats?.svgVariants) row.append(el("button", { class: "btn btn--secondary btn--sm", html: G.copy + " Copy SVG", onclick: () => fallbackCopy(it, variant) }));
  row.append(el("button", { class: "btn btn--secondary btn--sm", html: G.download + " Download", onclick: () => fallbackDownload(it, variant) }));
  const fav = favourites().has(it.id);
  row.append(el("button", { class: "btn btn--ghost btn--sm", html: G.star + (fav ? " Saved" : " Save"), onclick: (e) => { const on = toggleFavourite(it.id); e.currentTarget.innerHTML = G.star + (on ? " Saved" : " Save"); } }));
  panel.append(row);
  if (it.tags?.length) panel.append(el("div", { class: "hint", style: "margin-top:8px" }, it.tags.join(" · ")));
  if (it.note) panel.append(el("p", { class: "hint", style: "margin-top:8px" }, it.note));
  container.append(panel);
}
async function fallbackCopy(it, variant) { const { fallback } = await import("./insert.js"); return fallback(it, { variant, copy: true }); }
async function fallbackDownload(it, variant) { const { fallback } = await import("./insert.js"); return fallback(it, { variant }); }

/* ---------- Home ---------- */
async function home(container, ctx) {
  const n = hubNotice(ctx); if (n) container.append(n);
  const quick = el("div", { class: "grid grid--wide" });
  const actions = [
    ["Insert logo", () => ctx.go("logo")],
    ["Apply KSA style to selection", () => applyBrand(BRAND_PRESETS.default)],
    ["New corporate deck", () => ctx.go("templates")],
    ["Ask the KSA Assistant", () => ctx.go("assistant")],
  ];
  for (const [label, fn] of actions) quick.append(el("button", { class: "tile", style: "min-height:64px;justify-content:center;font-weight:600", onclick: fn }, label));
  container.append(section("Quick actions", quick));
  const favIds = favourites();
  const favs = (ctx.library.items || []).filter((it) => favIds.has(it.id));
  if (favs.length) container.append(section("Saved", gallery(favs.slice(0, 12), (it) => detailView(container, ctx, it, () => ctx.go("home")))));
  const recent = (ctx.library.items || []).filter((it) => it.featured).slice(0, 12);
  container.append(section("Featured", gallery(recent, (it) => detailView(container, ctx, it, () => ctx.go("home")), { wide: true })));
  const cats = (ctx.library.categories || []).filter((c) => c.id !== "assistant");
  const grid = el("div", { class: "grid grid--wide" });
  for (const c of cats) grid.append(el("button", { class: "tile", onclick: () => ctx.go(c.id) }, [el("div", { style: "font-weight:700" }, c.name), el("div", { class: "tile__desc" }, `${(ctx.library.items || []).filter((i) => i.category === c.id).length} items`)]));
  container.append(section("Browse", grid));
}

/* ---------- Logo & colour ---------- */
async function logo(container, ctx) {
  container.append(header("Logo & colour", CAT_INFO.logo[1]));
  const n = hubNotice(ctx); if (n) container.append(n);
  const items = byCategory(ctx.library, "logo", ctx.host);
  container.append(section("Logo versions", gallery(items, (it) => detailView(container, ctx, it, () => ctx.go("logo")))));
  const sw = el("div", { class: "swatches" });
  for (const c of PALETTE) sw.append(el("button", { class: "swatch", title: `Copy ${c.hex}`, onclick: () => copyText(c.hex) }, [el("div", { class: "swatch__color", style: `background:${c.hex}` }), el("div", { class: "swatch__name" }, c.name), el("div", { class: "swatch__hex" }, c.hex)]));
  container.append(section("Palette (click to copy)", sw));
  const cl = el("div", { class: "swatches" });
  for (const c of CLUSTERS) cl.append(el("button", { class: "swatch", title: `Copy ${c.hex}`, onclick: () => copyText(c.hex) }, [el("div", { class: "swatch__color", style: `background:${c.hex}` }), el("div", { class: "swatch__name" }, c.short), el("div", { class: "swatch__hex" }, c.hex)]));
  container.append(section("Service clusters", cl));
  const btns = el("div", { class: "btnrow" });
  if (isOffice()) btns.append(el("button", { class: "btn btn--primary btn--sm", onclick: () => applyBrand(BRAND_PRESETS.theme) }, ctx.host === "excel" ? "Apply KSA theme to workbook" : ctx.host === "powerpoint" ? "Apply KSA theme colours" : "Apply KSA styles"));
  btns.append(el("button", { class: "btn btn--secondary btn--sm", onclick: () => download("assets/templates/KSA_Office_Theme.thmx", "KSA_Office_Theme.thmx") }, "Download Office theme (.thmx)"));
  container.append(section("Theme", btns));
}

/* ---------- Effects (presets applied to selection) ---------- */
async function effects(container, ctx) {
  container.append(header("Effects", CAT_INFO.effects[1]));
  if (!isOffice()) container.append(el("div", { class: "notice" }, "Effects apply to a selection inside PowerPoint, Word or Excel."));
  const items = byCategory(ctx.library, "effects", ctx.host);
  container.append(gallery(items, async (it) => { await applyBrand(it.spec); }, { list: true, emptyText: "No effects for this host." }));
}

/* ---------- Settings ---------- */
async function settings(container, ctx) {
  container.append(header("Settings", "Choices are saved on this device.", () => ctx.go("home")));
  const s = getSettings();
  const form = el("div", { class: "detail" });
  form.append(field("Assistant endpoint", "assistantUrl", s.assistantUrl || "", "https://ksa-assistant.<your-domain>.workers.dev", "The proxy you deployed from the server folder. Your API key never leaves that proxy."));
  form.append(field("Assistant access token", "assistantToken", s.assistantToken || "", "optional shared secret", "Only if your proxy requires one."));
  form.append(field("Your name for signatures", "userName", s.userName || "", "[Full Name]"));
  form.append(field("Designation", "userTitle", s.userTitle || "", "[Designation]"));
  form.append(field("Mobile", "userPhone", s.userPhone || "", "+91 00000 00000"));
  const row = el("div", { class: "btnrow" });
  row.append(el("button", { class: "btn btn--primary", onclick: () => { const patch = {}; form.querySelectorAll("input").forEach((i) => patch[i.name] = i.value.trim()); saveSettings(patch); ctx.settings = getSettings(); toast("Settings saved", "ok"); } }, "Save"));
  row.append(el("button", { class: "btn btn--ghost", onclick: () => { localStorage.removeItem("ksa-toolbar-settings"); toast("Settings cleared"); ctx.go("settings"); } }, "Reset"));
  form.append(row);
  const c = caps();
  form.append(el("p", { class: "hint", style: "margin-top:12px" }, `Host: ${ctx.host} · SVG insert ${c.svgInsert ? "yes" : "no"} · slides ${c.pptSlides ? "yes" : "no"} · shapes ${c.pptShapes || c.excelShapes ? "yes" : "no"} · templates ${c.wordCreateDoc || c.excelCreateWb || c.pptSlides ? "yes" : "no"}`));
  container.append(form);
}
function field(label, name, value, placeholder, hint) {
  const f = el("div", { class: "field" });
  f.append(el("label", { for: "f-" + name }, label), el("input", { id: "f-" + name, name, value, placeholder }));
  if (hint) f.append(el("div", { class: "hint" }, hint));
  return f;
}

/* ---------- search results ---------- */
export function renderResults(container, ctx) {
  const { q, items } = ctx.params;
  container.append(header(`Results for “${q}”`, `${items.length} item${items.length === 1 ? "" : "s"}`));
  container.append(gallery(items, (it) => detailView(container, ctx, it, () => ctx.go(ctx.settings.lastView || "home"))));
}

/* ---------- assistant (lazy) ---------- */
async function assistant(container, ctx) {
  const mod = await import("./assistant.js");
  return mod.render(container, ctx);
}

export const VIEWS = {
  home, logo, settings, effects, assistant,
  icons: categoryView("icons"),
  "industry-icons": categoryView("industry-icons"),
  shapes: categoryView("shapes"),
  diagrams: categoryView("diagrams"),
  infographics: categoryView("infographics"),
  charts: categoryView("charts"),
  patterns: categoryView("patterns"),
  layouts: categoryView("layouts"),
  "report-layouts": categoryView("report-layouts"),
  templates: categoryView("templates"),
};
