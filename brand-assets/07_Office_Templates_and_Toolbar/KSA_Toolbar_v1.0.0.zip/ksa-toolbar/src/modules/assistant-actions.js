/* assistant-actions.js — executes the structured actions the KSA Assistant returns.
 * run(action, ctx) → Promise<string|null>. Every action feature-detects the host API, catches errors and toasts.
 * Action shapes (validated again by the proxy before they reach us):
 *   excel.chart   { chartType, title, highlight, range?, rows? }
 *   excel.table   { rows, range? }
 *   excel.rag     { range?, thresholds?:{green, amber}, higherIsBetter? }
 *   ppt.exhibit   { title, subtitle, source, rows, chartType, number? }
 *   ppt.title     { text }
 *   word.insert   { text|html, style:"standfirst"|"body"|"bullets"|"heading" }
 *   word.replace  { text }
 *   outlook.insert{ html|text }
 *   copy          { text }
 */
import { toast, host, caps, copyText } from "./host.js";
import { C, DATA, FONTS } from "./brand.js";

const LABELS = {
  "excel.chart": "Insert chart",
  "excel.table": "Insert table",
  "excel.rag": "Apply RAG colours",
  "ppt.exhibit": "Insert exhibit slide",
  "ppt.title": "Set action title",
  "word.insert": "Insert summary",
  "word.replace": "Replace selection",
  "outlook.insert": "Insert into message",
  copy: "Copy text",
};
const HOST_FOR_PREFIX = { excel: "excel", ppt: "powerpoint", word: "word", outlook: "outlook" };
const HOST_NAMES = { excel: "Excel", powerpoint: "PowerPoint", word: "Word", outlook: "Outlook" };
const MAX_ROWS = 200, MAX_COLS = 30;
/* Indian grouping (12,34,56,789) for large numbers; plain for small ones. */
const FMT_INDIAN = "[>=10000000]##\\,##\\,##\\,##0;[>=100000]##\\,##\\,##0;#,##0";
const RAG = {
  green: { fill: "#E4ECE4", font: C.kelp },
  amber: { fill: C.haze, font: C.gold },
  red: { fill: "#F4DED9", font: C.clay },
};

export function labelFor(action) {
  if (action?.label) return String(action.label).slice(0, 40);
  if (action?.type === "word.insert") {
    return { standfirst: "Insert standfirst", bullets: "Insert bullets", heading: "Insert heading" }[action.style] || "Insert summary";
  }
  return LABELS[action?.type] || String(action?.type || "Run");
}

export function allowedHere(action, h = host()) {
  const type = String(action?.type || "");
  if (type === "copy") return true;
  return HOST_FOR_PREFIX[type.split(".")[0]] === h;
}

export async function run(action, ctx = {}) {
  const type = String(action?.type || "");
  const h = ctx.host || host();
  try {
    if (!allowedHere(action, h)) {
      const need = HOST_NAMES[HOST_FOR_PREFIX[type.split(".")[0]]] || "Office";
      throw new Error(`This action runs in ${need}`);
    }
    let how;
    switch (type) {
      case "excel.chart": how = await excelChart(action); break;
      case "excel.table": how = await excelTable(action); break;
      case "excel.rag": how = await excelRag(action); break;
      case "ppt.exhibit": how = await pptExhibit(action); break;
      case "ppt.title": how = await pptTitle(action); break;
      case "word.insert": how = await wordInsert(action); break;
      case "word.replace": how = await wordReplace(action); break;
      case "outlook.insert": how = await outlookInsert(action); break;
      case "copy": await copyText(String(action.text || "")); how = null; break; // copyText toasts itself
      default: throw new Error(`Unknown action "${type}"`);
    }
    if (how) toast(how, "ok", 3200);
    return how || "ok";
  } catch (e) {
    console.warn("assistant action failed", type, e);
    toast(friendly(e), "error", 3600);
    return null;
  }
}

/* ---------- shared helpers ---------- */
function friendly(e) {
  const code = e?.code || "";
  const msg = String(e?.message || e || "Something went wrong");
  if (/InvalidSelection|ItemNotFound|GeneralException: The selection/i.test(code + " " + msg)) return "Select something in the document first, then try again";
  if (/ApiNotFound|not supported|is not a function/i.test(msg)) return "Your Office version does not support this action yet";
  if (/AccessDenied/i.test(code)) return "Office did not allow that change";
  return msg;
}

/** Coerce model rows into a clean 2-D array (max 200 × 30), numbers as numbers. */
function normaliseRows(rows) {
  if (!Array.isArray(rows)) return [];
  const out = [];
  for (const r of rows.slice(0, MAX_ROWS)) {
    const row = (Array.isArray(r) ? r : [r]).slice(0, MAX_COLS).map(cell);
    out.push(row);
  }
  const cols = Math.max(0, ...out.map((r) => r.length));
  for (const r of out) while (r.length < cols) r.push("");
  return out.filter((r) => r.some((v) => v !== ""));
  function cell(v) {
    if (v === null || v === undefined) return "";
    if (typeof v === "number" && isFinite(v)) return v;
    if (typeof v === "boolean") return v ? "Yes" : "No";
    const s = String(v).trim();
    const n = s.replace(/[₹,\s]/g, "").replace(/^\((.*)\)$/, "-$1");
    if (n !== "" && /^-?\d+(\.\d+)?$/.test(n) && !/^0\d/.test(n)) return Number(n);
    return s.slice(0, 2000);
  }
}
function isNum(v) { return typeof v === "number" && isFinite(v); }
function numberFormatFor(values) {
  const nums = values.filter(isNum);
  if (!nums.length) return null;
  if (nums.some((v) => Math.abs(v) >= 1000)) return FMT_INDIAN;
  if (nums.some((v) => !Number.isInteger(v))) return "0.0";
  return "0";
}
function splitAddress(address) {
  const s = String(address || "").trim();
  const i = s.lastIndexOf("!");
  if (i < 0) return [null, s];
  return [s.slice(0, i).replace(/^'|'$/g, ""), s.slice(i + 1)];
}
function stripHtml(html) {
  return String(html || "")
    .replace(/<\s*(br|\/p|\/div|\/li|\/h\d|\/tr)\s*\/?>/gi, "\n")
    .replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#39;/g, "'")
    .replace(/\n{3,}/g, "\n\n").trim();
}
/** Minimal HTML sanitiser for host insertion (Word/Outlook strip scripts anyway; belt and braces). */
function sanitiseHtml(html) {
  return String(html || "")
    .replace(/<\s*(script|style|iframe|object|embed|form|link|meta)[^>]*>[\s\S]*?<\s*\/\s*\1\s*>/gi, "")
    .replace(/<\s*(script|style|iframe|object|embed|form|link|meta)[^>]*\/?>/gi, "")
    .replace(/\son\w+\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, "")
    .replace(/(href|src)\s*=\s*("|')\s*javascript:[^"']*\2/gi, "$1=$2#$2");
}
function textToHtml(text) {
  const esc = (s) => s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  const blocks = String(text || "").split(/\n{2,}/).map((b) => b.trim()).filter(Boolean);
  const style = `font-family:Arial,sans-serif;font-size:11pt;color:${C.deep};margin:0 0 8pt`;
  return blocks.map((b) => {
    const lines = b.split("\n");
    if (lines.every((l) => /^\s*([-*•]|\d+[.)])\s+/.test(l))) {
      return `<ul style="${style}">` + lines.map((l) => `<li>${esc(l.replace(/^\s*([-*•]|\d+[.)])\s+/, ""))}</li>`).join("") + "</ul>";
    }
    return `<p style="${style}">${lines.map(esc).join("<br>")}</p>`;
  }).join("");
}

/* =================================================================== Excel */
function requireExcel() { if (!caps().excelApi || typeof Excel === "undefined") throw new Error("This action runs in Excel"); }

/** Resolve the target range: explicit address, else the selection (a single cell expands to its data region). */
async function resolveRange(c, address) {
  let range;
  if (address) {
    const [sheetName, addr] = splitAddress(address);
    const sheet = sheetName ? c.workbook.worksheets.getItem(sheetName) : c.workbook.worksheets.getActiveWorksheet();
    range = sheet.getRange(addr);
  } else {
    range = c.workbook.getSelectedRange();
  }
  range.load("address,rowCount,columnCount,cellCount");
  await c.sync();
  if (range.cellCount === 1 && typeof range.getSurroundingRegion === "function") {
    try {
      const region = range.getSurroundingRegion();
      region.load("address,rowCount,columnCount,cellCount");
      await c.sync();
      range = region;
    } catch { /* keep the single cell */ }
  }
  return range;
}
function writeRowsBelow(anchor, rows) {
  const cols = rows[0].length;
  const start = anchor.getLastRow().getOffsetRange(2, 0).getCell(0, 0);
  const target = start.getResizedRange(rows.length - 1, cols - 1);
  target.values = rows;
  return target;
}
const CHART_TYPES = {
  column: "columnClustered", columnclustered: "columnClustered", stackedcolumn: "columnStacked", columnstacked: "columnStacked",
  bar: "barClustered", barclustered: "barClustered", stackedbar: "barStacked", barstacked: "barStacked",
  line: "line", area: "area", donut: "doughnut", doughnut: "doughnut",
};
function chartKey(type) { return CHART_TYPES[String(type || "column").toLowerCase().replace(/[^a-z]/g, "")] || "columnClustered"; }

async function excelChart(a) {
  requireExcel();
  // Prefer the Excel host module's chart builder (same presets as the Charts tab) when it is available.
  let mod = null;
  try { mod = await import("./insert-excel.js"); } catch { mod = null; }
  if (mod && typeof mod.insert === "function") {
    const spec = { type: chartKey(a.chartType), chartType: a.chartType || "column", title: a.title || "", highlight: a.highlight, range: a.range, rows: a.rows };
    try {
      const how = await mod.insert({ id: "assistant.chart", category: "charts", name: a.title || "Assistant chart", spec }, { kind: "chart", spec, range: a.range });
      return typeof how === "string" && how !== "ok" ? how : "Chart inserted";
    } catch (e) {
      console.warn("insert-excel chart failed; using the built-in builder", e);
    }
  }
  return buildExcelChart(a);
}

async function buildExcelChart(a) {
  return Excel.run(async (c) => {
    let range;
    const rows = normaliseRows(a.rows);
    if (rows.length && !a.range) {
      const anchor = await resolveRange(c, null);
      range = writeRowsBelow(anchor, rows);
    } else {
      range = await resolveRange(c, a.range);
    }
    range.load("address,rowCount,columnCount,values");
    await c.sync();
    const values = range.values || [];
    if (range.rowCount < 2 || range.columnCount < 2) throw new Error("Select a range with labels in the first column and at least one value column");
    const key = chartKey(a.chartType);
    const isLine = key === "line", isDonut = key === "doughnut", isBar = /bar/i.test(key), isColumn = /column/i.test(key);
    const sheet = range.worksheet;
    const chart = sheet.charts.add(Excel.ChartType[key] || Excel.ChartType.columnClustered, range, "Auto");
    chart.name = "KSA chart";
    // Title: insight-first, Archivo, Deep Current
    if (a.title) {
      chart.title.visible = true;
      chart.title.text = String(a.title).slice(0, 200);
      chart.title.format.font.name = FONTS.heading; chart.title.format.font.size = 12; chart.title.format.font.bold = true; chart.title.format.font.color = C.deep;
    } else {
      chart.title.visible = false;
    }
    chart.format.fill.setSolidColor("#FFFFFF");
    try { chart.format.font.name = FONTS.heading; chart.format.font.color = C.slate; chart.format.font.size = 9; } catch { /* older API */ }
    chart.series.load("items/name,count");
    await c.sync();
    const count = chart.series.count;
    const hasHeader = values[0].slice(1).some((v) => typeof v === "string");
    const labels = values.map((r) => String(r[0]));
    const seriesNames = chart.series.items.map((s) => s.name);
    const highlight = a.highlight === undefined || a.highlight === null || a.highlight === "" ? null : a.highlight;
    chart.legend.visible = count > 1 || isDonut;
    chart.legend.position = isDonut ? "Right" : "Bottom";
    try { chart.legend.format.font.color = C.slate; chart.legend.format.font.size = 9; } catch { /* ignore */ }
    for (let i = 0; i < count; i++) {
      const s = chart.series.getItemAt(i);
      const matchesSeries = highlight !== null && count > 1 && (String(highlight) === seriesNames[i] || Number(highlight) === i);
      const colour = count === 1 ? DATA.primary : matchesSeries ? DATA.highlight : DATA.categorical[i % DATA.categorical.length];
      if (isLine) s.format.line.color = colour; else s.format.fill.setSolidColor(colour);
    }
    const points = values.length - (hasHeader ? 1 : 0);
    if (isDonut) {
      const n = Math.min(points, DATA.categorical.length);
      for (let p = 0; p < n; p++) chart.series.getItemAt(0).points.getItemAt(p).format.fill.setSolidColor(DATA.categorical[p]);
    } else {
      // Axes: zero baseline, Fog gridlines, no 3D, no dual axis (all ExcelApi 1.1)
      const v = chart.axes.valueAxis, k = chart.axes.categoryAxis;
      v.minimum = 0;
      v.majorGridlines.visible = true; v.majorGridlines.format.line.color = DATA.grid;
      v.minorGridlines.visible = false;
      k.majorGridlines.visible = false; k.format.line.color = DATA.context;
      v.format.font.color = C.slate; k.format.font.color = C.slate; v.format.font.size = 9; k.format.font.size = 9;
      if (isBar || isColumn) {
        chart.dataLabels.showValue = true;
        chart.dataLabels.position = "OutsideEnd";
        chart.dataLabels.format.font.size = 9; chart.dataLabels.format.font.color = C.slate;
      }
    }
    // One Saffron highlight on a single-series chart (by category label or 0-based index)
    if (highlight !== null && count === 1 && !isDonut) {
      let idx = labels.indexOf(String(highlight));
      if (idx >= 0) idx -= hasHeader ? 1 : 0; else if (Number.isInteger(Number(highlight))) idx = Number(highlight);
      if (idx >= 0 && idx < points) chart.series.getItemAt(0).points.getItemAt(idx).format.fill.setSolidColor(DATA.highlight);
    }
    // Place to the right of the data
    chart.setPosition(range.getOffsetRange(0, range.columnCount + 1).getCell(0, 0));
    chart.width = 440; chart.height = 280;
    await c.sync();
    // Refinements that need ExcelApi 1.7/1.8; a failure here must not undo the chart, so they get their own sync.
    try {
      if (isLine) for (let i = 0; i < count; i++) chart.series.getItemAt(i).format.line.weight = count > 1 && String(highlight) === seriesNames[i] ? 3 : 2;
      if (isDonut) chart.series.getItemAt(0).doughnutHoleSize = 64; // ring thickness 18% of diameter
      if (isBar || isColumn) { chart.series.getItemAt(0).gapWidth = 50; chart.dataLabels.numberFormat = numberFormatFor(values.flat()) || "General"; }
      if (!isDonut) chart.axes.valueAxis.format.line.visible = false;
      await c.sync();
    } catch (e) { console.warn("chart refinements skipped (older Excel)", e); }
    const cats = values.length - (hasHeader ? 1 : 0);
    const warn = !isLine && !isDonut && cats > 12 ? " (more than 12 bars: consider rolling up to Other)" : isDonut && cats > 5 ? " (more than 5 segments: roll up the tail)" : "";
    return `Chart inserted beside ${range.address.split("!").pop()}${warn}`;
  });
}

async function excelTable(a) {
  requireExcel();
  const rows = normaliseRows(a.rows);
  if (rows.length < 1) throw new Error("The assistant did not return any rows");
  return Excel.run(async (c) => {
    let target;
    if (a.range) {
      const [sheetName, addr] = splitAddress(a.range);
      const sheet = sheetName ? c.workbook.worksheets.getItem(sheetName) : c.workbook.worksheets.getActiveWorksheet();
      target = sheet.getRange(addr).getCell(0, 0).getResizedRange(rows.length - 1, rows[0].length - 1);
      target.values = rows;
    } else {
      const anchor = await resolveRange(c, null);
      target = writeRowsBelow(anchor, rows);
    }
    target.load("address");
    await c.sync();
    const sheet = target.worksheet;
    if (rows.length >= 2) {
      const table = sheet.tables.add(target.address, true);
      table.style = "TableStyleLight1";
      const header = table.getHeaderRowRange();
      header.format.fill.color = C.deep; header.format.font.color = "#FFFFFF"; header.format.font.bold = true;
      const body = table.getDataBodyRange();
      body.format.font.color = C.deep;
      try { body.format.font.name = FONTS.heading; header.format.font.name = FONTS.heading; } catch { /* ignore */ }
      for (let col = 0; col < rows[0].length; col++) {
        const fmt = numberFormatFor(rows.slice(1).map((r) => r[col]));
        if (fmt) {
          const r = target.getCell(1, col).getResizedRange(rows.length - 2, 0);
          r.numberFormat = rows.slice(1).map(() => [fmt]);
          r.format.horizontalAlignment = "Right";
        }
      }
    } else {
      target.format.font.color = C.deep;
    }
    try { target.format.autofitColumns(); } catch { /* ignore */ }
    await c.sync();
    return `Table written at ${target.address.split("!").pop()}`;
  });
}

async function excelRag(a) {
  requireExcel();
  return Excel.run(async (c) => {
    const range = await resolveRange(c, a.range);
    range.load("values,address");
    await c.sync();
    const flat = (range.values || []).flat().filter((v) => v !== "" && v !== null);
    const nums = flat.filter(isNum);
    const numeric = nums.length > 0 && nums.length >= flat.length / 2;
    const cfs = range.conditionalFormats;
    if (numeric) {
      const higher = a.higherIsBetter !== false;
      const t = a.thresholds || {};
      let green = Number(t.green), amber = Number(t.amber);
      if (!isFinite(green) || !isFinite(amber)) {
        const sorted = [...nums].sort((x, y) => x - y);
        const lo = sorted[Math.floor(sorted.length / 3)], hi = sorted[Math.floor((2 * sorted.length) / 3)];
        green = higher ? hi : lo; amber = higher ? lo : hi;
      }
      const rule = (operator, f1, f2, colours) => {
        const cf = cfs.add(Excel.ConditionalFormatType.cellValue);
        cf.cellValue.format.fill.color = colours.fill;
        cf.cellValue.format.font.color = colours.font;
        cf.cellValue.rule = f2 === undefined ? { formula1: String(f1), operator } : { formula1: String(f1), formula2: String(f2), operator };
      };
      if (higher) {
        rule("GreaterThanOrEqual", green, undefined, RAG.green);
        rule("Between", amber, green, RAG.amber);
        rule("LessThan", amber, undefined, RAG.red);
      } else {
        rule("LessThanOrEqual", green, undefined, RAG.green);
        rule("Between", green, amber, RAG.amber);
        rule("GreaterThan", amber, undefined, RAG.red);
      }
      await c.sync();
      return `RAG applied to ${range.address.split("!").pop()}: green ${higher ? "≥" : "≤"} ${green}, amber to ${amber}`;
    }
    const words = [["green", RAG.green], ["on track", RAG.green], ["amber", RAG.amber], ["at risk", RAG.amber], ["red", RAG.red], ["off track", RAG.red]];
    for (const [text, colours] of words) {
      const cf = cfs.add(Excel.ConditionalFormatType.containsText);
      cf.textComparison.format.fill.color = colours.fill;
      cf.textComparison.format.font.color = colours.font;
      cf.textComparison.rule = { operator: Excel.ConditionalTextOperator.contains, text };
    }
    await c.sync();
    return `RAG applied to ${range.address.split("!").pop()} for Green, Amber and Red labels`;
  });
}

/* ============================================================== PowerPoint */
function requirePpt() { if (!caps().pptShapes || typeof PowerPoint === "undefined") throw new Error("This needs PowerPoint 2021 or Microsoft 365 (PowerPointApi 1.4)"); }
const SLIDE_W = 960, MARGIN = 48;

function textBox(shapes, o) {
  const s = shapes.addTextBox(o.text, { left: o.left, top: o.top, width: o.width, height: o.height });
  s.name = o.name || "KSA text";
  const f = s.textFrame.textRange.font;
  f.name = o.font || FONTS.heading; f.size = o.size || 12; f.bold = !!o.bold; f.color = o.color || C.deep;
  try { s.textFrame.wordWrap = true; s.lineFormat.visible = false; } catch { /* ignore */ }
  return s;
}

async function pptExhibit(a) {
  requirePpt();
  const rows = normaliseRows(a.rows).slice(0, 13).map((r) => r.slice(0, 8));
  const title = String(a.title || "[Insight headline]").slice(0, 200);
  return PowerPoint.run(async (c) => {
    const slides = c.presentation.slides;
    slides.add();
    slides.load("items/id");
    await c.sync();
    const slide = slides.items[slides.items.length - 1];
    // Put the new slide right after the current one when the API allows it
    try {
      if (caps().pptSelection && typeof slide.moveTo === "function") {
        const sel = c.presentation.getSelectedSlides(); sel.load("items/id"); await c.sync();
        const idx = sel.items.length ? slides.items.findIndex((s) => s.id === sel.items[0].id) : -1;
        if (idx >= 0 && idx + 1 < slides.items.length - 1) { slide.moveTo(idx + 1); await c.sync(); }
      }
    } catch { /* leave at the end */ }
    const sh = slide.shapes;
    const number = Number.isInteger(Number(a.number)) ? Number(a.number) : null;
    textBox(sh, { text: `EXHIBIT ${number ?? "[n]"}`, left: MARGIN, top: 34, width: 400, height: 20, size: 10, bold: true, color: C.slate, name: "KSA Exhibit eyebrow" });
    textBox(sh, { text: title, left: MARGIN, top: 56, width: SLIDE_W - 2 * MARGIN, height: 66, size: 24, bold: true, color: C.deep, name: "KSA Exhibit title" });
    if (a.subtitle) textBox(sh, { text: String(a.subtitle).slice(0, 200), left: MARGIN, top: 124, width: SLIDE_W - 2 * MARGIN, height: 22, size: 12, color: C.slate, name: "KSA Exhibit subtitle" });
    try {
      const line = sh.addLine(PowerPoint.ConnectorType.straight, { left: MARGIN, top: 156, width: 56, height: 0 });
      line.name = "KSA Exhibit accent"; line.lineFormat.color = C.saffron; line.lineFormat.weight = 3;
    } catch { /* ignore */ }
    let how = "table";
    if (rows.length) {
      const cols = rows[0].length;
      const height = Math.min(26 * rows.length, 300);
      const values = rows.map((r) => r.map((v) => (isNum(v) ? formatIndian(v) : String(v))));
      let table = null;
      if (typeof sh.addTable === "function") {
        try {
          table = sh.addTable(rows.length, cols, {
            left: MARGIN, top: 172, width: SLIDE_W - 2 * MARGIN, height, values,
            uniformCellProperties: { font: { name: FONTS.heading, size: 11, color: C.deep } },
            specificCellProperties: rows[0].map((_, col) => ({ rowIndex: 0, columnIndex: col, properties: { fill: { color: C.deep }, font: { color: "#FFFFFF", bold: true, name: FONTS.heading, size: 11 } } })),
          });
          table.name = "KSA Exhibit table";
          await c.sync();
        } catch (e) {
          console.warn("addTable with properties failed, retrying plain", e);
          try { table = sh.addTable(rows.length, cols, { left: MARGIN, top: 172, width: SLIDE_W - 2 * MARGIN, height, values }); table.name = "KSA Exhibit table"; await c.sync(); }
          catch (e2) { console.warn("addTable failed", e2); table = null; }
        }
      }
      if (!table) {
        how = "text table (this PowerPoint cannot add native tables)";
        textBox(sh, { text: values.map((r) => r.join("\t")).join("\n"), left: MARGIN, top: 172, width: SLIDE_W - 2 * MARGIN, height, size: 11, color: C.deep, name: "KSA Exhibit table" });
      }
    }
    textBox(sh, { text: `Source: ${String(a.source || "[Source]").slice(0, 200)}; KSA analysis`, left: MARGIN, top: 494, width: SLIDE_W - 2 * MARGIN, height: 18, size: 9, color: C.river, name: "KSA Exhibit source" });
    await c.sync();
    return `Exhibit slide added as a ${how}. For a native chart, build it in Excel from this table and paste it in.`;
  });
}
function formatIndian(n) {
  const neg = n < 0; const abs = Math.abs(n);
  const [int, dec] = (Number.isInteger(abs) ? String(abs) : abs.toFixed(1)).split(".");
  let s = int;
  if (int.length > 3) {
    const last3 = int.slice(-3); let rest = int.slice(0, -3);
    rest = rest.replace(/\B(?=(\d{2})+(?!\d))/g, ",");
    s = rest + "," + last3;
  }
  return (neg ? "-" : "") + s + (dec ? "." + dec : "");
}

async function pptTitle(a) {
  requirePpt();
  const text = String(a.text || "").trim().slice(0, 400);
  if (!text) throw new Error("No title text was returned");
  return PowerPoint.run(async (c) => {
    let target = null, isTitle = false;
    if (caps().pptSelection) {
      const sel = c.presentation.getSelectedShapes();
      sel.load("items/id,items/name,items/type");
      await c.sync();
      for (const s of sel.items) {
        try { s.textFrame.textRange.load("text"); await c.sync(); target = s; isTitle = /title/i.test(s.name); break; }
        catch { /* no text frame on this shape */ }
      }
    }
    if (!target) {
      const slides = caps().pptSelection ? c.presentation.getSelectedSlides() : c.presentation.slides;
      slides.load("items/id");
      await c.sync();
      const slide = slides.items[0];
      if (!slide) throw new Error("Open a slide first");
      const sh = slide.shapes;
      sh.load("items/id,items/name,items/type");
      await c.sync();
      target = sh.items.find((s) => /title/i.test(s.name)) || null;
      isTitle = true;
      if (!target) {
        target = textBox(sh, { text, left: MARGIN, top: 40, width: SLIDE_W - 2 * MARGIN, height: 66, size: 24, bold: true, color: C.deep, name: "KSA Action title" });
        await c.sync();
        return "Action title added to the slide";
      }
    }
    target.textFrame.textRange.text = text;
    if (isTitle) { const f = target.textFrame.textRange.font; f.name = FONTS.heading; f.bold = true; f.color = C.deep; }
    await c.sync();
    return isTitle ? "Action title set" : "Text replaced";
  });
}

/* ==================================================================== Word */
function requireWord() { if (!caps().wordApi || typeof Word === "undefined") throw new Error("This action runs in Word"); }
const STYLE_API = () => caps().wordCreateDoc; // styleBuiltIn arrived with WordApi 1.3

async function wordInsert(a) {
  requireWord();
  const style = String(a.style || "body");
  const text = a.text ? String(a.text) : stripHtml(a.html);
  if (!text.trim() && !a.html) throw new Error("Nothing to insert");
  return Word.run(async (c) => {
    const sel = c.document.getSelection();
    if (!a.text && a.html) {
      sel.insertHtml(sanitiseHtml(a.html), "After");
      await c.sync();
      return "Inserted";
    }
    const lines = text.split(/\n+/).map((s) => s.trim()).filter(Boolean);
    let anchor = sel;
    for (const raw of lines) {
      const bullet = style === "bullets" || /^([-*•]|\d+[.)])\s+/.test(raw);
      const clean = raw.replace(/^([-*•]|\d+[.)])\s+/, "").replace(/\*\*/g, "");
      const p = anchor.insertParagraph(bullet && !STYLE_API() ? "• " + clean : clean, "After");
      applyWordStyle(p, bullet ? "bullets" : style);
      anchor = p;
    }
    await c.sync();
    return `${lines.length} paragraph${lines.length === 1 ? "" : "s"} inserted`;
  });
}
function applyWordStyle(p, style) {
  if (style === "standfirst") {
    p.font.name = FONTS.serif; p.font.size = 14; p.font.color = C.slate; p.font.bold = false; p.font.italic = false; p.spaceAfter = 10;
    return;
  }
  if (style === "heading") {
    if (STYLE_API()) { p.styleBuiltIn = Word.Style.heading2; } else { p.font.bold = true; p.font.size = 14; }
    p.font.name = FONTS.heading; p.font.color = C.deep;
    return;
  }
  if (style === "bullets" && STYLE_API()) {
    p.styleBuiltIn = Word.Style.listBullet;
  }
  p.font.name = FONTS.heading; p.font.size = 11; p.font.color = C.deep; p.font.bold = false;
}
async function wordReplace(a) {
  requireWord();
  const text = String(a.text || "");
  if (!text.trim()) throw new Error("Nothing to replace with");
  return Word.run(async (c) => {
    const sel = c.document.getSelection();
    sel.load("text");
    await c.sync();
    if (!sel.text) throw new Error("Select the text to replace first");
    sel.insertText(text, "Replace");
    await c.sync();
    return "Selection replaced";
  });
}

/* ================================================================= Outlook */
function outlookInsert(a) {
  if (!caps().mailbox || typeof Office === "undefined" || !Office.context?.mailbox?.item?.body?.setSelectedDataAsync) throw new Error("Open a message in compose mode first");
  const html = a.html ? sanitiseHtml(a.html) : textToHtml(a.text);
  if (!html) throw new Error("Nothing to insert");
  return new Promise((resolve, reject) => {
    Office.context.mailbox.item.body.setSelectedDataAsync(html, { coercionType: Office.CoercionType.Html }, (res) => {
      if (res.status === Office.AsyncResultStatus.Succeeded) resolve("Inserted into the message");
      else reject(new Error(res.error?.message || "Outlook could not insert the text (is the message in compose mode?)"));
    });
  });
}
