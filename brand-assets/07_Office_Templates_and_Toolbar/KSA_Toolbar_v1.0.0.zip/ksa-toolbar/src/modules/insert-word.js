/* insert-word.js — Word host module for the KSA Toolbar.
 *
 * Exports:
 *   insert(item, { kind, variant, size })  → Promise<string>   "svg" | "png" | "ooxml" | "html" | "table" | "document"
 *       kinds: "svg" | "png" | "ooxml" | "html" | "table" | "template"
 *   applyBrand(preset)                     → Promise<void>     style the selection (BRAND_PRESETS semantics;
 *                                                             ids "headline", "standfirst", "ksa-theme", "table" are special)
 *   newFromTemplate(item)                  → Promise<void>     createDocument(base64).open() on WordApi 1.3, else insertFileFromBase64
 *   styleTable(table)                      (context-bound helper) KSA table look: Deep Current header, Storm Slate body, Fog borders
 *   HEADING_STYLES                         built-in heading style → { size, color, bold } used by the "ksa-theme" preset
 *
 * Every public function wraps Office calls in try/catch and throws a plain Error with a readable message.
 */
import { caps, fetchText, fetchBase64, insertSvgAtSelection, insertPngAtSelection, svgToPngBase64 } from "./host.js";
import { C, FONTS } from "./brand.js";

export const HEADING_STYLES = {
  Title: { size: 32, color: C.deep, bold: true, font: FONTS.heading },
  Heading1: { size: 24, color: C.deep, bold: true, font: FONTS.heading },
  Heading2: { size: 18, color: C.deep, bold: true, font: FONTS.heading },
  Heading3: { size: 14, color: C.water, bold: true, font: FONTS.heading },
  Heading4: { size: 12, color: C.slate, bold: true, font: FONTS.heading },
  Subtitle: { size: 16, color: C.slate, bold: false, font: FONTS.serif },
  Quote: { size: 14, color: C.slate, bold: false, font: FONTS.serif },
  IntenseQuote: { size: 14, color: C.water, bold: false, font: FONTS.serif },
};
const BODY = { size: 11, color: C.slate, bold: false, font: FONTS.heading };
const PX = 0.75; // 1px in points

/* ---------- plumbing ---------- */
function isSet(name, version) {
  try { return !!(Office?.context?.requirements?.isSetSupported(name, version)); } catch { return false; }
}
function readable(e) {
  const code = e?.code || e?.name || "";
  const known = {
    ApiNotFound: "This feature is not available in your version of Word",
    ApiNotAvailable: "This feature is not available in your version of Word",
    InvalidArgument: "Word rejected one of the values",
    ItemNotFound: "The selection could not be found",
    AccessDenied: "Word did not allow this action (the document may be protected)",
    NotAllowed: "Word does not allow this here (try placing the cursor in the body text)",
    GeneralException: "Word reported a general error",
  };
  return known[code] || e?.message || String(e);
}
async function run(fn) {
  if (typeof Word === "undefined" || !caps().wordApi) throw new Error("This needs Word 2016 or Microsoft 365");
  try { return await Word.run(fn); }
  catch (e) { throw new Error(readable(e)); }
}
function pathFor(item, variant, kind) {
  const f = item.formats || {};
  if (kind === "png") return (variant && f.pngVariants?.[variant]) || f.png || null;
  return (variant && f.svgVariants?.[variant]) || f.svg || null;
}
function defaultWidth(item, options) {
  if (options.size) return Number(options.size) || 120;
  const cat = item.category || "";
  if (cat === "logo") return /monogram|identifier|app/i.test(item.name || "") ? 48 : 160;
  if (cat === "icons" || cat === "industry-icons") return 36;
  const w = Number(item.size?.w) || 0;
  return w > 0 ? Math.min(w * PX, 450) : 300; // library sizes are pixels; Word wants points; page body is ~450pt wide
}

/* ---------- insert ---------- */
export async function insert(item, options = {}) {
  const kind = options.kind || "svg";
  try {
    switch (kind) {
      case "svg": return await insertSvg(item, options);
      case "png": return await insertPng(item, options);
      case "ooxml": return await insertOoxml(item);
      case "html": return await insertHtml(item);
      case "table": return await insertTable(item, options);
      case "template": await newFromTemplate(item); return "document";
      default: throw new Error(`Word cannot insert "${kind}" items`);
    }
  } catch (e) {
    throw e instanceof Error ? e : new Error(String(e));
  }
}

async function insertSvg(item, options) {
  const path = pathFor(item, options.variant, "svg");
  if (!path) return insertPng(item, options);
  const svg = await fetchText(path);
  if (caps().svgInsert) {
    try { return await insertSvgAtSelection(svg, 1024); }
    catch (e) { console.warn("XmlSvg coercion failed, rasterising", e); }
  }
  const base64 = await svgToPngBase64(svg, 1024);
  return insertPicture(base64, defaultWidth(item, options), item.name);
}

async function insertPng(item, options) {
  const png = pathFor(item, options.variant, "png");
  let base64;
  if (png) base64 = await fetchBase64(png);
  else {
    const svgPath = pathFor(item, options.variant, "svg");
    if (!svgPath) throw new Error("This item has no image to insert");
    base64 = await svgToPngBase64(await fetchText(svgPath), 1024);
  }
  return insertPicture(base64, defaultWidth(item, options), item.name);
}

/** Inline picture at the selection: Word.run first (lets us size it), then the host-neutral Image coercion. */
async function insertPicture(base64, widthPt, name) {
  try {
    await run(async (context) => {
      const pic = context.document.getSelection().insertInlinePictureFromBase64(base64, "End");
      pic.lockAspectRatio = true;
      if (widthPt) pic.width = widthPt;
      if (name) pic.altTextTitle = name;
      await context.sync();
    });
    return "png";
  } catch (e) {
    console.warn("insertInlinePictureFromBase64 failed, trying Image coercion", e);
    try { return await insertPngAtSelection(base64); }
    catch (e2) { throw new Error(`Could not insert the image: ${e2.message || e.message}`); }
  }
}

async function insertOoxml(item) {
  if (!item.file) throw new Error("This item has no OOXML file");
  const pkg = await fetchText(item.file);
  if (!/<pkg:package|<w:document|<\?xml/i.test(pkg.slice(0, 500))) throw new Error("The OOXML file does not look like a Word package");
  await run(async (context) => {
    context.document.getSelection().insertOoxml(pkg, "End");
    await context.sync();
  });
  return "ooxml";
}

async function insertHtml(item) {
  const path = item.html || item.file;
  if (!path) throw new Error("This item has no HTML to insert");
  const html = await fetchText(path);
  await run(async (context) => {
    context.document.getSelection().insertHtml(html, "End");
    await context.sync();
  });
  return "html";
}

/** Table from item.spec: { rows, cols, header: true, values: [[...], ...] }. */
async function insertTable(item, options = {}) {
  const spec = { ...(item.spec || {}), ...(options.spec || {}) };
  let values = Array.isArray(spec.values) ? spec.values.map((r) => [].concat(r).map((v) => String(v ?? ""))) : null;
  const rows = Math.max(1, Number(spec.rows) || (values ? values.length : 3));
  const cols = Math.max(1, Number(spec.cols) || (values ? Math.max(...values.map((r) => r.length)) : 3));
  if (!values) {
    values = [];
    for (let r = 0; r < rows; r++) values.push(Array.from({ length: cols }, (_, c) => (r === 0 && spec.header !== false ? `[Column ${c + 1}]` : "")));
  } else {
    values = values.slice(0, rows).map((r) => { const row = r.slice(0, cols); while (row.length < cols) row.push(""); return row; });
    while (values.length < rows) values.push(Array.from({ length: cols }, () => ""));
  }
  await run(async (context) => {
    const sel = context.document.getSelection();
    const table = sel.insertTable(rows, cols, "After", values);
    styleTable(table, { header: spec.header !== false, fontSize: spec.fontSize });
    await context.sync();
  });
  return "table";
}

/** KSA table styling. Must be called inside a Word.run with a Word.Table proxy. */
export function styleTable(table, opts = {}) {
  const header = opts.header !== false;
  table.font.name = FONTS.heading;
  table.font.size = opts.fontSize || 10;
  table.font.color = C.slate;
  try { table.styleBandedRows = false; table.styleBandedColumns = false; table.styleFirstColumn = false; } catch { /* WordApi 1.3 */ }
  try { table.headerRowCount = header ? 1 : 0; } catch { /* WordApi 1.3 */ }
  try {
    for (const loc of ["Top", "Bottom", "Left", "Right", "InsideHorizontal", "InsideVertical"]) {
      const b = table.getBorder(loc);
      b.type = "Single"; b.color = C.fog; b.width = PX;
    }
  } catch { /* WordApi 1.3 */ }
  if (header) {
    try {
      const first = table.rows.getFirst();
      first.shadingColor = C.deep;
      first.font.color = C.white;
      first.font.bold = true;
      first.font.name = FONTS.heading;
    } catch { /* WordApi 1.3 */ }
  }
}

/* ---------- apply brand ---------- */
export async function applyBrand(preset = {}) {
  if (!preset || typeof preset !== "object") throw new Error("No preset given");
  if (preset.id === "chart") throw new Error("Chart styling is available in Excel; paste the chart there or insert a chart exhibit from the Charts tab");
  if (preset.shadow && !preset.fill && !preset.font && !preset.color) throw new Error("Shadows are not available through the Word API. Use Picture Format or Shape Format > Effects");
  if (preset.id === "table") return applyTable();
  if (preset.id === "ksa-theme") return applyTheme();
  await run(async (context) => {
    const sel = context.document.getSelection();
    const font = sel.font;
    const spec = preset.id === "headline" ? { id: "headline", font: FONTS.heading, color: C.deep, bold: true, size: 28 }
      : preset.id === "standfirst" ? { id: "standfirst", font: FONTS.serif, color: C.slate, size: 16, bold: false }
      : preset;
    if (spec.font) font.name = spec.font;
    if (spec.size) font.size = spec.size;
    if (spec.color) font.color = spec.color;
    if (spec.bold !== undefined) font.bold = !!spec.bold;
    if (spec.id === "headline" || spec.id === "standfirst") {
      try { const paras = sel.paragraphs; paras.load("items"); await context.sync(); for (const p of paras.items) { p.spaceAfter = spec.id === "headline" ? 8 : 10; if (spec.id === "headline") p.lineSpacing = 32; } } catch { /* optional */ }
    }
    await context.sync();
    if (spec.fill) await shadeParagraphs(context, sel, spec.fill, spec.line);
  });
}

/** Paragraph shading needs WordApiDesktop 1.1; otherwise we quietly skip the fill. */
async function shadeParagraphs(context, sel, fill, line) {
  if (!isSet("WordApiDesktop", "1.1")) { console.info("KSA Toolbar: paragraph fill needs Word desktop; applied fonts only"); return; }
  try {
    const paras = sel.paragraphs; paras.load("items"); await context.sync();
    for (const p of paras.items) {
      p.shading.backgroundPatternColor = fill;
      if (line) { for (const loc of ["Top", "Bottom", "Left", "Right"]) { const b = p.getBorder(loc); b.type = "Single"; b.color = line; b.width = PX; } }
    }
    await context.sync();
  } catch (e) { console.info("KSA Toolbar: fill skipped", readable(e)); }
}

async function applyTable() {
  await run(async (context) => {
    const sel = context.document.getSelection();
    const table = sel.parentTableOrNullObject;
    table.load("isNullObject");
    await context.sync();
    if (table.isNullObject) throw new Error("Place the cursor inside a table first");
    styleTable(table);
    await context.sync();
  });
}

/** "ksa-theme": Archivo body + KSA heading colours on the selected paragraphs, or the whole document when nothing is selected. */
async function applyTheme() {
  await run(async (context) => {
    const sel = context.document.getSelection();
    sel.load("isEmpty");
    await context.sync();
    const paras = sel.isEmpty ? context.document.body.paragraphs : sel.paragraphs;
    paras.load(caps().wordCreateDoc ? "items/styleBuiltIn,items/style" : "items/style"); // styleBuiltIn is WordApi 1.3
    await context.sync();
    if (!paras.items.length) throw new Error("Nothing to style");
    for (const p of paras.items) {
      const key = String(p.styleBuiltIn || "").replace(/\s+/g, "") || String(p.style || "").replace(/\s+/g, "");
      const s = HEADING_STYLES[key] || (/^Heading\d/.test(key) ? HEADING_STYLES.Heading4 : BODY);
      p.font.name = s.font;
      p.font.color = s.color;
      p.font.bold = s.bold;
      if (s !== BODY || !/^(List|Table|Caption|Footer|Header|TOC)/i.test(key)) p.font.size = s.size;
    }
    await context.sync();
    // Tables inside the range get the KSA table look too.
    try {
      const tables = sel.isEmpty ? context.document.body.tables : sel.tables;
      tables.load("items"); await context.sync();
      for (const t of tables.items) styleTable(t);
      await context.sync();
    } catch (e) { console.info("KSA Toolbar: table restyle skipped", readable(e)); }
  });
}

/* ---------- templates ---------- */
export async function newFromTemplate(item) {
  if (!item?.file || !/\.(docx|dotx)$/i.test(item.file)) throw new Error("This template is not a Word file");
  const base64 = await fetchBase64(item.file);
  if (caps().wordCreateDoc) {
    try {
      await run(async (context) => {
        const doc = context.application.createDocument(base64);
        await context.sync();
        doc.open();
        await context.sync();
      });
      return;
    } catch (e) { console.warn("createDocument failed, inserting into the current document instead", e); }
  }
  await run(async (context) => {
    context.document.body.insertFileFromBase64(base64, "End");
    await context.sync();
  });
}
