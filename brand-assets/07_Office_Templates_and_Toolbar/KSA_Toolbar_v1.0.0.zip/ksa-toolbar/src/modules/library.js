/* library.js — loads assets/library.json and offers search, filters, favourites and gallery rendering. */
import { el, resolve, getSettings, saveSettings } from "./host.js";

let LIB = null;

export async function loadLibrary() {
  const r = await fetch(resolve("assets/library.json"), { cache: "no-cache" });
  if (!r.ok) throw new Error(`library.json ${r.status}`);
  LIB = await r.json();
  LIB.items.forEach((it) => { it._text = [it.name, it.subcategory, ...(it.tags || [])].join(" ").toLowerCase(); });
  return LIB;
}
export function library() { return LIB; }

export function byCategory(lib, categoryId, hostId) {
  return (lib?.items || []).filter((it) => it.category === categoryId && allowedIn(it, hostId));
}
export function allowedIn(item, hostId) {
  if (!hostId || hostId === "hub") return true;
  return !item.hosts || item.hosts.includes(hostId);
}
export function search(lib, q, hostId) {
  const terms = q.toLowerCase().split(/\s+/).filter(Boolean);
  return (lib?.items || []).filter((it) => allowedIn(it, hostId) && terms.every((t) => it._text.includes(t))).slice(0, 200);
}
export function subcategories(items) {
  const m = new Map();
  for (const it of items) { const k = it.subcategory || "Other"; m.set(k, (m.get(k) || 0) + 1); }
  return [...m.entries()];
}

/* favourites */
export function favourites() { return new Set(getSettings().favourites || []); }
export function toggleFavourite(id) {
  const f = favourites(); f.has(id) ? f.delete(id) : f.add(id);
  saveSettings({ favourites: [...f] }); return f.has(id);
}

/** Render a gallery of items. onPick(item) is called on click. */
export function gallery(items, onPick, opts = {}) {
  const grid = el("div", { class: "grid" + (opts.wide ? " grid--wide" : "") + (opts.list ? " grid--list" : "") });
  for (const it of items) grid.append(tile(it, onPick, opts));
  if (!items.length) grid.append(el("div", { class: "empty" }, opts.emptyText || "Nothing here yet."));
  return grid;
}
export function tile(it, onPick, opts = {}) {
  const dark = it.dark || /reversed|white/i.test(it.name);
  const t = el("button", { class: "tile" + (opts.wide ? " tile--wide" : "") + (opts.list ? " tile--list" : "") + (dark ? " tile--dark" : ""), title: it.name, onclick: () => onPick(it) });
  const img = el("img", { class: "tile__img", alt: "", loading: "lazy", src: resolve(it.preview || it.formats?.png || it.formats?.svg || "") });
  t.append(img);
  const name = el("div", { class: "tile__name" }, it.name);
  if (opts.list) t.append(el("div", {}, [name, el("div", { class: "tile__desc" }, it.description || it.subcategory || "")]));
  else t.append(name);
  if (it.badge) t.append(el("span", { class: "tile__badge" }, it.badge));
  return t;
}
