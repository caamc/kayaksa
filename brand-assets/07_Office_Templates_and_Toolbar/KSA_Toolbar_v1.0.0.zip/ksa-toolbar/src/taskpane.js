/* taskpane.js — boot, router and tab navigation. Views live in modules/; each exports render(container, ctx). */
import { ready, host, isOffice, caps, toast, setStatus, el, getSettings, saveSettings } from "./modules/host.js";
import { loadLibrary, search as searchLibrary } from "./modules/library.js";
import * as views from "./modules/views.js";

const TABS = [
  { id: "home", name: "Home" },
  { id: "logo", name: "Logo & colour" },
  { id: "icons", name: "Icons" },
  { id: "industry-icons", name: "Industry icons" },
  { id: "shapes", name: "Shapes" },
  { id: "diagrams", name: "Smart diagrams" },
  { id: "infographics", name: "Infographics" },
  { id: "charts", name: "Charts" },
  { id: "patterns", name: "Patterns" },
  { id: "effects", name: "Effects" },
  { id: "layouts", name: "Layouts" },
  { id: "report-layouts", name: "Report layouts" },
  { id: "templates", name: "Templates" },
  { id: "assistant", name: "KSA Assistant" },
];

const ctx = { host: "hub", library: null, settings: getSettings(), go, toast };

async function boot() {
  await ready();
  ctx.host = host();
  document.getElementById("hostLabel").textContent = labelFor(ctx.host);
  document.getElementById("btnSettings").innerHTML = views.glyph("settings");
  document.getElementById("btnSettings").addEventListener("click", () => go("settings"));
  renderTabs();
  try { ctx.library = await loadLibrary(); setStatus(`${ctx.library.items.length} assets`); }
  catch (e) { setStatus("Library unavailable"); toast("Could not load the asset library: " + e.message, "error"); ctx.library = { categories: [], items: [] }; }
  const q = new URLSearchParams(location.search);
  go(q.get("view") || (q.get("hub") ? "home" : ctx.settings.lastView || "home"));
  document.getElementById("search").addEventListener("input", onSearch);
}

function labelFor(h) {
  const names = { powerpoint: "PowerPoint", word: "Word", excel: "Excel", outlook: "Outlook", hub: "KSA Hub" };
  const base = names[h] || h;
  return isOffice() ? base : `${base} · browse & download`;
}

function renderTabs() {
  const nav = document.getElementById("tabs");
  nav.innerHTML = "";
  for (const t of TABS) {
    if (!tabAllowed(t.id)) continue;
    nav.append(el("button", { class: "tab", role: "tab", "data-tab": t.id, "aria-selected": "false", onclick: () => go(t.id) }, t.name));
  }
}
function tabAllowed(id) {
  const h = ctx.host;
  if (h === "outlook") return ["home", "logo", "icons", "templates", "assistant"].includes(id);
  if (h === "excel") return !["report-layouts", "layouts", "infographics", "diagrams"].includes(id) || id === "layouts";
  return true;
}

export function go(viewId, params = {}) {
  const view = document.getElementById("view");
  document.querySelectorAll(".tab").forEach((b) => b.setAttribute("aria-selected", String(b.dataset.tab === viewId)));
  const active = document.querySelector(`.tab[data-tab="${viewId}"]`);
  active?.scrollIntoView({ inline: "center", block: "nearest" });
  view.innerHTML = "";
  view.scrollTop = 0;
  saveSettings({ lastView: TABS.some((t) => t.id === viewId) ? viewId : ctx.settings.lastView });
  const fn = views.VIEWS[viewId] || views.VIEWS.home;
  Promise.resolve(fn(view, { ...ctx, params })).catch((e) => { console.error(e); toast(e.message || "Something went wrong", "error"); });
}

let searchTimer;
function onSearch(e) {
  clearTimeout(searchTimer);
  const q = e.target.value.trim();
  searchTimer = setTimeout(() => {
    if (!q) return go(ctx.settings.lastView || "home");
    const view = document.getElementById("view");
    view.innerHTML = "";
    views.renderResults(view, { ...ctx, params: { q, items: searchLibrary(ctx.library, q) } });
  }, 160);
}

window.ksaGo = (v) => go(v);
boot();
