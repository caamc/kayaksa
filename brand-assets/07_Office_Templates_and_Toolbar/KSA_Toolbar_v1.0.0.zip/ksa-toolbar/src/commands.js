/* commands.js — ribbon function commands (ExecuteFunction / unified-manifest "executeFunction" actions).
 *
 * Registered with Office.actions.associate:
 *   insertLogo       PowerPoint + Word: insert KSA_Logo_Full_FullColour.svg at the selection;
 *                    Excel: addSvg at the selected cell; Outlook: insert the KSA signature.
 *   applyKsaStyle    applyBrand(BRAND_PRESETS.default) in the current host.
 *   applyChartStyle  Excel: restyle the selected chart (or all charts on the sheet) to the KSA rules.
 *   showAssistant    opens the task pane on the KSA Assistant (Office.addin.showAsTaskpane, shared runtime).
 *
 * Every command always calls event.completed(), never throws, and reports problems to the console
 * (and as an Outlook notification bar where one exists).
 */
import { ready, host, saveSettings } from "./modules/host.js";
import { BRAND_PRESETS } from "./modules/brand.js";

const LOGO_ITEM = {
  id: "logo.full-colour", name: "KSA logo", category: "logo",
  formats: { svg: "assets/logo/KSA_Logo_Full_FullColour.svg", png: "assets/logo/KSA_Logo_Full_FullColour.png" },
  size: { w: 416, h: 134 },
};
const loaders = {
  powerpoint: () => import("./modules/insert-ppt.js"),
  word: () => import("./modules/insert-word.js"),
  excel: () => import("./modules/insert-excel.js"),
  outlook: () => import("./modules/insert-outlook.js"),
};

async function hostModule() {
  await ready();
  const h = host();
  if (!loaders[h]) throw new Error("KSA Toolbar does not run in this host");
  return { h, mod: await loaders[h]() };
}

function notify(message, isError) {
  if (isError) console.error("KSA Toolbar:", message); else console.info("KSA Toolbar:", message);
  try {
    const item = Office?.context?.mailbox?.item;
    if (item?.notificationMessages?.replaceAsync) {
      item.notificationMessages.replaceAsync("ksa-toolbar", {
        type: isError ? Office.MailboxEnums.ItemNotificationMessageType.ErrorMessage : Office.MailboxEnums.ItemNotificationMessageType.InformationalMessage,
        message: String(message).slice(0, 150),
        ...(isError ? {} : { icon: "icon16", persistent: false }),
      }, () => {});
    }
  } catch { /* not Outlook */ }
}

/** Wrap a command so it always completes and never leaves a rejected promise behind. */
function command(name, fn) {
  return async function wrapped(event) {
    try { await fn(); }
    catch (e) { notify(e?.message || `${name} failed`, true); }
    finally { try { event?.completed?.(); } catch { /* nothing to do */ } }
  };
}

const insertLogo = command("insertLogo", async () => {
  const { h, mod } = await hostModule();
  const kind = h === "outlook" ? "signature" : "svg";
  const how = await mod.insert(LOGO_ITEM, { kind });
  notify(h === "outlook" ? "KSA signature inserted" : `KSA logo inserted (${how})`);
});

const applyKsaStyle = command("applyKsaStyle", async () => {
  const { h, mod } = await hostModule();
  if (h === "outlook") throw new Error("Styling is not available in Outlook. Use the Insert logo button for the signature");
  await mod.applyBrand(BRAND_PRESETS.default);
  notify("KSA style applied");
});

const applyChartStyle = command("applyChartStyle", async () => {
  const { h, mod } = await hostModule();
  if (h !== "excel") throw new Error("Chart styling runs in Excel. In PowerPoint and Word, insert a chart exhibit from the Charts tab");
  await mod.applyBrand(BRAND_PRESETS.chart);
  notify("KSA chart style applied");
});

/* Open the shared task pane on a given view. In a shared runtime the pane and the commands share one window,
 * so window.ksaGo (set by taskpane.js) switches the view directly; otherwise the saved lastView is used on load. */
async function openView(view) {
  await ready();
  saveSettings({ lastView: view });
  if (typeof Office !== "undefined" && Office.addin && typeof Office.addin.showAsTaskpane === "function") {
    await Office.addin.showAsTaskpane();
  } else {
    notify("Open the KSA Toolbar pane from the ribbon");
  }
  if (typeof window !== "undefined" && typeof window.ksaGo === "function") window.ksaGo(view);
}
const showAssistant = command("showAssistant", () => openView("assistant"));
const VIEW_COMMANDS = ["home","logo","icons","industry-icons","shapes","diagrams","infographics","charts","patterns","effects","layouts","report-layouts","templates"];
const viewCommands = Object.fromEntries(VIEW_COMMANDS.map((v) => ["open_" + v.replace(/-/g, "_"), command("open_" + v, () => openView(v))]));

function register() {
  try {
    if (typeof Office === "undefined" || !Office.actions || typeof Office.actions.associate !== "function") return;
    Office.actions.associate("insertLogo", insertLogo);
    Office.actions.associate("applyKsaStyle", applyKsaStyle);
    Office.actions.associate("applyChartStyle", applyChartStyle);
    Office.actions.associate("showAssistant", showAssistant);
    for (const [name, fn] of Object.entries(viewCommands)) Office.actions.associate(name, fn);
  } catch (e) { console.error("KSA Toolbar: could not register ribbon commands", e); }
}

/* Office.onReady guard: register as soon as Office.js is initialised; also register immediately in case the
 * host invokes a command before onReady resolves (associate is safe to call more than once). */
if (typeof Office !== "undefined" && typeof Office.onReady === "function") {
  try { Promise.resolve(Office.onReady(register)).catch((e) => console.error("KSA Toolbar: Office.onReady failed", e)); }
  catch (e) { console.error("KSA Toolbar: Office.onReady failed", e); }
}
register();

export { insertLogo, applyKsaStyle, applyChartStyle, showAssistant };
