#!/usr/bin/env bash
# package-release.sh: zip the deployable KSA Toolbar site.
#
#   tools/package-release.sh            -> KSA_Toolbar_v<version>.zip next to the project folder (version read from manifest.xml)
#   tools/package-release.sh out.zip    -> a custom path
#
# Includes manifest/, src/, assets/, docs/, server/, powerbi/, teams/ and tools/ and the top-level files.
# Excludes caches, node_modules, .git, certificates, local settings and OS cruft. Prints the size at the end.
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
NAME="$(basename "$ROOT")"
VERSION="$(sed -n 's/.*<Version>\([0-9.]*\)<\/Version>.*/\1/p' "$ROOT/manifest/manifest.xml" | head -1)"
VERSION="${VERSION:-1.0.0.0}"
SHORT="${VERSION%.*}"                      # 1.0.0.0 -> 1.0.0
OUT="${1:-$(dirname "$ROOT")/KSA_Toolbar_v${SHORT}.zip}"

if ! command -v zip >/dev/null 2>&1; then
  echo "zip is not installed (apt install zip / brew install zip)" >&2
  exit 1
fi

rm -f "$OUT"
cd "$(dirname "$ROOT")"
zip -r -q -X "$OUT" "$NAME/manifest" "$NAME/src" "$NAME/assets" "$NAME/docs" "$NAME/server" "$NAME/powerbi" "$NAME/teams" "$NAME/tools" \
  -x "*/.git/*" "*/node_modules/*" "*/.cache/*" "*/__pycache__/*" "*.pyc" "*/.DS_Store" "*/Thumbs.db" \
     "*/tools/certs/*" "*/server/*/local.settings.json" "*/server/*/.wrangler/*" "*/.env" "*/.env.*" "*.log" "*.swp"
# top-level files, if any (README, LICENCE, package.json)
for f in "$NAME"/*; do
  [ -f "$f" ] && zip -q -X "$OUT" "$f"
done

BYTES=$(stat -c %s "$OUT" 2>/dev/null || stat -f %z "$OUT")
COUNT=$(unzip -l "$OUT" | tail -1 | awk '{print $2}')
echo "wrote $OUT"
echo "version $SHORT, $COUNT files, $(awk -v b="$BYTES" 'BEGIN{printf "%.1f MB", b/1048576}') ($BYTES bytes)"
if grep -q "ksa-toolbar.kayaksa.com" "$ROOT/manifest/manifest.xml"; then
  echo "note: manifests still use the placeholder base URL; run tools/set-base-url.py <url> before deploying"
fi
