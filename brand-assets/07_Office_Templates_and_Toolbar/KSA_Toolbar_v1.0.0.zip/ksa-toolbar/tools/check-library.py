#!/usr/bin/env python3
"""check-library.py: validates assets/library.json.

    python3 tools/check-library.py [--strict] [--list-pending]

Checks
  - the top-level shape (version, generated, categories, items) and that every category id is one of the fixed ids
  - every item has id, category, name, preview, formats (or an insert kind that needs none), insert, hosts
  - ids are unique; categories referenced by items exist
  - every referenced file (preview, formats.*, svgVariants.*, file, html) exists under ROOT
  - files owned by other contributors (assets/templates/**, assets/layouts/word/**) are reported as PENDING, not errors,
    unless --strict is given
Prints counts per category and the total size of assets/. Exit code 1 on errors (or on pending files with --strict).
"""
import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
FIXED_CATEGORIES = ["logo", "colours", "icons", "industry-icons", "shapes", "infographics", "diagrams", "charts", "patterns",
                    "effects", "layouts", "report-layouts", "templates", "assistant"]
INSERT_KINDS = {"svg", "png", "slide", "ooxml", "chart", "html", "template", "effect", "shape", "download"}
HOSTS = {"powerpoint", "word", "excel", "outlook"}
OTHERS_OWN = ("assets/templates/", "assets/layouts/word/", "assets/fonts/")
NO_FORMATS_OK = {"effect", "template", "download", "ooxml", "html"}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--strict", action="store_true", help="treat pending files from other contributors as errors")
    ap.add_argument("--list-pending", action="store_true", help="print every pending file")
    a = ap.parse_args()

    path = ROOT / "assets" / "library.json"
    if not path.exists():
        print(f"ERROR: {path} does not exist. Run tools/build-library.py first.")
        sys.exit(1)
    lib = json.loads(path.read_text(encoding="utf-8"))
    errors, pending = [], set()

    for k in ("version", "generated", "categories", "items"):
        if k not in lib:
            errors.append(f"top-level key missing: {k}")
    cat_ids = [c.get("id") for c in lib.get("categories", [])]
    for c in lib.get("categories", []):
        if c.get("id") not in FIXED_CATEGORIES:
            errors.append(f"unknown category id {c.get('id')}")
        for k in ("name", "icon", "description"):
            if not c.get(k):
                errors.append(f"category {c.get('id')} lacks {k}")
    for fixed in FIXED_CATEGORIES:
        if fixed not in cat_ids:
            errors.append(f"fixed category missing: {fixed}")

    seen = set()
    counts = {c: 0 for c in cat_ids}

    def check_file(it, label, p):
        if not isinstance(p, str) or not p:
            errors.append(f"{it['id']}: {label} is empty")
            return
        if p.startswith("/") or ".." in p:
            errors.append(f"{it['id']}: {label} must be a relative path inside the project: {p}")
            return
        if not (ROOT / p).exists():
            if p.startswith(OTHERS_OWN):
                pending.add(p)
            else:
                errors.append(f"{it['id']}: {label} not found: {p}")

    for it in lib.get("items", []):
        iid = it.get("id")
        if not iid:
            errors.append(f"item without id: {json.dumps(it)[:80]}")
            continue
        if iid in seen:
            errors.append(f"duplicate id {iid}")
        seen.add(iid)
        cat = it.get("category")
        if cat not in counts:
            errors.append(f"{iid}: unknown category {cat}")
        else:
            counts[cat] += 1
        for k in ("name", "preview", "insert", "hosts"):
            if not it.get(k):
                errors.append(f"{iid}: missing {k}")
        kinds = set((it.get("insert") or {}).values())
        if not kinds <= INSERT_KINDS:
            errors.append(f"{iid}: unknown insert kind(s) {kinds - INSERT_KINDS}")
        for h in (it.get("insert") or {}):
            if h not in HOSTS and h != "default":
                errors.append(f"{iid}: insert key {h} is not a host")
        if not set(it.get("hosts") or []) <= HOSTS:
            errors.append(f"{iid}: unknown host(s) {set(it.get('hosts') or []) - HOSTS}")
        fm = it.get("formats") or {}
        if not fm and not (kinds & NO_FORMATS_OK):
            errors.append(f"{iid}: no formats")
        if it.get("preview"):
            check_file(it, "preview", it["preview"])
        for k, v in fm.items():
            if k == "svgVariants":
                for vk, vp in v.items():
                    check_file(it, f"svgVariants.{vk}", vp)
            else:
                check_file(it, f"formats.{k}", v)
        if it.get("file"):
            check_file(it, "file", it["file"])
        if it.get("html"):
            check_file(it, "html", it["html"])
        if "svg" in kinds and not (fm.get("svg") or fm.get("svgVariants")):
            errors.append(f"{iid}: insert svg but no svg format")
        if "png" in kinds and not (fm.get("png") or it.get("preview")):
            errors.append(f"{iid}: insert png but no png format")
        if "slide" in kinds:
            if not it.get("file"):
                errors.append(f"{iid}: insert slide but no file")
            if not it.get("slideIndex") and not it.get("sourceSlideIds"):
                pending.add(f"{iid} (slideIndex not yet known: waiting for tools/make-templates/slide-library-index.json)")
        if "ooxml" in kinds and not it.get("file"):
            errors.append(f"{iid}: insert ooxml but no file")
        if "chart" in kinds and not it.get("spec"):
            errors.append(f"{iid}: insert chart but no spec")
        if "effect" in kinds and not it.get("spec"):
            errors.append(f"{iid}: insert effect but no spec")
        if it.get("defaultVariant") and it["defaultVariant"] not in fm.get("svgVariants", {}):
            errors.append(f"{iid}: defaultVariant {it['defaultVariant']} not in svgVariants")

    total = sum(f.stat().st_size for f in (ROOT / "assets").rglob("*") if f.is_file())
    nfiles = sum(1 for f in (ROOT / "assets").rglob("*") if f.is_file())
    print(f"library.json: {path.stat().st_size / 1e6:.2f} MB, {len(lib.get('items', []))} items, generated {lib.get('generated')}")
    print("items per category:")
    for c in cat_ids:
        print(f"  {c:16s} {counts.get(c, 0)}")
    print(f"assets/: {nfiles} files, {total / 1e6:.1f} MB")
    if path.stat().st_size > 3_000_000:
        errors.append("library.json is larger than 3 MB")

    if pending:
        print(f"PENDING ({len(pending)}): files or slide indexes owned by other contributors, not present yet")
        for p in (sorted(pending) if a.list_pending else sorted(pending)[:10]):
            print("   " + p)
        if not a.list_pending and len(pending) > 10:
            print(f"   ... {len(pending) - 10} more; use --list-pending")
    if errors:
        print(f"ERRORS ({len(errors)}):")
        for e in errors[:60]:
            print("   " + e)
        if len(errors) > 60:
            print(f"   ... {len(errors) - 60} more")
        sys.exit(1)
    if pending and a.strict:
        sys.exit(1)
    print("OK: every owned file exists and every item has a preview, formats and insert kinds.")


if __name__ == "__main__":
    main()
