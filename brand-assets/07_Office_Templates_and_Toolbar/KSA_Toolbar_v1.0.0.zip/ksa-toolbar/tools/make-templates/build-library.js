// KSA_Slide_Library.pptx: one insertable asset per slide. The slide title placeholder holds the
// library id so the add-in can find it; slide-library-index.json records id -> 1-based index.
// Diagram, infographic and shape slides are grouped afterwards by postprocess_library.py.
'use strict';
const fs = require('fs');
const path = require('path');
const K = require('./lib/ksa');
const { COL, CAT, CLUSTERS, SERIF, px, M, CW, W, H } = K;

const INDEX = {};
let slideNo = 0;
const BODY_Y = 2.0, BODY_B = 6.3, BODY_H = BODY_B - BODY_Y;   // content zone under the title
const CX = M.l + CW / 2;

async function main() {
  const pres = K.newPres({ title: 'KSA Slide Library', subject: 'Insertable slides for the KSA Toolbar' });
  K.defineLayouts(pres, { footer: 'Kayak Strategic Advisors' });
  const SECTION = { layouts: 'Layouts', charts: 'Charts', diagrams: 'Smart diagrams', infographics: 'Infographics', shapes: 'Shapes', effects: 'Effects' };
  let currentSection = null;

  // register a library slide; fn(slide) draws the content. Title placeholder = id.
  function add(id, meta, masterName, fn, { eyebrow = true, notes } = {}) {
    if (currentSection !== meta.category) { currentSection = meta.category; pres.addSection({ title: SECTION[meta.category] }); }
    const s = pres.addSlide({ masterName, sectionTitle: SECTION[meta.category] });
    slideNo += 1;
    if (eyebrow) s.addText(`${SECTION[meta.category].toUpperCase()} · ${meta.name.toUpperCase()}`, { placeholder: 'eyebrow' });
    s.addText(id, { placeholder: 'title' });
    fn(s);
    s.addNotes(notes || `${meta.name}. ${meta.description} Replace the title with your own action title.`);
    INDEX[id] = { index: slideNo, name: meta.name, category: meta.category, subcategory: meta.subcategory, description: meta.description, tags: meta.tags, group: !!meta.group };
    return s;
  }
  const T = (s, text, o) => s.addText(text, { margin: 0, isTextBox: true, ...o });
  const R = (s, x, y, w, h, color, name = 'Rectangle', line) => s.addShape('rect', { x, y, w, h, fill: { color }, line: line || { color, width: 0 }, objectName: name });
  const subtitle = (s, text) => T(s, text, { x: M.l, y: 1.5, w: CW, h: 0.3, fontSize: 12, color: COL.slate, objectName: 'Subtitle' });
  const source = (s, text = 'Source: [Source]; KSA analysis') => T(s, text, { x: M.l, y: 6.35, w: CW, h: 0.3, fontSize: 9.5, color: COL.slate, objectName: 'Source' });
  const chartOpts = (extra) => K.chartBase({ x: M.l, y: BODY_Y, w: CW, h: BODY_H, ...extra });

  // ====================================================================== LAYOUTS
  add('layout.title-dark', { name: 'Title slide, dark', category: 'layouts', subcategory: 'Covers', description: 'Dark cover on the Chart Contours pattern with logo, blade rule, title, standfirst and meta line.', tags: ['cover', 'title', 'dark'] },
    'KSA_COVER', (s) => {
      s.addText('[Standfirst: one sentence on what this deck decides]', { placeholder: 'subtitle' });
      s.addText('[DOCUMENT TYPE] · [MONTH YEAR] · [CLIENT OR AUDIENCE]', { placeholder: 'meta' });
    }, { eyebrow: false });
  add('layout.title-light', { name: 'Title slide, light', category: 'layouts', subcategory: 'Covers', description: 'Light cover on the Wake Lines pattern with the full-colour logo.', tags: ['cover', 'title', 'light'] },
    'KSA_COVER_LIGHT', (s) => {
      s.addText('[Standfirst: one sentence on what this deck decides]', { placeholder: 'subtitle' });
      s.addText('[DOCUMENT TYPE] · [MONTH YEAR] · [CLIENT OR AUDIENCE]', { placeholder: 'meta' });
    }, { eyebrow: false });
  add('layout.agenda', { name: 'Agenda', category: 'layouts', subcategory: 'Structure', description: 'Narrow title, serif standfirst and up to five numbered sections with rules.', tags: ['agenda', 'contents'] },
    'KSA_SPLIT', (s) => {
      s.addText('[One line on what this session is for and how long it takes]', { placeholder: 'body' });
      const x = M.l + 4.9, w = CW - 4.9, rowH = 0.95;
      ['[Section one]', '[Section two]', '[Section three]', '[Section four]', '[Decisions and next steps]'].forEach((t, i) => {
        const y = M.t + 0.34 + i * rowH;
        s.addShape('line', { x, y, w, h: 0, line: { color: i === 0 ? COL.deep : COL.fog, width: i === 0 ? 1.5 : 0.75 }, objectName: 'Rule' });
        T(s, `0${i + 1}`, { x, y: y + px(18), w: 0.7, h: 0.4, fontSize: 18, bold: true, color: i === 4 ? COL.saffron : COL.water });
        T(s, t, { x: x + 0.7, y: y + px(18), w: w - 2.2, h: 0.36, fontSize: 16, bold: true, color: COL.deep });
        T(s, '[Time]', { x: x + w - 1.4, y: y + px(18), w: 1.4, h: 0.36, fontSize: 11, color: COL.slate, align: 'right' });
        T(s, '[What this section covers]', { x: x + 0.7, y: y + px(18) + 0.36, w: w - 0.7, h: 0.35, fontSize: 12, color: COL.slate });
      });
      s.addShape('line', { x, y: M.t + 0.34 + 5 * rowH, w, h: 0, line: { color: COL.fog, width: 0.75 }, objectName: 'Rule' });
    });
  add('layout.divider', { name: 'Section divider', category: 'layouts', subcategory: 'Structure', description: 'Chevron Wake section divider with section number, title and standfirst.', tags: ['divider', 'section'] },
    'KSA_DIVIDER', (s) => {
      s.addText('01', { placeholder: 'number' });
      s.addText('[One sentence that says what this section shows]', { placeholder: 'subtitle' });
    }, { eyebrow: false });
  add('layout.action-exhibit', { name: 'Action title and exhibit', category: 'layouts', subcategory: 'Content', description: 'Action title, exhibit area with subtitle and source, and a so-what panel on the right.', tags: ['exhibit', 'chart', 'insight'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 1 · [Measure, unit and period]');
      const ew = CW - 3.6;
      s.addShape('rect', { x: M.l, y: BODY_Y, w: ew, h: BODY_H, fill: { color: COL.white }, line: { color: COL.fog, width: 1, dashType: 'dash' }, objectName: 'Exhibit area' });
      T(s, '[Exhibit: paste a chart, table or diagram here]', { x: M.l, y: BODY_Y, w: ew, h: BODY_H, fontSize: 12, color: COL.river, align: 'center', valign: 'middle' });
      const px0 = M.l + ew + 0.4;
      R(s, px0, BODY_Y, 3.2, BODY_H, COL.mist, 'So-what panel');
      T(s, 'SO WHAT', { x: px0 + 0.3, y: BODY_Y + 0.3, w: 2.6, h: 0.3, fontSize: 10, bold: true, charSpacing: 2, color: COL.water });
      T(s, [
        { text: '[The implication for the decision]', options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 8 } },
        { text: '[What changed, and why]', options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 8 } },
        { text: '[What we recommend]', options: { bullet: { indent: 12 } } },
      ], { x: px0 + 0.3, y: BODY_Y + 0.7, w: 2.6, h: 3.2, fontSize: 13, color: COL.deep, valign: 'top' });
      source(s);
    });
  add('layout.two-column', { name: 'Two-column text', category: 'layouts', subcategory: 'Content', description: 'Two text columns with bold heads, for argument and evidence side by side.', tags: ['text', 'columns'] },
    'KSA_TITLE', (s) => {
      const gap = 0.6, cw = (CW - gap) / 2;
      ['[Column one heading]', '[Column two heading]'].forEach((h, i) => {
        const x = M.l + i * (cw + gap);
        T(s, h, { x, y: BODY_Y, w: cw, h: 0.45, fontSize: 18, bold: true, color: COL.deep });
        s.addShape('line', { x, y: BODY_Y + 0.55, w: cw, h: 0, line: { color: COL.deep, width: 1.5 }, objectName: 'Rule' });
        T(s, [
          { text: '[First point, stated as a full sentence]', options: { bullet: { indent: 14 }, breakLine: true, paraSpaceAfter: 10 } },
          { text: '[Second point with the evidence behind it]', options: { bullet: { indent: 14 }, breakLine: true, paraSpaceAfter: 10 } },
          { text: '[Third point and what it means for the decision]', options: { bullet: { indent: 14 } } },
        ], { x, y: BODY_Y + 0.75, w: cw, h: 3.3, fontSize: 14, color: COL.slate, valign: 'top', lineSpacingMultiple: 1.15 });
      });
    });
  add('layout.three-columns', { name: 'Three columns', category: 'layouts', subcategory: 'Content', description: 'Three columns with icons, heads and short text on the 4 + 4 + 4 grid.', tags: ['columns', 'three'] },
    'KSA_TITLE', (s) => {
      const gap = 0.5, cw = (CW - 2 * gap) / 3;
      ['strategy', 'search', 'growth'].forEach((ic, i) => {
        const x = M.l + i * (cw + gap);
        s.addImage({ path: K.iconPng(ic), x, y: BODY_Y, w: 0.5, h: 0.5 });
        T(s, `[Column ${i + 1} heading]`, { x, y: BODY_Y + 0.7, w: cw, h: 0.4, fontSize: 18, bold: true, color: COL.deep });
        T(s, '[Two or three sentences that make one point. Keep each column to the same length so the slide reads evenly.]', { x, y: BODY_Y + 1.2, w: cw, h: 2.4, fontSize: 14, color: COL.slate, valign: 'top', lineSpacingMultiple: 1.2 });
      });
    });
  add('layout.four-cards', { name: 'Four cards', category: 'layouts', subcategory: 'Content', description: 'Four white cards on Sea Mist with icon, head and body; the last card can be set in Deep Current.', tags: ['cards', 'four', 'grid'] },
    'KSA_TITLE_MIST', (s) => {
      const gap = px(32), cw = (CW - 3 * gap) / 4, ch = BODY_H - 0.1;
      ['regulatory', 'due-diligence', 'cybersecurity', 'governance'].forEach((ic, i) => {
        const x = M.l + i * (cw + gap), dark = i === 3;
        R(s, x, BODY_Y, cw, ch, dark ? COL.deep : COL.white, 'Card');
        s.addImage({ path: K.iconPng(ic, dark ? 'Duotone_Reversed' : 'Duotone'), x: x + px(40), y: BODY_Y + px(40), w: 0.42, h: 0.42 });
        T(s, `[Card ${i + 1} heading]`, { x: x + px(40), y: BODY_Y + 1.0, w: cw - px(80), h: 0.7, fontSize: 16, bold: true, color: dark ? COL.white : COL.deep, valign: 'top' });
        T(s, '[One or two sentences that make the point of this card.]', { x: x + px(40), y: BODY_Y + 1.75, w: cw - px(80), h: ch - 2.0, fontSize: 13, color: dark ? COL.spray : COL.slate, valign: 'top', lineSpacingMultiple: 1.15 });
      });
    });
  add('layout.big-number', { name: 'Big number', category: 'layouts', subcategory: 'Content', description: 'One number, one line, with three supporting figures on the right.', tags: ['number', 'stat', 'hero'] },
    'KSA_TITLE_DARK', (s) => {
      T(s, '[86%]', { x: M.l, y: BODY_Y + 0.1, w: 7, h: 1.9, fontSize: 96, bold: true, color: COL.white });
      T(s, '[of what the number describes, in one line that completes the sentence]', { x: M.l, y: BODY_Y + 2.2, w: 6.4, h: 1.0, fontSize: 18, color: COL.spray, valign: 'top', lineSpacingMultiple: 1.2 });
      const x = M.l + 7.8, w = CW - 7.8;
      ['[38 cr]', '[22 cr]', '[26 cr]'].forEach((v, i) => {
        const y = BODY_Y + 0.2 + i * 1.3;
        s.addShape('line', { x, y, w, h: 0, line: { color: COL.undertow, width: 0.75 }, objectName: 'Rule' });
        T(s, v, { x, y: y + 0.15, w, h: 0.5, fontSize: 24, bold: true, color: i === 0 ? COL.saffron : COL.white });
        T(s, `[Supporting figure ${i + 1}]`, { x, y: y + 0.7, w, h: 0.35, fontSize: 11, color: COL.spray });
      });
      T(s, 'Source: [Source]; KSA analysis', { x: M.l, y: 6.35, w: CW, h: 0.3, fontSize: 9.5, color: COL.spray, objectName: 'Source' });
    });
  add('layout.quote', { name: 'Quote', category: 'layouts', subcategory: 'Content', description: 'A serif italic pull quote with blade quote marks and attribution.', tags: ['quote', 'testimonial'] },
    'KSA_TITLE', (s) => {
      K.addBlade(s, M.l, BODY_Y + 0.15, 0.28, 0.36, { dir: 'right', color: COL.water, name: 'Quote mark open 1' });
      K.addBlade(s, M.l + 0.34, BODY_Y + 0.15, 0.28, 0.36, { dir: 'right', color: COL.water, name: 'Quote mark open 2' });
      T(s, '[A sentence from the text that carries the argument, set as a quotation. Never a new claim.]', { x: M.l + 0.9, y: BODY_Y, w: CW - 1.8, h: 2.6, fontSize: 28, fontFace: SERIF, italic: true, color: COL.deep, valign: 'top', lineSpacingMultiple: 1.25 });
      K.addBlade(s, W - M.r - 0.62, BODY_Y + 2.7, 0.28, 0.36, { dir: 'left', color: COL.saffron, name: 'Quote mark close 1' });
      K.addBlade(s, W - M.r - 0.28, BODY_Y + 2.7, 0.28, 0.36, { dir: 'left', color: COL.saffron, name: 'Quote mark close 2' });
      T(s, '[Full Name]', { x: M.l + 0.9, y: BODY_Y + 3.2, w: 6, h: 0.35, fontSize: 14, bold: true, color: COL.deep });
      T(s, '[Designation], [Organisation]', { x: M.l + 0.9, y: BODY_Y + 3.55, w: 6, h: 0.35, fontSize: 12, color: COL.slate });
    });
  add('layout.comparison', { name: 'Comparison, two options', category: 'layouts', subcategory: 'Content', description: 'Two option panels with heads, bullets and a verdict row; the recommended option is marked.', tags: ['comparison', 'options', 'versus'] },
    'KSA_TITLE', (s) => {
      const gap = 0.5, cw = (CW - gap) / 2, ch = BODY_H;
      [0, 1].forEach((i) => {
        const x = M.l + i * (cw + gap), rec = i === 1;
        R(s, x, BODY_Y, cw, ch, rec ? COL.deep : COL.mist, 'Option panel');
        T(s, `OPTION ${i === 0 ? 'A' : 'B'}`, { x: x + 0.4, y: BODY_Y + 0.3, w: 3, h: 0.3, fontSize: 10, bold: true, charSpacing: 2, color: rec ? COL.shallows : COL.water });
        if (rec) K.addTag(s, x + cw - 2.2, BODY_Y + 0.25, 1.8, 0.36, 'RECOMMENDED', { fill: COL.saffron, color: COL.deep, fontSize: 9 });
        T(s, `[Option ${i === 0 ? 'A' : 'B'} name]`, { x: x + 0.4, y: BODY_Y + 0.65, w: cw - 0.8, h: 0.5, fontSize: 20, bold: true, color: rec ? COL.white : COL.deep });
        T(s, [
          { text: '[What it involves]', options: { bullet: { indent: 14 }, breakLine: true, paraSpaceAfter: 8 } },
          { text: '[Cost and time]', options: { bullet: { indent: 14 }, breakLine: true, paraSpaceAfter: 8 } },
          { text: '[Main risk]', options: { bullet: { indent: 14 }, breakLine: true, paraSpaceAfter: 8 } },
          { text: '[What it needs to succeed]', options: { bullet: { indent: 14 } } },
        ], { x: x + 0.4, y: BODY_Y + 1.3, w: cw - 0.8, h: 2.0, fontSize: 14, color: rec ? COL.spray : COL.slate, valign: 'top', lineSpacingMultiple: 1.15 });
        s.addShape('line', { x: x + 0.4, y: BODY_Y + ch - 0.9, w: cw - 0.8, h: 0, line: { color: rec ? COL.undertow : COL.fog, width: 0.75 }, objectName: 'Rule' });
        T(s, '[Verdict in one line]', { x: x + 0.4, y: BODY_Y + ch - 0.75, w: cw - 0.8, h: 0.5, fontSize: 13, bold: true, color: rec ? COL.white : COL.deep });
      });
    });
  add('layout.timeline', { name: 'Timeline', category: 'layouts', subcategory: 'Content', description: 'Horizontal route line with five waypoint diamonds, dates and milestone text.', tags: ['timeline', 'milestones', 'roadmap'] },
    'KSA_TITLE', (s) => {
      const n = 5, cw = CW / n, ly = BODY_Y + 1.2;
      s.addShape('line', { x: M.l + cw / 2, y: ly, w: CW - cw, h: 0, line: { color: COL.water, width: 1.5, dashType: 'dash' }, objectName: 'Route line' });
      for (let i = 0; i < n; i++) {
        const x = M.l + i * cw, cx = x + cw / 2, last = i === n - 1;
        T(s, `[Month ${i + 1}]`, { x, y: ly - 0.75, w: cw, h: 0.35, fontSize: 11, bold: true, charSpacing: 1, color: COL.slate, align: 'center' });
        s.addShape('diamond', { x: cx - 0.16, y: ly - 0.16, w: 0.32, h: 0.32, fill: { color: last ? COL.saffron : COL.white }, line: { color: last ? COL.saffron : COL.water, width: 1.5 }, objectName: 'Waypoint' });
        T(s, `[Milestone ${i + 1}]`, { x: x + 0.15, y: ly + 0.4, w: cw - 0.3, h: 0.4, fontSize: 14, bold: true, color: COL.deep, align: 'center' });
        T(s, '[What is delivered and who signs it off]', { x: x + 0.15, y: ly + 0.85, w: cw - 0.3, h: 1.2, fontSize: 12, color: COL.slate, align: 'center', valign: 'top', lineSpacingMultiple: 1.15 });
      }
    });
  add('layout.team', { name: 'Team', category: 'layouts', subcategory: 'Content', description: 'Four team cards with portrait placeholder, name, designation and expertise.', tags: ['team', 'people', 'bios'] },
    'KSA_TITLE', (s) => {
      const gap = px(32), cw = (CW - 3 * gap) / 4, ch = BODY_H;
      ['AB', 'CD', 'EF', 'GH'].forEach((ini, i) => {
        const x = M.l + i * (cw + gap), y = BODY_Y;
        R(s, x, y, cw, ch, COL.mist, 'Team card');
        R(s, x + px(32), y + px(32), 1.1, 1.1, COL.deep, 'Portrait placeholder');
        T(s, ini, { x: x + px(32), y: y + px(32), w: 1.1, h: 1.1, fontSize: 22, bold: true, color: COL.white, align: 'center', valign: 'middle' });
        T(s, '[Full Name]', { x: x + px(32), y: y + 1.6, w: cw - px(64), h: 0.4, fontSize: 16, bold: true, color: COL.deep });
        T(s, '[Designation]', { x: x + px(32), y: y + 2.0, w: cw - px(64), h: 0.35, fontSize: 12, bold: true, color: COL.water });
        T(s, '[Cluster and areas of expertise, in one or two lines]', { x: x + px(32), y: y + 2.45, w: cw - px(64), h: 1.3, fontSize: 12.5, color: COL.slate, valign: 'top', lineSpacingMultiple: 1.15 });
      });
    });
  add('layout.closing', { name: 'Closing', category: 'layouts', subcategory: 'Covers', description: 'Thank-you slide with identifier, standfirst, contact block and reversed logo.', tags: ['closing', 'thank you', 'contact'] },
    'KSA_CLOSING', (s) => {
      s.addText('[One line that restates the promise]', { placeholder: 'subtitle' });
      s.addText([
        { text: '[Full Name], [Designation]', options: { bold: true, breakLine: true } },
        { text: '[name]@kayaksa.com · [+91 00000 00000]', options: { breakLine: true } },
        { text: 'www.kayaksa.com · [Office address], [City]' },
      ], { placeholder: 'contact' });
    }, { eyebrow: false });

  // ====================================================================== CHARTS
  const FY = ['FY21', 'FY22', 'FY23', 'FY24', 'FY25', 'FY26'];
  add('chart.column-highlight', { name: 'Column with highlight', category: 'charts', subcategory: 'Comparison', description: 'Single-series column chart with one Beacon Saffron bar for the point the title makes.', tags: ['column', 'bar', 'highlight'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 1 · [Measure], [unit], [period]');
      const vals = [10.2, 10.8, 11.4, 11.1, 9.7, 12.6];
      s.addChart(pres.charts.BAR, [{ name: '[Series]', labels: FY, values: vals }], chartOpts({
        barDir: 'col', barGapWidthPct: 60, chartColors: [COL.water, COL.water, COL.water, COL.water, COL.water, COL.saffron],
        showValue: true, dataLabelPosition: 'outEnd', dataLabelFormatCode: '0.0', valAxisMinVal: 0, valAxisLabelFormatCode: '0',
      }));
      source(s);
    });
  add('chart.bar-sorted', { name: 'Sorted horizontal bar', category: 'charts', subcategory: 'Comparison', description: 'Horizontal bars sorted largest first; the client bar in saffron, peers in Riverstone.', tags: ['bar', 'ranking', 'peers'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 2 · [Measure] by [group], [unit], [period]');
      const labels = ['[Peer E]', '[Peer D]', '[Peer C]', '[Peer B]', '[Peer A]', '[Client]'];
      const vals = [29.4, 33.0, 36.9, 38.5, 41.8, 44.2];
      s.addChart(pres.charts.BAR, [{ name: '[Measure]', labels, values: vals }], chartOpts({
        barDir: 'bar', barGapWidthPct: 45, chartColors: [COL.river, COL.river, COL.river, COL.river, COL.river, COL.saffron],
        showValue: true, dataLabelPosition: 'outEnd', dataLabelFormatCode: '0.0', valAxisHidden: true, valGridLine: { style: 'none' }, catAxisLineShow: false,
      }));
      source(s);
    });
  add('chart.column-grouped', { name: 'Grouped column', category: 'charts', subcategory: 'Comparison', description: 'Two or three series side by side in the categorical order: Open Water, Tidewater Blue, Kelp Green.', tags: ['column', 'grouped', 'clustered'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 3 · [Measure] by [series], [unit], [period]');
      s.addChart(pres.charts.BAR, [
        { name: '[Series A]', labels: FY.slice(1), values: [42, 48, 53, 57, 64] },
        { name: '[Series B]', labels: FY.slice(1), values: [31, 35, 36, 41, 47] },
        { name: '[Series C]', labels: FY.slice(1), values: [18, 21, 26, 28, 33] },
      ], chartOpts({ barDir: 'col', barGapWidthPct: 80, barGrouping: 'clustered', chartColors: [CAT[0], CAT[1], CAT[2]], showLegend: true, legendPos: 'b', valAxisMinVal: 0 }));
      source(s);
    });
  add('chart.column-stacked', { name: 'Stacked column', category: 'charts', subcategory: 'Composition', description: 'Stacked columns with up to four segments and labels inside the bars.', tags: ['column', 'stacked', 'mix'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 4 · [Measure] by [segment], [unit], [period]');
      s.addChart(pres.charts.BAR, [
        { name: '[Segment 1]', labels: FY.slice(2), values: [67, 65, 63, 59] },
        { name: '[Segment 2]', labels: FY.slice(2), values: [19, 19, 19, 18] },
        { name: '[Segment 3]', labels: FY.slice(2), values: [9, 10, 11, 12] },
        { name: '[Segment 4]', labels: FY.slice(2), values: [5, 6, 7, 11] },
      ], chartOpts({ barDir: 'col', barGapWidthPct: 70, barGrouping: 'stacked', chartColors: [CAT[0], CAT[1], CAT[2], COL.saffron], showLegend: true, legendPos: 'b', showValue: true, dataLabelPosition: 'ctr', dataLabelColor: COL.white, valAxisMinVal: 0 }));
      source(s);
    });
  add('chart.line-benchmark', { name: 'Line with benchmark', category: 'charts', subcategory: 'Trend', description: 'One Open Water line with a dashed Storm Slate benchmark line, labelled.', tags: ['line', 'benchmark', 'target', 'trend'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 5 · [Measure], [unit], [period]; benchmark = [peer median]');
      const q = ['Q1', 'Q2', 'Q3', 'Q4', 'Q1', 'Q2', 'Q3', 'Q4'];
      s.addChart([
        { type: pres.charts.LINE, data: [{ name: '[Client]', labels: q, values: [12.1, 12.8, 13.4, 13.9, 14.6, 15.2, 15.9, 16.4] }], options: { chartColors: [COL.water], lineSize: 2, lineDataSymbol: 'none' } },
        { type: pres.charts.LINE, data: [{ name: '[Benchmark 14.0]', labels: q, values: [14, 14, 14, 14, 14, 14, 14, 14] }], options: { chartColors: [COL.slate], lineSize: 1.25, lineDataSymbol: 'none', lineDash: 'dash' } },
      ], chartOpts({ showLegend: true, legendPos: 'b', valAxisMinVal: 0, valAxes: [{ showValAxisTitle: false, valAxisMinVal: 0, valGridLine: { color: COL.fog, size: 0.75 }, valAxisLabelFontFace: '+mn-lt', valAxisLabelFontSize: 10, valAxisLabelColor: COL.slate }], catAxes: [{ catAxisLabelFontFace: '+mn-lt', catAxisLabelFontSize: 10, catAxisLabelColor: COL.slate }] }));
      source(s);
    });
  add('chart.line-multi', { name: 'Multi-line', category: 'charts', subcategory: 'Trend', description: 'Up to five lines in the categorical order, with a bottom legend; label line ends in PowerPoint if you can.', tags: ['line', 'multi', 'series'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 6 · [Measure] by [series], [unit], [period]');
      s.addChart(pres.charts.LINE, [
        { name: '[Series A]', labels: FY, values: [11.2, 9.8, 8.1, 6.4, 5.2, 4.4] },
        { name: '[Series B]', labels: FY, values: [7.6, 6.9, 5.8, 4.6, 3.9, 3.4] },
        { name: '[Series C]', labels: FY, values: [5.1, 5.6, 5.9, 4.2, 3.4, 3.0] },
        { name: '[Series D]', labels: FY, values: [3.9, 3.5, 2.8, 2.3, 1.9, 1.7] },
      ], chartOpts({ chartColors: [CAT[0], CAT[1], CAT[2], CAT[3]], lineSize: 2, lineDataSymbol: 'none', showLegend: true, legendPos: 'b', valAxisMinVal: 0 }));
      source(s);
    });
  add('chart.area', { name: 'Area', category: 'charts', subcategory: 'Trend', description: 'Single area from a zero baseline in Open Water at reduced opacity.', tags: ['area', 'volume', 'trend'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 7 · [Measure], [unit], monthly');
      const mo = ['Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec', 'Jan', 'Feb', 'Mar'];
      s.addChart(pres.charts.AREA, [{ name: '[Measure]', labels: mo, values: [18.2, 19.1, 20.4, 21.0, 21.8, 23.1, 24.6, 24.1, 25.3, 26.0, 26.4, 27.2] }],
        chartOpts({ chartColors: [COL.water], chartColorsOpacity: 35, lineSize: 2, valAxisMinVal: 0 }));
      source(s);
    });
  add('chart.donut', { name: 'Donut', category: 'charts', subcategory: 'Composition', description: 'Five segments at most, 18% ring, total stated in the centre, legend with values on the right.', tags: ['donut', 'share', 'part to whole'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 8 · [Measure] by [segment], % of total, [period]');
      const cw = 5.2;
      s.addChart(pres.charts.DOUGHNUT, [{ name: '[Measure]', labels: ['[Segment 1]', '[Segment 2]', '[Segment 3]', '[Segment 4]', 'Other'], values: [36, 25, 19, 11, 9] }],
        chartOpts({ x: CX - cw / 2 - 1.6, w: cw, holeSize: 82, chartColors: [COL.water, COL.gold, COL.slate, COL.tide, COL.river], showLegend: false, showLabel: false, showValue: false, showPercent: false, dataBorder: { pt: 2, color: COL.white } }));
      T(s, '[412]', { x: CX - cw / 2 - 1.6, y: BODY_Y + BODY_H / 2 - 0.5, w: cw, h: 0.6, fontSize: 32, bold: true, color: COL.deep, align: 'center' });
      T(s, '[unit]', { x: CX - cw / 2 - 1.6, y: BODY_Y + BODY_H / 2 + 0.1, w: cw, h: 0.35, fontSize: 12, color: COL.slate, align: 'center' });
      // legend as text rows with swatches
      const lx = CX + 1.6, ly = BODY_Y + 0.9;
      [['[Segment 1]', '36%', COL.water], ['[Segment 2]', '25%', COL.gold], ['[Segment 3]', '19%', COL.slate], ['[Segment 4]', '11%', COL.tide], ['Other', '9%', COL.river]].forEach((r, i) => {
        const y = ly + i * 0.5;
        R(s, lx, y + 0.07, 0.18, 0.18, r[2], 'Legend swatch');
        T(s, r[0], { x: lx + 0.3, y, w: 2.2, h: 0.32, fontSize: 12, color: COL.deep });
        T(s, r[1], { x: lx + 2.5, y, w: 0.8, h: 0.32, fontSize: 12, bold: true, color: COL.deep, align: 'right' });
        s.addShape('line', { x: lx, y: y + 0.42, w: 3.3, h: 0, line: { color: COL.fog, width: 0.75 }, objectName: 'Hairline' });
      });
      source(s);
    });
  add('chart.waterfall', { name: 'Waterfall', category: 'charts', subcategory: 'Composition', description: 'Bridge from start to end built from stacked columns with an invisible base series; edit the data sheet to re-bridge.', tags: ['waterfall', 'bridge', 'walk'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 9 · [Measure] bridge, [unit], [period A] to [period B]');
      const labels = ['[Start]', '[Driver 1]', '[Driver 2]', '[Driver 3]', '[Driver 4]', '[End]'];
      const base = [0, 100, 128, 143, 118, 0];
      const rise = [100, 28, 15, 0, 0, 131];
      const fall = [0, 0, 0, 25, 12, 0];
      s.addChart(pres.charts.BAR, [
        { name: 'Base', labels, values: base },
        { name: 'Increase', labels, values: rise },
        { name: 'Decrease', labels, values: fall },
      ], chartOpts({ barDir: 'col', barGapWidthPct: 40, barGrouping: 'stacked', chartColors: [COL.white, COL.water, COL.clay], showValue: true, dataLabelPosition: 'inEnd', dataLabelColor: COL.white, dataLabelFormatCode: '0;0;;', valAxisMinVal: 0 }));
      source(s);
    });
  add('chart.bullet', { name: 'Bullet, actual vs target', category: 'charts', subcategory: 'Comparison', description: 'Horizontal bars for actual (Open Water) against target (Storm Slate) for a set of KPIs.', tags: ['bullet', 'target', 'kpi'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 10 · [KPI set], actual vs target, [period]');
      const labels = ['[KPI 5]', '[KPI 4]', '[KPI 3]', '[KPI 2]', '[KPI 1]'];
      s.addChart(pres.charts.BAR, [
        { name: 'Actual', labels, values: [71, 62, 98, 92, 86] },
        { name: 'Target', labels, values: [90, 80, 98, 85, 95] },
      ], chartOpts({ barDir: 'bar', barGapWidthPct: 55, chartColors: [COL.water, COL.slate], showLegend: true, legendPos: 'b', showValue: true, dataLabelPosition: 'outEnd', valAxisMinVal: 0, valAxisMaxVal: 110, valAxisHidden: true, valGridLine: { style: 'none' }, catAxisLineShow: false }));
      source(s);
    });
  add('chart.small-multiples', { name: 'Small multiples', category: 'charts', subcategory: 'Trend', description: 'A 2 x 2 grid of line charts, each asking one question; the series in focus is Open Water, the rest are ghosted in Fog.', tags: ['small multiples', 'grid', 'line'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 11 · [Measure] by [panel], [unit], [period]');
      const gap = 0.4, cw = (CW - gap) / 2, ch = (BODY_H - 0.2 - gap) / 2;
      const data = [[3.1, 3.6, 4.4, 4.9, 5.8], [2.2, 2.4, 2.1, 2.9, 3.3], [4.0, 3.7, 3.5, 3.1, 2.8], [1.9, 2.6, 3.4, 4.6, 5.1]];
      for (let i = 0; i < 4; i++) {
        const x = M.l + (i % 2) * (cw + gap), y = BODY_Y + 0.2 + Math.floor(i / 2) * (ch + gap);
        T(s, `[Panel ${i + 1}]`, { x, y: y - 0.05, w: cw, h: 0.3, fontSize: 11, bold: true, color: COL.deep });
        const series = [0, 1, 2, 3].filter((j) => j !== i).map((j) => ({ name: `[Panel ${j + 1}]`, labels: FY.slice(1), values: data[j] }));
        series.push({ name: `[Panel ${i + 1}]`, labels: FY.slice(1), values: data[i] });
        s.addChart(pres.charts.LINE, series, K.chartBase({ x, y: y + 0.25, w: cw, h: ch - 0.25, chartColors: [COL.fog, COL.fog, COL.fog, COL.water], lineSize: 1.5, lineDataSymbol: 'none', valAxisMinVal: 0, valAxisLabelFontSize: 9, catAxisLabelFontSize: 9 }));
      }
      source(s);
    });
  add('chart.combo', { name: 'Combo column and line', category: 'charts', subcategory: 'Trend', description: 'Columns for a level (left axis) with a line for a rate (right axis), both axes declared.', tags: ['combo', 'column', 'line', 'secondary axis'] },
    'KSA_TITLE', (s) => {
      subtitle(s, 'EXHIBIT 12 · [Level], [unit] (columns) and [rate], % (line), [period]');
      const base = K.chartBase({});
      s.addChart([
        { type: pres.charts.BAR, data: [{ name: '[Level]', labels: FY, values: [4186, 4812, 5463, 6120, 6890, 7540] }], options: { barDir: 'col', barGapWidthPct: 60, chartColors: [COL.water] } },
        { type: pres.charts.LINE, data: [{ name: '[Rate, %]', labels: FY, values: [15.6, 16.3, 17.4, 18.6, 19.1, 19.8] }], options: { chartColors: [COL.saffron], lineSize: 2, lineDataSymbol: 'circle', lineDataSymbolSize: 6, secondaryValAxis: true, secondaryCatAxis: true } },
      ], {
        ...base, x: M.l, y: BODY_Y, w: CW, h: BODY_H, showLegend: true, legendPos: 'b',
        valAxes: [
          { showValAxisTitle: false, valAxisMinVal: 0, valGridLine: { color: COL.fog, size: 0.75 }, valAxisLabelFontFace: '+mn-lt', valAxisLabelFontSize: 10, valAxisLabelColor: COL.slate },
          { showValAxisTitle: false, valAxisMinVal: 0, valGridLine: { style: 'none' }, valAxisLabelFontFace: '+mn-lt', valAxisLabelFontSize: 10, valAxisLabelColor: COL.slate, valAxisLabelFormatCode: '0"%"' },
        ],
        catAxes: [{ catAxisTitle: '', catAxisLabelFontFace: '+mn-lt', catAxisLabelFontSize: 10, catAxisLabelColor: COL.slate }, { catAxisHidden: true }],
      });
      source(s);
    });

  // ====================================================================== DIAGRAMS (grouped)
  const DG = { category: 'diagrams', group: true };
  const label = (s, text, x, y, w, h, o = {}) => T(s, text, { x, y, w, h, fontSize: 13, color: COL.slate, valign: 'top', lineSpacingMultiple: 1.15, ...o });

  add('diagram.process-chevrons', { ...DG, name: 'Process, 4 chevrons', subcategory: 'Process', description: 'Four chevron steps in Open Water with the final step in Beacon Saffron, titles and text beneath.', tags: ['process', 'chevron', 'steps'] },
    'KSA_TITLE', (s) => {
      const n = 4, gap = 0.12, cw = (CW - (n - 1) * gap) / n;
      for (let i = 0; i < n; i++) {
        const x = M.l + i * (cw + gap), last = i === n - 1;
        s.addShape(i === 0 ? 'homePlate' : 'chevron', { x, y: BODY_Y + 0.2, w: cw, h: 0.8, fill: { color: last ? COL.saffron : COL.water }, line: { color: last ? COL.saffron : COL.water, width: 0 }, objectName: `Step ${i + 1}` });
        T(s, `0${i + 1}`, { x: x + (i === 0 ? 0.3 : 0.6), y: BODY_Y + 0.2, w: cw - 1.0, h: 0.8, fontSize: 16, bold: true, color: last ? COL.deep : COL.white, valign: 'middle' });
        T(s, `[Step ${i + 1} title]`, { x: x + 0.1, y: BODY_Y + 1.25, w: cw - 0.6, h: 0.45, fontSize: 16, bold: true, color: COL.deep });
        label(s, '[What happens in this step, who does it and what it produces.]', x + 0.1, BODY_Y + 1.75, cw - 0.6, 1.6);
      }
    });
  add('diagram.cycle', { ...DG, name: 'Cycle, 4 stages', subcategory: 'Process', description: 'Four stages around a centre, joined by arrows in a continuous loop.', tags: ['cycle', 'loop', 'stages'] },
    'KSA_TITLE', (s) => {
      const cx = M.l + 3.6, cy = BODY_Y + BODY_H / 2, r = 1.55, nw = 1.9, nh = 0.7;
      const pos = [[cx, cy - r], [cx + r * 1.25, cy], [cx, cy + r], [cx - r * 1.25, cy]];
      s.addShape('ellipse', { x: cx - 0.75, y: cy - 0.75, w: 1.5, h: 1.5, fill: { color: COL.mist }, line: { color: COL.mist, width: 0 }, objectName: 'Centre' });
      T(s, '[Cycle name]', { x: cx - 0.75, y: cy - 0.75, w: 1.5, h: 1.5, fontSize: 12, bold: true, color: COL.deep, align: 'center', valign: 'middle' });
      // arrows between nodes (clockwise)
      const arrow = (x1, y1, x2, y2) => s.addShape('line', { x: Math.min(x1, x2), y: Math.min(y1, y2), w: Math.abs(x2 - x1), h: Math.abs(y2 - y1), flipH: x2 < x1, flipV: y2 < y1, line: { color: COL.water, width: 1.5, endArrowType: 'triangle' }, objectName: 'Arrow' });
      arrow(cx + nw / 2 + 0.1, cy - r + 0.1, cx + r * 1.25 - nw / 2 - 0.1, cy - nh / 2 - 0.1);
      arrow(cx + r * 1.25 - nw / 2 - 0.1, cy + nh / 2 + 0.1, cx + nw / 2 + 0.1, cy + r - 0.1);
      arrow(cx - nw / 2 - 0.1, cy + r - 0.1, cx - r * 1.25 + nw / 2 + 0.1, cy + nh / 2 + 0.1);
      arrow(cx - r * 1.25 + nw / 2 + 0.1, cy - nh / 2 - 0.1, cx - nw / 2 - 0.1, cy - r + 0.1);
      pos.forEach((p, i) => {
        const last = i === 3;
        s.addShape('roundRect', { x: p[0] - nw / 2, y: p[1] - nh / 2, w: nw, h: nh, rectRadius: 0.06, fill: { color: last ? COL.saffron : COL.water }, line: { color: last ? COL.saffron : COL.water, width: 0 }, objectName: `Stage ${i + 1}` });
        T(s, `0${i + 1}  [Stage ${i + 1}]`, { x: p[0] - nw / 2, y: p[1] - nh / 2, w: nw, h: nh, fontSize: 13, bold: true, color: last ? COL.deep : COL.white, align: 'center', valign: 'middle' });
      });
      // legend on the right
      const lx = M.l + 7.6;
      for (let i = 0; i < 4; i++) {
        const y = BODY_Y + 0.2 + i * 1.0;
        T(s, `0${i + 1}`, { x: lx, y, w: 0.5, h: 0.4, fontSize: 16, bold: true, color: i === 3 ? COL.saffron : COL.water });
        T(s, `[Stage ${i + 1}]`, { x: lx + 0.5, y, w: 3.4, h: 0.4, fontSize: 15, bold: true, color: COL.deep });
        label(s, '[What this stage does and what it hands to the next.]', lx + 0.5, y + 0.4, 3.4, 0.55, { fontSize: 12 });
      }
    });
  add('diagram.pyramid', { ...DG, name: 'Pyramid, 4 levels', subcategory: 'Hierarchy', description: 'Four flat-cut levels from Deep Current to Shallows with a saffron apex; labels to the right.', tags: ['pyramid', 'hierarchy', 'levels'] },
    'KSA_TITLE', (s) => {
      const bw = 6.0, bx = M.l + 0.4, top = BODY_Y + 0.1, lh = (BODY_H - 0.3) / 4, gap = 0.06;
      const cols = [COL.saffron, COL.water, COL.lagoon, COL.deep];
      for (let i = 0; i < 4; i++) {
        const wTop = bw * (i / 4), wBot = bw * ((i + 1) / 4);
        const y = top + i * lh, h = lh - gap;
        const x = bx + (bw - wBot) / 2, inset = (wBot - wTop) / 2;
        const pts = i === 0
          ? [{ x: wBot / 2, y: 0 }, { x: wBot, y: h }, { x: 0, y: h }, { close: true }]
          : [{ x: inset, y: 0 }, { x: wBot - inset, y: 0 }, { x: wBot, y: h }, { x: 0, y: h }, { close: true }];
        s.addShape('custGeom', { x, y, w: wBot, h, points: pts, fill: { color: cols[i] }, line: { color: cols[i], width: 0 }, objectName: `Level ${i + 1}` });
        if (i > 0) T(s, `[Level ${i + 1}]`, { x, y, w: wBot, h, fontSize: 13, bold: true, color: COL.white, align: 'center', valign: 'middle' });
        const lx = bx + bw + 0.5;
        s.addShape('line', { x: lx - 0.3, y: y + h / 2, w: 0.25, h: 0, line: { color: COL.river, width: 0.75 }, objectName: 'Leader' });
        T(s, i === 0 ? '[Apex]' : `[Level ${i + 1} name]`, { x: lx, y: y + h / 2 - 0.4, w: CW - (lx - M.l), h: 0.4, fontSize: 15, bold: true, color: COL.deep });
        label(s, '[What belongs at this level and who owns it.]', lx, y + h / 2, CW - (lx - M.l), 0.5, { fontSize: 12 });
      }
    });
  add('diagram.funnel', { ...DG, name: 'Funnel, 4 stages', subcategory: 'Process', description: 'Four narrowing stages with counts, from Deep Current to a saffron outcome.', tags: ['funnel', 'conversion', 'pipeline'] },
    'KSA_TITLE', (s) => {
      const bw = 6.0, bx = M.l + 0.4, top = BODY_Y + 0.1, lh = (BODY_H - 0.3) / 4, gap = 0.06;
      const cols = [COL.deep, COL.lagoon, COL.water, COL.saffron];
      const vals = ['[1,240]', '[610]', '[214]', '[52]'];
      for (let i = 0; i < 4; i++) {
        const wTop = bw * (1 - i * 0.2), wBot = bw * (1 - (i + 1) * 0.2);
        const y = top + i * lh, h = lh - gap;
        const x = bx + (bw - wTop) / 2, inset = (wTop - wBot) / 2;
        s.addShape('custGeom', { x, y, w: wTop, h, points: [{ x: 0, y: 0 }, { x: wTop, y: 0 }, { x: wTop - inset, y: h }, { x: inset, y: h }, { close: true }], fill: { color: cols[i] }, line: { color: cols[i], width: 0 }, objectName: `Stage ${i + 1}` });
        T(s, vals[i], { x, y, w: wTop, h, fontSize: 16, bold: true, color: i === 3 ? COL.deep : COL.white, align: 'center', valign: 'middle' });
        const lx = bx + bw + 0.5;
        s.addShape('line', { x: lx - 0.3, y: y + h / 2, w: 0.25, h: 0, line: { color: COL.river, width: 0.75 }, objectName: 'Leader' });
        T(s, `[Stage ${i + 1}]`, { x: lx, y: y + h / 2 - 0.4, w: CW - (lx - M.l), h: 0.4, fontSize: 15, bold: true, color: COL.deep });
        label(s, '[Definition of the stage and the conversion from the one above.]', lx, y + h / 2, CW - (lx - M.l), 0.5, { fontSize: 12 });
      }
    });
  add('diagram.matrix-2x2', { ...DG, name: 'Matrix, 2 x 2', subcategory: 'Framework', description: 'Two-by-two with labelled axes; the priority quadrant in Open Water, the rest in Sea Mist.', tags: ['matrix', '2x2', 'prioritisation'] },
    'KSA_TITLE', (s) => {
      const gx = M.l + 0.9, gy = BODY_Y + 0.1, gw = 7.4, gh = BODY_H - 0.6, gap = 0.08;
      const qw = (gw - gap) / 2, qh = (gh - gap) / 2;
      const quads = [['[High / Low]', 0, 0, COL.mist, COL.deep], ['[High / High]', 1, 0, COL.water, COL.white], ['[Low / Low]', 0, 1, COL.mist, COL.deep], ['[Low / High]', 1, 1, COL.mist, COL.deep]];
      quads.forEach((q, i) => {
        const x = gx + q[1] * (qw + gap), y = gy + q[2] * (qh + gap);
        R(s, x, y, qw, qh, q[3], `Quadrant ${i + 1}`);
        T(s, q[0], { x: x + 0.25, y: y + 0.2, w: qw - 0.5, h: 0.4, fontSize: 14, bold: true, color: q[4] });
        T(s, '[What sits here and what to do with it]', { x: x + 0.25, y: y + 0.6, w: qw - 0.5, h: 0.8, fontSize: 12, color: q[1] === 1 && q[2] === 0 ? COL.spray : COL.slate, valign: 'top' });
      });
      // axes
      s.addShape('line', { x: gx - 0.3, y: gy, w: 0, h: gh, flipV: true, line: { color: COL.deep, width: 1.5, endArrowType: 'triangle' }, objectName: 'Y axis' });
      s.addShape('line', { x: gx, y: gy + gh + 0.3, w: gw, h: 0, line: { color: COL.deep, width: 1.5, endArrowType: 'triangle' }, objectName: 'X axis' });
      T(s, '[VERTICAL AXIS]', { x: gx - 0.6 - gh / 2, y: gy + gh / 2 - 0.15, w: gh, h: 0.3, fontSize: 10, bold: true, charSpacing: 2, color: COL.slate, align: 'center', rotate: 270 });
      T(s, '[HORIZONTAL AXIS]', { x: gx, y: gy + gh + 0.38, w: gw, h: 0.3, fontSize: 10, bold: true, charSpacing: 2, color: COL.slate, align: 'center' });
      // markers
      [[gx + qw + gap + 1.4, gy + 0.9, '1'], [gx + qw + gap + 2.6, gy + 1.6, '2'], [gx + 1.2, gy + qh + gap + 1.2, '3']].forEach((m) => {
        s.addShape('ellipse', { x: m[0], y: m[1], w: 0.4, h: 0.4, fill: { color: m[2] === '1' ? COL.saffron : COL.deep }, line: { color: COL.white, width: 1.5 }, objectName: 'Item marker' });
        T(s, m[2], { x: m[0], y: m[1], w: 0.4, h: 0.4, fontSize: 11, bold: true, color: COL.white, align: 'center', valign: 'middle' });
      });
      const lx = gx + gw + 0.6;
      ['[Item one]', '[Item two]', '[Item three]'].forEach((t, i) => {
        T(s, `${i + 1}  ${t}`, { x: lx, y: gy + 0.1 + i * 0.5, w: W - M.r - lx, h: 0.4, fontSize: 13, bold: true, color: COL.deep });
      });
    });
  add('diagram.venn', { ...DG, name: 'Venn, 3 sets', subcategory: 'Framework', description: 'Three translucent circles in Open Water, Tidewater Blue and Beacon Saffron with a labelled overlap.', tags: ['venn', 'overlap', 'intersection'] },
    'KSA_TITLE', (s) => {
      const d = 3.3, cx = M.l + 3.5, cy = BODY_Y + BODY_H / 2 + 0.2;
      const circles = [[cx - 0.95, cy - 0.85, COL.water, '[Set A]'], [cx + 0.95, cy - 0.85, COL.tide, '[Set B]'], [cx, cy + 0.8, COL.saffron, '[Set C]']];
      circles.forEach((c, i) => {
        s.addShape('ellipse', { x: c[0] - d / 2, y: c[1] - d / 2, w: d, h: d, fill: { color: c[2], transparency: 45 }, line: { color: c[2], width: 1 }, objectName: `Set ${i + 1}` });
      });
      T(s, '[Set A]', { x: cx - 0.95 - d / 2 + 0.3, y: cy - 0.85 - 0.9, w: 1.6, h: 0.4, fontSize: 14, bold: true, color: COL.deep });
      T(s, '[Set B]', { x: cx + 0.95 + d / 2 - 1.9, y: cy - 0.85 - 0.9, w: 1.6, h: 0.4, fontSize: 14, bold: true, color: COL.deep, align: 'right' });
      T(s, '[Set C]', { x: cx - 0.8, y: cy + 0.8 + d / 2 - 0.6, w: 1.6, h: 0.4, fontSize: 14, bold: true, color: COL.deep, align: 'center' });
      T(s, '[Overlap]', { x: cx - 0.8, y: cy - 0.35, w: 1.6, h: 0.4, fontSize: 12, bold: true, color: COL.deep, align: 'center' });
      const lx = M.l + 7.6;
      ['[Set A]', '[Set B]', '[Set C]', '[Overlap]'].forEach((t, i) => {
        const y = BODY_Y + 0.2 + i * 1.0;
        R(s, lx, y + 0.08, 0.22, 0.22, [COL.water, COL.tide, COL.saffron, COL.deep][i], 'Swatch');
        T(s, t, { x: lx + 0.4, y, w: 3.5, h: 0.4, fontSize: 15, bold: true, color: COL.deep });
        label(s, '[What belongs to this set, in one line.]', lx + 0.4, y + 0.4, 3.5, 0.5, { fontSize: 12 });
      });
    });
  add('diagram.hub-spoke', { ...DG, name: 'Hub and spoke, 6', subcategory: 'Framework', description: 'A Deep Current hub with six spokes; one spoke in saffron for the item in focus.', tags: ['hub', 'spoke', 'network', 'stakeholders'] },
    'KSA_TITLE', (s) => {
      const cx = M.l + CW / 2, cy = BODY_Y + BODY_H / 2, rr = 1.75, nd = 1.15;
      for (let i = 0; i < 6; i++) {
        const a = -Math.PI / 2 + i * Math.PI / 3, nx = cx + Math.cos(a) * rr * 1.7, ny = cy + Math.sin(a) * rr;
        s.addShape('line', { x: Math.min(cx, nx), y: Math.min(cy, ny), w: Math.abs(nx - cx) || 0.001, h: Math.abs(ny - cy) || 0.001, flipH: nx < cx, flipV: ny < cy, line: { color: i === 0 ? COL.saffron : COL.river, width: 1.25 }, objectName: 'Spoke' });
      }
      for (let i = 0; i < 6; i++) {
        const a = -Math.PI / 2 + i * Math.PI / 3, nx = cx + Math.cos(a) * rr * 1.7, ny = cy + Math.sin(a) * rr, focus = i === 0;
        s.addShape('ellipse', { x: nx - nd / 2, y: ny - nd / 2, w: nd, h: nd, fill: { color: focus ? COL.saffron : COL.water }, line: { color: focus ? COL.saffron : COL.water, width: 0 }, objectName: `Node ${i + 1}` });
        T(s, `[Node ${i + 1}]`, { x: nx - nd / 2, y: ny - nd / 2, w: nd, h: nd, fontSize: 11, bold: true, color: focus ? COL.deep : COL.white, align: 'center', valign: 'middle' });
      }
      s.addShape('ellipse', { x: cx - 0.8, y: cy - 0.8, w: 1.6, h: 1.6, fill: { color: COL.deep }, line: { color: COL.deep, width: 0 }, objectName: 'Hub' });
      T(s, '[Hub]', { x: cx - 0.8, y: cy - 0.8, w: 1.6, h: 1.6, fontSize: 14, bold: true, color: COL.white, align: 'center', valign: 'middle' });
    });
  add('diagram.roadmap', { ...DG, name: 'Roadmap with milestones', subcategory: 'Process', description: 'Three phase bars over a quarter grid with milestone diamonds on a route line.', tags: ['roadmap', 'gantt', 'milestones', 'phases'] },
    'KSA_TITLE', (s) => {
      const lx = M.l + 2.2, gw = CW - 2.2, cols = 6, cw = gw / cols, top = BODY_Y;
      ['Q1', 'Q2', 'Q3', 'Q4', 'Q1', 'Q2'].forEach((q, i) => {
        T(s, `[${q}]`, { x: lx + i * cw, y: top, w: cw, h: 0.3, fontSize: 10, bold: true, charSpacing: 1, color: COL.slate, align: 'center' });
        s.addShape('line', { x: lx + i * cw, y: top + 0.35, w: 0, h: BODY_H - 1.2, line: { color: COL.fog, width: 0.75 }, objectName: 'Grid' });
      });
      const phases = [['[Phase 1: Diagnose]', 0, 1.6, COL.deep], ['[Phase 2: Decide]', 1.4, 2.0, COL.water], ['[Phase 3: Deliver]', 3.2, 2.8, COL.shallows]];
      phases.forEach((p, i) => {
        const y = top + 0.6 + i * 0.85;
        T(s, p[0], { x: M.l, y, w: 2.1, h: 0.5, fontSize: 12, bold: true, color: COL.deep, valign: 'middle' });
        R(s, lx + p[1] * cw, y, p[2] * cw, 0.5, p[3], `Phase ${i + 1}`);
      });
      const ry = top + 0.6 + 3 * 0.85 + 0.5;
      s.addShape('line', { x: lx, y: ry, w: gw, h: 0, line: { color: COL.water, width: 1.5, dashType: 'dash' }, objectName: 'Route line' });
      [[1.55, '[Read-out]'], [3.35, '[Board decision]'], [5.9, '[Go live]']].forEach((m, i) => {
        const x = lx + m[0] * cw, last = i === 2;
        s.addShape('diamond', { x: x - 0.15, y: ry - 0.15, w: 0.3, h: 0.3, fill: { color: last ? COL.saffron : COL.white }, line: { color: last ? COL.saffron : COL.water, width: 1.5 }, objectName: 'Milestone' });
        T(s, m[1], { x: x - 0.9, y: ry + 0.25, w: 1.8, h: 0.35, fontSize: 11, bold: true, color: COL.deep, align: 'center' });
      });
      T(s, 'MILESTONES', { x: M.l, y: ry - 0.2, w: 2.1, h: 0.4, fontSize: 10, bold: true, charSpacing: 2, color: COL.slate, valign: 'middle' });
    });
  add('diagram.maturity-ladder', { ...DG, name: 'Maturity ladder, 5 steps', subcategory: 'Framework', description: 'Five rising steps from Sea Mist to Deep Current with level names; the current level marked.', tags: ['maturity', 'ladder', 'stages'] },
    'KSA_TITLE', (s) => {
      const n = 5, gap = 0.1, cw = (CW - (n - 1) * gap) / n, base = BODY_B - 0.1, step = 0.55, minH = 1.0;
      const cols = [COL.spray, COL.shallows, COL.water, COL.lagoon, COL.deep];
      for (let i = 0; i < n; i++) {
        const x = M.l + i * (cw + gap), h = minH + i * step, y = base - h, dark = i >= 2;
        R(s, x, y, cw, h, cols[i], `Level ${i + 1}`);
        T(s, `LEVEL ${i + 1}`, { x: x + 0.2, y: y + 0.15, w: cw - 0.4, h: 0.3, fontSize: 10, bold: true, charSpacing: 2, color: dark ? COL.spray : COL.deep });
        T(s, `[Level ${i + 1} name]`, { x: x + 0.2, y: y + 0.45, w: cw - 0.4, h: 0.45, fontSize: 14, bold: true, color: dark ? COL.white : COL.deep });
        T(s, `[What this level looks like in practice]`, { x: x + 0.2, y: BODY_Y, w: cw - 0.4, h: y - BODY_Y - 0.55, fontSize: 11.5, color: COL.slate, valign: 'bottom', lineSpacingMultiple: 1.15 });
      }
      // current-level marker on level 3
      const mx = M.l + 2 * (cw + gap) + cw / 2;
      s.addShape('diamond', { x: mx - 0.16, y: base - (minH + 2 * step) - 0.42, w: 0.32, h: 0.32, fill: { color: COL.saffron }, line: { color: COL.saffron, width: 0 }, objectName: 'You are here' });
    });
  add('diagram.org-chart', { ...DG, name: 'Organisation chart, 3 levels', subcategory: 'Hierarchy', description: 'One role at the top, three below and six at the base, joined by elbow connectors.', tags: ['org chart', 'structure', 'hierarchy', 'governance'] },
    'KSA_TITLE', (s) => {
      const bw = 2.1, bh = 0.62, cx = M.l + CW / 2;
      const box = (x, y, text, fill, color, name, w = bw) => { s.addShape('rect', { x, y, w, h: bh, fill: { color: fill }, line: { color: fill, width: 0 }, objectName: name }); T(s, text, { x, y, w, h: bh, fontSize: 12, bold: true, color, align: 'center', valign: 'middle' }); };
      const vline = (x, y, h) => s.addShape('line', { x, y, w: 0, h, line: { color: COL.river, width: 1 }, objectName: 'Connector' });
      const hline = (x, y, w) => s.addShape('line', { x, y, w, h: 0, line: { color: COL.river, width: 1 }, objectName: 'Connector' });
      const y1 = BODY_Y, y2 = BODY_Y + 1.5, y3 = BODY_Y + 3.0;
      const xs2 = [cx - 3.7, cx, cx + 3.7];
      vline(cx, y1 + bh, y2 - (y1 + bh) - 0.3); hline(xs2[0], y2 - 0.3, xs2[2] - xs2[0]);
      xs2.forEach((x, i) => { vline(x, y2 - 0.3, 0.3); vline(x, y2 + bh, 0.3); hline(x - 0.9, y2 + bh + 0.3, 1.8); vline(x - 0.9, y2 + bh + 0.3, y3 - (y2 + bh + 0.3)); vline(x + 0.9, y2 + bh + 0.3, y3 - (y2 + bh + 0.3)); });
      box(cx - bw / 2, y1, '[Board / Head]', COL.deep, COL.white, 'Level 1');
      xs2.forEach((x, i) => box(x - bw / 2, y2, `[Function ${i + 1}]`, i === 1 ? COL.saffron : COL.water, i === 1 ? COL.deep : COL.white, `Level 2.${i + 1}`));
      xs2.forEach((x, i) => { box(x - 0.9 - 0.8, y3, `[Role ${2 * i + 1}]`, COL.mist, COL.deep, `Level 3.${2 * i + 1}`, 1.6); box(x + 0.9 - 0.8, y3, `[Role ${2 * i + 2}]`, COL.mist, COL.deep, `Level 3.${2 * i + 2}`, 1.6); });
    });
  add('diagram.swimlane', { ...DG, name: 'Journey, 3 swimlanes', subcategory: 'Process', description: 'Three lanes with owners and a chain of steps joined by arrows; the hand-off step in saffron.', tags: ['swimlane', 'journey', 'process', 'hand-off'] },
    'KSA_TITLE', (s) => {
      const lw = 1.7, lx = M.l, lh = (BODY_H - 0.2) / 3, gw = CW - lw;
      ['[Lane 1 owner]', '[Lane 2 owner]', '[Lane 3 owner]'].forEach((t, i) => {
        const y = BODY_Y + i * (lh + 0.1);
        R(s, lx, y, lw, lh, COL.deep, `Lane ${i + 1} label`);
        T(s, t, { x: lx + 0.2, y, w: lw - 0.4, h: lh, fontSize: 12, bold: true, color: COL.white, valign: 'middle' });
        R(s, lx + lw, y, gw, lh, COL.mist, `Lane ${i + 1}`);
      });
      const sw = 1.75, sh = 0.6;
      const steps = [[0, 0.3], [0, 2.5], [1, 4.4], [2, 6.3], [1, 8.0]];
      const spos = steps.map((st) => [lx + lw + st[1], BODY_Y + st[0] * (lh + 0.1) + lh / 2 - sh / 2]);
      spos.forEach((p, i) => {
        if (i < spos.length - 1) {
          const q = spos[i + 1];
          const x1 = p[0] + sw, y1 = p[1] + sh / 2, x2 = q[0], y2 = q[1] + sh / 2;
          s.addShape('line', { x: x1, y: Math.min(y1, y2), w: x2 - x1, h: Math.abs(y2 - y1) || 0.001, flipV: y2 < y1, line: { color: COL.water, width: 1.5, endArrowType: 'triangle' }, objectName: 'Flow' });
        }
      });
      spos.forEach((p, i) => {
        const hand = i === 3;
        s.addShape('roundRect', { x: p[0], y: p[1], w: sw, h: sh, rectRadius: 0.05, fill: { color: hand ? COL.saffron : COL.white }, line: { color: hand ? COL.saffron : COL.water, width: 1.25 }, objectName: `Step ${i + 1}` });
        T(s, `[Step ${i + 1}]`, { x: p[0], y: p[1], w: sw, h: sh, fontSize: 12, bold: true, color: COL.deep, align: 'center', valign: 'middle' });
      });
    });
  add('diagram.decision-tree', { ...DG, name: 'Decision tree', subcategory: 'Framework', description: 'A root question branching twice into four outcomes, with yes and no labels on the branches.', tags: ['decision', 'tree', 'branch', 'logic'] },
    'KSA_TITLE', (s) => {
      const x0 = M.l, bw = 2.2, bh = 0.7, cy = BODY_Y + BODY_H / 2;
      const node = (x, y, text, fill, color, name, w = bw) => { s.addShape('roundRect', { x, y: y - bh / 2, w, h: bh, rectRadius: 0.05, fill: { color: fill }, line: { color: fill, width: 0 }, objectName: name }); T(s, text, { x, y: y - bh / 2, w, h: bh, fontSize: 12, bold: true, color, align: 'center', valign: 'middle' }); };
      const link = (x1, y1, x2, y2, tag) => {
        s.addShape('line', { x: x1, y: Math.min(y1, y2), w: x2 - x1, h: Math.abs(y2 - y1) || 0.001, flipV: y2 < y1, line: { color: COL.river, width: 1 }, objectName: 'Branch' });
        T(s, tag, { x: (x1 + x2) / 2 - 0.3, y: (y1 + y2) / 2 - 0.15, w: 0.6, h: 0.3, fontSize: 9, bold: true, charSpacing: 1, color: tag === 'YES' ? COL.water : COL.clay, align: 'center', valign: 'middle', fill: { color: COL.white } });
      };
      const x1 = x0 + bw + 0.9, x2 = x1 + bw + 0.9, x3 = x2 + bw + 0.9;
      const ys2 = [cy - 1.3, cy + 1.3], ys3 = [cy - 1.85, cy - 0.65, cy + 0.65, cy + 1.85];
      link(x0 + bw, cy, x1, ys2[0], 'YES'); link(x0 + bw, cy, x1, ys2[1], 'NO');
      link(x1 + bw, ys2[0], x2, ys3[0], 'YES'); link(x1 + bw, ys2[0], x2, ys3[1], 'NO');
      link(x1 + bw, ys2[1], x2, ys3[2], 'YES'); link(x1 + bw, ys2[1], x2, ys3[3], 'NO');
      node(x0, cy, '[Root question?]', COL.deep, COL.white, 'Root');
      node(x1, ys2[0], '[Question A?]', COL.water, COL.white, 'Branch A');
      node(x1, ys2[1], '[Question B?]', COL.water, COL.white, 'Branch B');
      ['[Outcome 1]', '[Outcome 2]', '[Outcome 3]', '[Outcome 4]'].forEach((t, i) => node(x2, ys3[i], t, i === 0 ? COL.saffron : COL.mist, COL.deep, `Outcome ${i + 1}`, W - M.r - x2));
    });

  // ====================================================================== INFOGRAPHICS (grouped)
  const IG = { category: 'infographics', group: true };
  add('info.big-number-trio', { ...IG, name: 'Big-number trio', subcategory: 'Numbers', description: 'Three hero figures with split rules and one-line descriptions; the first in saffron.', tags: ['numbers', 'stats', 'trio'] },
    'KSA_TITLE', (s) => {
      const gap = 0.6, cw = (CW - 2 * gap) / 3;
      ['[86%]', '[₹1,240 cr]', '[3.2x]'].forEach((v, i) => {
        const x = M.l + i * (cw + gap);
        K.addSplitRule(s, x, BODY_Y + 0.3, cw, { color: COL.deep, accent: i === 0 ? COL.saffron : COL.water });
        T(s, v, { x, y: BODY_Y + 0.5, w: cw, h: 1.2, fontSize: 48, bold: true, color: i === 0 ? COL.saffron : COL.deep });
        T(s, `[What figure ${i + 1} measures, with the period]`, { x, y: BODY_Y + 1.8, w: cw, h: 0.8, fontSize: 14, color: COL.slate, valign: 'top', lineSpacingMultiple: 1.2 });
      });
    });
  add('info.kpi-cards', { ...IG, name: 'KPI cards with delta pills', subcategory: 'Numbers', description: 'Four metric cards: context tag, value, delta pill and comparison, on a Fog keyline.', tags: ['kpi', 'metric', 'cards', 'delta'] },
    'KSA_TITLE', (s) => {
      const gap = 0.3, cw = (CW - 3 * gap) / 4, ch = 2.2;
      const cards = [['[REVENUE · Q2]', '[₹1,284 cr]', '▲ 12.4% YoY', 'EAF1EA', COL.kelp, 'vs [₹1,142 cr] in Q2 last year'], ['[GROSS NPA]', '[2.41%]', '▼ 18 bps', 'EAF1EA', COL.kelp, 'lower is better'], ['[OPEN ALERTS]', '[37]', '▲ 16 days', 'F7E7E3', COL.clay, 'above the 60-day covenant'], ['[CASE CLOSURE]', '[92%]', '– 0.0%', 'EEF1F3', COL.slate, 'within 30 days, no change']];
      cards.forEach((c, i) => {
        const x = M.l + i * (cw + gap), y = BODY_Y + 0.2;
        s.addShape('roundRect', { x, y, w: cw, h: ch, rectRadius: 0.08, fill: { color: COL.white }, line: { color: COL.fog, width: 1 }, objectName: 'Metric card' });
        T(s, c[0], { x: x + 0.3, y: y + 0.3, w: cw - 0.6, h: 0.3, fontSize: 9, bold: true, charSpacing: 2, color: COL.slate });
        T(s, c[1], { x: x + 0.3, y: y + 0.6, w: cw - 0.6, h: 0.7, fontSize: 24, bold: true, color: COL.deep });
        s.addShape('roundRect', { x: x + 0.3, y: y + 1.35, w: 1.3, h: 0.3, rectRadius: 0.15, fill: { color: c[3] }, line: { color: c[3], width: 0 }, objectName: 'Delta pill' });
        T(s, c[2], { x: x + 0.3, y: y + 1.35, w: 1.3, h: 0.3, fontSize: 9.5, bold: true, color: c[4], align: 'center', valign: 'middle' });
        T(s, c[5], { x: x + 0.3, y: y + 1.72, w: cw - 0.6, h: 0.35, fontSize: 10, color: COL.slate });
      });
    });
  add('info.stat-gauge', { ...IG, name: 'Stat with donut gauge', subcategory: 'Numbers', description: 'A native doughnut gauge (value against the remainder in Fog) beside the figure, target and explanation.', tags: ['gauge', 'donut', 'progress', 'kpi'] },
    'KSA_TITLE', (s) => {
      const gd = 3.6;
      s.addChart(pres.charts.DOUGHNUT, [{ name: '[Measure]', labels: ['Achieved', 'Remaining'], values: [72, 28] }], K.chartBase({ x: M.l + 0.4, y: BODY_Y + 0.2, w: gd, h: gd, holeSize: 82, chartColors: [COL.water, COL.fog], showLegend: false, showLabel: false, showValue: false, showPercent: false, dataBorder: { pt: 0, color: COL.white } }));
      T(s, '[72%]', { x: M.l + 0.4, y: BODY_Y + 0.2 + gd / 2 - 0.45, w: gd, h: 0.6, fontSize: 30, bold: true, color: COL.deep, align: 'center' });
      T(s, 'of [target]', { x: M.l + 0.4, y: BODY_Y + 0.2 + gd / 2 + 0.15, w: gd, h: 0.3, fontSize: 11, color: COL.slate, align: 'center' });
      const tx = M.l + 5.2;
      T(s, '[MEASURE · PERIOD]', { x: tx, y: BODY_Y + 0.5, w: 6, h: 0.3, fontSize: 10, bold: true, charSpacing: 2, color: COL.slate });
      T(s, '[₹86.4 cr]', { x: tx, y: BODY_Y + 0.85, w: 6, h: 1.0, fontSize: 48, bold: true, color: COL.deep });
      T(s, 'of [₹120 cr] target · pace [58%]', { x: tx, y: BODY_Y + 1.95, w: 6, h: 0.4, fontSize: 14, color: COL.slate });
      s.addShape('line', { x: tx, y: BODY_Y + 2.55, w: 6, h: 0, line: { color: COL.fog, width: 0.75 }, objectName: 'Hairline' });
      T(s, '[One sentence on whether this is good, and what happens next.]', { x: tx, y: BODY_Y + 2.7, w: 6, h: 0.9, fontSize: 13, color: COL.deep, valign: 'top', lineSpacingMultiple: 1.2 });
    });
  add('info.before-after', { ...IG, name: 'Comparison, before and after', subcategory: 'Comparison', description: 'Two panels, Sea Mist before and Deep Current after, joined by a saffron arrow with the change stated.', tags: ['before', 'after', 'comparison', 'change'] },
    'KSA_TITLE', (s) => {
      const aw = 1.2, pw = (CW - aw - 0.6) / 2, ph = BODY_H - 0.2;
      [['BEFORE', COL.mist, COL.deep, COL.slate, M.l], ['AFTER', COL.deep, COL.white, COL.spray, M.l + pw + aw + 0.6]].forEach((p, i) => {
        R(s, p[4], BODY_Y, pw, ph, p[1], p[0] + ' panel');
        T(s, p[0], { x: p[4] + 0.4, y: BODY_Y + 0.3, w: 3, h: 0.3, fontSize: 10, bold: true, charSpacing: 2, color: i === 0 ? COL.water : COL.shallows });
        T(s, i === 0 ? '[4.2 days]' : '[0.8 days]', { x: p[4] + 0.4, y: BODY_Y + 0.7, w: pw - 0.8, h: 1.0, fontSize: 44, bold: true, color: p[2] });
        T(s, '[What the figure measures]', { x: p[4] + 0.4, y: BODY_Y + 1.75, w: pw - 0.8, h: 0.4, fontSize: 13, bold: true, color: p[2] });
        T(s, [
          { text: '[How the process worked]', options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 6 } },
          { text: '[What it cost in time and money]', options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 6 } },
          { text: '[What it meant for the customer]', options: { bullet: { indent: 12 } } },
        ], { x: p[4] + 0.4, y: BODY_Y + 2.25, w: pw - 0.8, h: ph - 2.5, fontSize: 12.5, color: p[3], valign: 'top' });
      });
      const ax = M.l + pw + 0.3;
      s.addShape('rightArrow', { x: ax, y: BODY_Y + ph / 2 - 0.4, w: aw, h: 0.8, fill: { color: COL.saffron }, line: { color: COL.saffron, width: 0 }, objectName: 'Change arrow' });
      T(s, '[-81%]', { x: ax, y: BODY_Y + ph / 2 + 0.5, w: aw, h: 0.4, fontSize: 14, bold: true, color: COL.deep, align: 'center' });
    });
  add('info.icon-stat-rows', { ...IG, name: 'Icon and stat rows', subcategory: 'Numbers', description: 'Four rows of icon, figure and description separated by Fog hairlines.', tags: ['icons', 'stats', 'rows', 'list'] },
    'KSA_TITLE', (s) => {
      const rh = BODY_H / 4;
      [['analytics', '[48]', '[dashboards delivered across six clusters]'], ['user', '[12]', '[senior advisers, every one of them hands-on]'], ['globe', '[9]', '[countries covered by the International Desk]'], ['timeline', '[4 weeks]', '[from first conversation to first read-out]']].forEach((r, i) => {
        const y = BODY_Y + i * rh;
        s.addShape('line', { x: M.l, y, w: CW, h: 0, line: { color: i === 0 ? COL.deep : COL.fog, width: i === 0 ? 1.5 : 0.75 }, objectName: 'Rule' });
        s.addImage({ path: K.iconPng(r[0]), x: M.l + 0.1, y: y + rh / 2 - 0.3, w: 0.6, h: 0.6 });
        T(s, r[1], { x: M.l + 1.2, y: y + 0.15, w: 3.2, h: rh - 0.3, fontSize: 32, bold: true, color: i === 3 ? COL.saffron : COL.deep, valign: 'middle' });
        T(s, r[2], { x: M.l + 4.6, y: y + 0.15, w: CW - 4.6, h: rh - 0.3, fontSize: 15, color: COL.slate, valign: 'middle' });
      });
      s.addShape('line', { x: M.l, y: BODY_Y + 4 * rh, w: CW, h: 0, line: { color: COL.fog, width: 0.75 }, objectName: 'Rule' });
    });
  add('info.scorecard-rag', { ...IG, name: 'RAG scorecard', subcategory: 'Tables', description: 'KPI table with actual, target and a status column where shape carries the state: circle on track, triangle at risk, diamond off track.', tags: ['scorecard', 'rag', 'status', 'table', 'kpi'] },
    'KSA_TITLE', (s) => {
      const rows = [['[Vendor DD coverage]', '86%', '95%', 1], ['[Whistle-blower response]', '92%', '85%', 0], ['[KYC backlog, accounts]', '14,820', '5,000', 2], ['[Policy attestation]', '98%', '98%', 0], ['[Incident containment, h]', '6.2', '4.0', 1], ['[Audit points closed]', '71%', '90%', 2]];
      const colW = [4.4, 1.7, 1.7, 0.5, 3.256], rowH = 0.5, hy = BODY_Y;
      const states = [['On track', COL.kelp], ['At risk', COL.gold], ['Off track', COL.clay]];
      const hdr = ['KPI', 'ACTUAL', 'TARGET', '', 'STATUS'].map((t, i) => ({ text: t, options: { bold: true, fontSize: 9.5, color: COL.slate, charSpacing: 1.5, align: i === 0 || i === 4 ? 'left' : 'right', border: [{ type: 'none' }, { type: 'none' }, { pt: 1.5, color: COL.deep }, { type: 'none' }] } }));
      const body = rows.map((r) => [
        { text: r[0], options: { fontSize: 12, color: COL.deep } },
        { text: r[1], options: { fontSize: 12, bold: true, color: COL.deep, align: 'right' } },
        { text: r[2], options: { fontSize: 12, color: COL.slate, align: 'right' } },
        { text: '', options: { fontSize: 12 } },
        { text: states[r[3]][0], options: { fontSize: 12, bold: true, color: states[r[3]][1] } },
      ]);
      s.addTable([hdr, ...body], { x: M.l, y: hy, w: CW, colW, rowH, fontFace: 'Archivo', margin: [0.06, 0.08, 0.06, 0.08], valign: 'middle', border: { type: 'solid', pt: 0.75, color: COL.fog }, fill: { color: COL.white }, objectName: 'Scorecard table' });
      rows.forEach((r, i) => {
        const y = hy + rowH * (i + 1) + rowH / 2, x = M.l + colW[0] + colW[1] + colW[2] + 0.14;
        const shp = ['ellipse', 'triangle', 'diamond'][r[3]];
        s.addShape(shp, { x, y: y - 0.11, w: 0.22, h: 0.22, fill: { color: states[r[3]][1] }, line: { color: states[r[3]][1], width: 0 }, objectName: 'Status mark' });
      });
      T(s, 'Shape carries status; colour confirms it.  ● On track   ▲ At risk   ◆ Off track', { x: M.l, y: hy + rowH * 7 + 0.2, w: CW, h: 0.3, fontSize: 10, color: COL.slate });
    });
  add('info.stepped-numbers', { ...IG, name: 'Stepped numbers 01 to 04', subcategory: 'Process', description: 'Four columns with large ordinals, titles and text, the last ordinal in saffron.', tags: ['steps', 'numbers', 'ordinals'] },
    'KSA_TITLE', (s) => {
      const gap = 0.45, cw = (CW - 3 * gap) / 4;
      for (let i = 0; i < 4; i++) {
        const x = M.l + i * (cw + gap), last = i === 3;
        T(s, `0${i + 1}`, { x, y: BODY_Y, w: cw, h: 1.0, fontSize: 48, bold: true, color: last ? COL.saffron : COL.water });
        s.addShape('line', { x, y: BODY_Y + 1.1, w: cw, h: 0, line: { color: COL.deep, width: 1.5 }, objectName: 'Rule' });
        T(s, `[Step ${i + 1} title]`, { x, y: BODY_Y + 1.25, w: cw, h: 0.45, fontSize: 16, bold: true, color: COL.deep });
        T(s, '[What happens, who is involved and what it produces.]', { x, y: BODY_Y + 1.75, w: cw, h: 1.8, fontSize: 13, color: COL.slate, valign: 'top', lineSpacingMultiple: 1.2 });
      }
    });
  add('info.percentage-bars', { ...IG, name: 'Percentage bars', subcategory: 'Comparison', description: 'Five labelled bars on a Fog track with values at the end; the lead bar in saffron.', tags: ['bars', 'percentage', 'progress'] },
    'KSA_TITLE', (s) => {
      const rows = [['[Category A]', 78], ['[Category B]', 64], ['[Category C]', 51], ['[Category D]', 37], ['[Category E]', 22]];
      const lw = 3.0, bw = CW - lw - 1.0, rh = 0.75;
      rows.forEach((r, i) => {
        const y = BODY_Y + 0.2 + i * rh;
        T(s, r[0], { x: M.l, y, w: lw - 0.2, h: 0.4, fontSize: 13, bold: true, color: COL.deep, valign: 'middle' });
        R(s, M.l + lw, y + 0.08, bw, 0.24, COL.fog, 'Track');
        R(s, M.l + lw, y + 0.08, bw * r[1] / 100, 0.24, i === 0 ? COL.saffron : COL.water, 'Bar');
        T(s, `${r[1]}%`, { x: M.l + lw + bw + 0.15, y, w: 0.85, h: 0.4, fontSize: 13, bold: true, color: COL.deep, valign: 'middle' });
      });
    });
  add('info.india-regions', { ...IG, name: 'India regions, hex tiles', subcategory: 'Maps', description: 'Six hexagon tiles for North, West, Central, East, South and North-East with a figure each; no map needed.', tags: ['india', 'regions', 'hexagon', 'tiles'] },
    'KSA_TITLE', (s) => {
      const hw = 1.5, hh = 1.3, ox = M.l + 0.3, oy = BODY_Y;
      // flat-top honeycomb: columns 0.75 w apart, odd columns dropped by half a tile
      const tiles = [['West', 0, 1, COL.tide], ['North', 1, 0, COL.water], ['Central', 1, 1, COL.slate], ['South', 1, 2, COL.lagoon], ['East', 2, 1, COL.kelp], ['North-East', 3, 0, COL.saffron]];
      tiles.forEach((t) => {
        const x = ox + t[1] * hw * 0.76, y = oy + t[2] * hh + (t[1] % 2 ? hh / 2 : 0);
        s.addShape('hexagon', { x, y, w: hw, h: hh, fill: { color: t[3] }, line: { color: COL.white, width: 2 }, objectName: `${t[0]} tile` });
        T(s, t[0].toUpperCase(), { x: x + 0.2, y: y + 0.25, w: hw - 0.4, h: 0.25, fontSize: 7.5, bold: true, charSpacing: 1.5, color: t[3] === COL.saffron ? COL.deep : COL.spray, align: 'center' });
        T(s, '[24%]', { x: x + 0.2, y: y + 0.48, w: hw - 0.4, h: 0.4, fontSize: 16, bold: true, color: t[3] === COL.saffron ? COL.deep : COL.white, align: 'center' });
        T(s, '[of total]', { x: x + 0.2, y: y + 0.86, w: hw - 0.4, h: 0.25, fontSize: 8, color: t[3] === COL.saffron ? COL.deep : COL.spray, align: 'center' });
      });
      const lx = M.l + 6.2;
      T(s, '[What the regional split shows]', { x: lx, y: BODY_Y + 0.2, w: W - M.r - lx, h: 0.8, fontSize: 16, bold: true, color: COL.deep, valign: 'top' });
      T(s, '[Two or three sentences on the regional pattern and what it means for the plan. Use one saffron tile for the region the title is about.]', { x: lx, y: BODY_Y + 1.1, w: W - M.r - lx, h: 2.5, fontSize: 13, color: COL.slate, valign: 'top', lineSpacingMultiple: 1.2 });
    });
  add('info.risk-heatmap', { ...IG, name: 'Risk heat map, 5 x 5', subcategory: 'Risk', description: 'Likelihood by impact grid on the risk ramp (Kelp to Red Clay) with numbered risk markers and a key.', tags: ['risk', 'heat map', 'matrix', 'likelihood', 'impact'] },
    'KSA_TITLE', (s) => {
      const ramp = ['4B7A4E', '9AAD5A', 'F5C46D', 'EE9B1E', 'B4472F'];
      const gx = M.l + 0.9, gy = BODY_Y + 0.1, cell = 0.72, gap = 0.04;
      for (let r = 0; r < 5; r++) for (let c = 0; c < 5; c++) {
        const score = (5 - r) * (c + 1), lvl = score >= 16 ? 4 : score >= 10 ? 3 : score >= 6 ? 2 : score >= 3 ? 1 : 0;
        R(s, gx + c * (cell + gap), gy + r * (cell + gap), cell, cell, ramp[lvl], `Cell L${5 - r} I${c + 1}`);
      }
      for (let i = 0; i < 5; i++) {
        T(s, String(5 - i), { x: gx - 0.4, y: gy + i * (cell + gap), w: 0.3, h: cell, fontSize: 10, bold: true, color: COL.slate, align: 'right', valign: 'middle' });
        T(s, String(i + 1), { x: gx + i * (cell + gap), y: gy + 5 * (cell + gap), w: cell, h: 0.3, fontSize: 10, bold: true, color: COL.slate, align: 'center' });
      }
      T(s, 'LIKELIHOOD', { x: gx - 0.95 - 1.5, y: gy + 2.5 * (cell + gap) - 0.15, w: 3.8, h: 0.3, fontSize: 9.5, bold: true, charSpacing: 2, color: COL.slate, align: 'center', rotate: 270 });
      T(s, 'IMPACT', { x: gx, y: gy + 5 * (cell + gap) + 0.3, w: 5 * (cell + gap), h: 0.3, fontSize: 9.5, bold: true, charSpacing: 2, color: COL.slate, align: 'center' });
      const marks = [[4, 3, '1'], [2, 4, '2'], [3, 1, '3'], [1, 2, '4']];
      marks.forEach((m) => {
        const x = gx + m[1] * (cell + gap) + cell / 2 - 0.19, y = gy + (5 - m[0]) * (cell + gap) + cell / 2 - 0.19;
        s.addShape('ellipse', { x, y, w: 0.38, h: 0.38, fill: { color: COL.deep }, line: { color: COL.white, width: 1.5 }, objectName: 'Risk marker' });
        T(s, m[2], { x, y, w: 0.38, h: 0.38, fontSize: 10, bold: true, color: COL.white, align: 'center', valign: 'middle' });
      });
      const lx = gx + 5 * (cell + gap) + 1.0;
      T(s, 'RISK REGISTER', { x: lx, y: gy, w: 4, h: 0.3, fontSize: 10, bold: true, charSpacing: 2, color: COL.slate });
      ['[Risk one]', '[Risk two]', '[Risk three]', '[Risk four]'].forEach((t, i) => {
        const y = gy + 0.45 + i * 0.75;
        s.addShape('line', { x: lx, y, w: W - M.r - lx, h: 0, line: { color: COL.fog, width: 0.75 }, objectName: 'Hairline' });
        T(s, `${i + 1}`, { x: lx, y: y + 0.1, w: 0.4, h: 0.4, fontSize: 14, bold: true, color: COL.water });
        T(s, t, { x: lx + 0.4, y: y + 0.1, w: 3.2, h: 0.3, fontSize: 13, bold: true, color: COL.deep });
        T(s, '[Owner · mitigation]', { x: lx + 0.4, y: y + 0.38, w: 3.2, h: 0.3, fontSize: 10.5, color: COL.slate });
      });
    });

  // ====================================================================== SHAPES (grouped)
  const SH = { category: 'shapes', group: true };
  const caption = (s, text) => T(s, text, { x: M.l, y: 5.75, w: CW, h: 0.5, fontSize: 12, color: COL.slate, align: 'center' });
  add('shape.blade-left', { ...SH, name: 'Blade, left', subcategory: 'Identifier', description: 'The left blade of the identifier as an editable vector shape in Open Water.', tags: ['blade', 'identifier', 'vector'] },
    'KSA_TITLE', (s) => { K.addBlade(s, CX - 1.0, BODY_Y + 0.3, 2.0, 2.9, { dir: 'left', color: COL.water, name: 'Blade left' }); caption(s, 'Blade, left. Cut on the 62 degree angle; recolour with the theme accents.'); });
  add('shape.blade-right', { ...SH, name: 'Blade, right', subcategory: 'Identifier', description: 'The right blade of the identifier as an editable vector shape in Beacon Saffron.', tags: ['blade', 'identifier', 'vector'] },
    'KSA_TITLE', (s) => { K.addBlade(s, CX - 1.0, BODY_Y + 0.3, 2.0, 2.9, { dir: 'right', color: COL.saffron, name: 'Blade right' }); caption(s, 'Blade, right. The saffron blade: use once per slide.'); });
  add('shape.blade-pair', { ...SH, name: 'Blade pair', subcategory: 'Identifier', description: 'Both blades of the identifier without the stem: two strokes that meet at the split.', tags: ['blades', 'identifier', 'pair'] },
    'KSA_TITLE', (s) => { K.addBlade(s, CX - 2.05, BODY_Y + 0.3, 1.95, 2.9, { dir: 'left', color: COL.water, name: 'Blade left' }); K.addBlade(s, CX + 0.1, BODY_Y + 0.3, 1.95, 2.9, { dir: 'right', color: COL.saffron, name: 'Blade right' }); caption(s, 'Blade pair. The identifier without its stem; keep the split between the strokes.'); });
  add('shape.chevron-wake', { ...SH, name: 'Chevron wake pair', subcategory: 'Marks', description: 'Two converging V strokes that never touch, drawn as open paths in Open Water.', tags: ['chevron', 'wake', 'mark'] },
    'KSA_TITLE', (s) => {
      const w = 1.6, h = 1.0, y = BODY_Y + 1.2;
      [CX - 2.0, CX + 0.4].forEach((x, i) => {
        s.addShape('custGeom', { x, y, w, h, points: [{ x: 0, y: 0 }, { x: w * 0.47, y: h }], fill: { color: COL.white, transparency: 100 }, line: { color: i === 1 ? COL.saffron : COL.water, width: 4 }, objectName: `Wake stroke ${i * 2 + 1}` });
        s.addShape('custGeom', { x, y, w, h, points: [{ x: w, y: 0 }, { x: w * 0.53, y: h }], fill: { color: COL.white, transparency: 100 }, line: { color: i === 1 ? COL.saffron : COL.water, width: 4 }, objectName: `Wake stroke ${i * 2 + 2}` });
      });
      caption(s, 'Chevron wake pair. Two strokes converge but never touch: the split at the heart of the identifier.');
    });
  add('shape.delta', { ...SH, name: 'Delta trapezoid', subcategory: 'Identifier', description: 'The trapezoid cut from the A of the monogram, in Deep Current.', tags: ['delta', 'trapezoid', 'monogram'] },
    'KSA_TITLE', (s) => {
      const w = 3.0, h = 2.6, x = CX - w / 2, y = BODY_Y + 0.4;
      s.addShape('custGeom', { x, y, w, h, points: [{ x: w * 0.36, y: 0 }, { x: w * 0.64, y: 0 }, { x: w, y: h }, { x: 0, y: h }, { close: true }], fill: { color: COL.deep }, line: { color: COL.deep, width: 0 }, objectName: 'Delta' });
      caption(s, 'Delta trapezoid. Upright or inverted; it interlocks like a river delta in Pattern 03.');
    });
  add('shape.split-rule', { ...SH, name: 'Split rule', subcategory: 'Rules', description: 'A 2 px rule in Deep Current with a one-third Open Water tail after a 4% gap; sits under headlines and hero figures.', tags: ['rule', 'split', 'divider'] },
    'KSA_TITLE', (s) => { K.addSplitRule(s, M.l + 1.5, BODY_Y + 1.6, CW - 3, { weight: 2 }); caption(s, 'Split rule. Deep Current plus Open Water, gap 4% of the length.'); });
  add('shape.blade-rule', { ...SH, name: 'Blade rule', subcategory: 'Rules', description: 'Two blades, 26 x 6 and 13 x 6, cut at 62 degrees on a Fog hairline; opens a chapter or section.', tags: ['rule', 'blade', 'opener'] },
    'KSA_TITLE', (s) => { K.addHairline(s, M.l + 1.5, BODY_Y + 1.63, CW - 3); K.addBladeRule(s, M.l + 1.5, BODY_Y + 1.42, { scale: 3 }); caption(s, 'Blade rule. Blades sit on a Fog hairline; the saffron blade is the only accent.'); });
  add('shape.confluence-divider', { ...SH, name: 'Confluence divider', subcategory: 'Rules', description: 'Two 1.5 px arms that fall at 62 degrees to a split at the centre; closes a section.', tags: ['divider', 'confluence', 'closer'] },
    'KSA_TITLE', (s) => {
      const w = CW - 3, x = M.l + 1.5, y = BODY_Y + 1.5, arm = w * 0.46, drop = 0.32;
      s.addShape('custGeom', { x, y, w: arm + 0.2, h: drop, points: [{ x: 0, y: 0 }, { x: arm, y: 0 }, { x: arm + 0.2, y: drop }], fill: { color: COL.white, transparency: 100 }, line: { color: COL.deep, width: 1.5 }, objectName: 'Confluence arm left' });
      s.addShape('custGeom', { x: x + w - arm - 0.2, y, w: arm + 0.2, h: drop, points: [{ x: arm + 0.2, y: 0 }, { x: 0.2, y: 0 }, { x: 0, y: drop }], fill: { color: COL.white, transparency: 100 }, line: { color: COL.deep, width: 1.5 }, objectName: 'Confluence arm right' });
      caption(s, 'Confluence divider. Arms fall at 62 degrees; 4% split at the centre; 24 px clear above and below.');
    });
  add('shape.content-label', { ...SH, name: 'Content-type label', subcategory: 'Badges', description: 'A cut-corner tag in Deep Current with reversed caps; also keyline and tint variants.', tags: ['label', 'tag', 'badge', 'content type'] },
    'KSA_TITLE', (s) => {
      K.addTag(s, CX - 3.9, BODY_Y + 1.3, 2.3, 0.46, 'INSIGHT', { fill: COL.deep, fontSize: 11, name: 'Label, solid' });
      K.addTag(s, CX - 1.15, BODY_Y + 1.3, 2.3, 0.46, 'POINT OF VIEW', { fill: COL.deep, keyline: true, fontSize: 11, name: 'Label, keyline' });
      K.addTag(s, CX + 1.6, BODY_Y + 1.3, 2.3, 0.46, 'CASE STUDY', { fill: COL.water, fontSize: 11, name: 'Label, Open Water' });
      caption(s, 'Content-type label. Top left of covers, cards and tiles. One per view; never rotate or outline.');
    });
  add('shape.cluster-badge', { ...SH, name: 'Cluster badge', subcategory: 'Badges', description: 'Square badge in the cluster colour with the reversed icon and the cluster name; recolour for each of the six clusters.', tags: ['badge', 'cluster', 'icon'] },
    'KSA_TITLE', (s) => {
      const cl = CLUSTERS[0], x = CX - 2.1, y = BODY_Y + 1.2;
      R(s, x, y, 0.9, 0.9, cl.color, 'Cluster badge tile');
      s.addImage({ path: K.iconPng(cl.icon, 'Line_White'), x: x + 0.18, y: y + 0.18, w: 0.54, h: 0.54 });
      T(s, '[Cluster name]', { x: x + 1.1, y: y + 0.08, w: 3.4, h: 0.4, fontSize: 18, bold: true, color: COL.deep });
      T(s, '[COLOUR NAME]', { x: x + 1.1, y: y + 0.5, w: 3.4, h: 0.3, fontSize: 10, bold: true, charSpacing: 2, color: cl.color });
      caption(s, 'Cluster badge. Icon reversed to white; no saffron inside. Colours: Open Water, Burnished Gold, Storm Slate, Tidewater Blue, Kelp Green, Dusk Plum.');
    });
  add('shape.status-stamp', { ...SH, name: 'Status stamp', subcategory: 'Badges', description: 'Dashed square stamp with an icon, status word and a line of detail; sits top right of the page.', tags: ['stamp', 'status', 'draft', 'confidential'] },
    'KSA_TITLE', (s) => {
      const w = 3.0, h = 0.8, x = CX - w - 0.3, y = BODY_Y + 1.1;
      s.addShape('rect', { x, y, w, h, fill: { color: COL.white }, line: { color: COL.deep, width: 1.5, dashType: 'dash' }, objectName: 'Stamp frame' });
      s.addImage({ path: K.iconPng('report'), x: x + 0.18, y: y + 0.2, w: 0.4, h: 0.4 });
      T(s, 'DRAFT', { x: x + 0.75, y: y + 0.15, w: w - 0.9, h: 0.3, fontSize: 12, bold: true, charSpacing: 3, color: COL.deep });
      T(s, 'V0.3 · INTERNAL', { x: x + 0.75, y: y + 0.45, w: w - 0.9, h: 0.25, fontSize: 8.5, bold: true, charSpacing: 2, color: COL.slate });
      const x2 = CX + 0.3;
      s.addShape('rect', { x: x2, y, w, h, fill: { color: COL.white }, line: { color: COL.clay, width: 1.5 }, objectName: 'Stamp frame, confidential' });
      s.addImage({ path: K.iconPng('compliance'), x: x2 + 0.18, y: y + 0.2, w: 0.4, h: 0.4 });
      T(s, 'CONFIDENTIAL', { x: x2 + 0.75, y: y + 0.15, w: w - 0.9, h: 0.3, fontSize: 11, bold: true, charSpacing: 2, color: COL.clay });
      T(s, 'CLIENT ONLY', { x: x2 + 0.75, y: y + 0.45, w: w - 0.9, h: 0.25, fontSize: 8.5, bold: true, charSpacing: 2, color: COL.clay });
      caption(s, 'Status stamps. Square, never rotated, never distressed. Dashed for draft, Red Clay for confidential, Kelp for client ready.');
    });
  add('shape.numbered-marker', { ...SH, name: 'Numbered marker', subcategory: 'Badges', description: 'Chapter tile in Deep Current with a reversed number and a saffron underline variant for sections.', tags: ['number', 'marker', 'chapter', 'section'] },
    'KSA_TITLE', (s) => {
      const x = CX - 2.6, y = BODY_Y + 0.9;
      R(s, x, y, 1.2, 1.2, COL.deep, 'Chapter tile');
      T(s, '03', { x, y, w: 1.2, h: 1.2, fontSize: 36, bold: true, color: COL.white, align: 'center', valign: 'middle' });
      T(s, 'CHAPTER · REVERSED', { x: x - 0.4, y: y + 1.35, w: 2.0, h: 0.3, fontSize: 8.5, bold: true, charSpacing: 2, color: COL.slate, align: 'center' });
      const x2 = CX + 1.0;
      T(s, '03', { x: x2, y, w: 1.4, h: 0.9, fontSize: 36, bold: true, color: COL.water });
      R(s, x2 + 0.02, y + 0.95, 0.5, px(6), COL.saffron, 'Underline');
      T(s, 'SECTION · ON LIGHT', { x: x2 - 0.3, y: y + 1.35, w: 2.0, h: 0.3, fontSize: 8.5, bold: true, charSpacing: 2, color: COL.slate, align: 'center' });
      caption(s, 'Numbered markers. Archivo Bold figures; the saffron underline marks the current section.');
    });
  add('shape.waypoint-route', { ...SH, name: 'Waypoint and route line', subcategory: 'Marks', description: 'A dashed route line with three waypoint diamonds, the arrival in saffron: milestone, event or decision.', tags: ['waypoint', 'route', 'milestone', 'navigator'] },
    'KSA_TITLE', (s) => {
      const x = M.l + 1.5, w = CW - 3, y = BODY_Y + 1.6;
      s.addShape('line', { x, y, w, h: 0, line: { color: COL.water, width: 1.5, dashType: 'dash' }, objectName: 'Route line' });
      [0, 0.5, 1].forEach((t, i) => {
        const cx = x + t * w, last = i === 2;
        s.addShape('diamond', { x: cx - 0.2, y: y - 0.2, w: 0.4, h: 0.4, fill: { color: last ? COL.saffron : COL.white }, line: { color: last ? COL.saffron : COL.deep, width: 1.5 }, objectName: last ? 'Arrival' : `Waypoint ${i + 1}` });
        T(s, last ? 'ARRIVE' : `WP 0${i + 1}`, { x: cx - 0.8, y: y + 0.35, w: 1.6, h: 0.3, fontSize: 9, bold: true, charSpacing: 2, color: COL.slate, align: 'center' });
      });
      caption(s, 'Waypoint and route line. 2 px diamond, 14 x 20; saffron marks the arrival. Every mark carries a label.');
    });
  add('shape.frame-corners', { ...SH, name: 'Frame corner marks', subcategory: 'Marks', description: 'Four registration corners, 12 px arms in Deep Current, that frame an exhibit, pull-out or photograph.', tags: ['frame', 'corners', 'registration', 'exhibit'] },
    'KSA_TITLE', (s) => {
      const x = M.l + 1.5, y = BODY_Y + 0.2, w = CW - 3, h = 3.1, a = 0.3;
      R(s, x + 0.25, y + 0.25, w - 0.5, h - 0.5, COL.mist, 'Exhibit area');
      T(s, 'EXHIBIT AREA', { x: x + 0.25, y: y + 0.25, w: w - 0.5, h: h - 0.5, fontSize: 11, bold: true, charSpacing: 3, color: COL.river, align: 'center', valign: 'middle' });
      const corner = (cx, cy, sx, sy, name) => s.addShape('custGeom', { x: cx, y: cy, w: a, h: a, points: sx === 1 ? (sy === 1 ? [{ x: 0, y: a }, { x: 0, y: 0 }, { x: a, y: 0 }] : [{ x: 0, y: 0 }, { x: 0, y: a }, { x: a, y: a }]) : (sy === 1 ? [{ x: a, y: a }, { x: a, y: 0 }, { x: 0, y: 0 }] : [{ x: a, y: 0 }, { x: a, y: a }, { x: 0, y: a }]), fill: { color: COL.white, transparency: 100 }, line: { color: COL.deep, width: 1.25 }, objectName: name });
      corner(x, y, 1, 1, 'Corner top left'); corner(x + w - a, y, -1, 1, 'Corner top right'); corner(x, y + h - a, 1, -1, 'Corner bottom left'); corner(x + w - a, y + h - a, -1, -1, 'Corner bottom right');
      caption(s, 'Registration marks. 12 px arms, 1 px Deep Current, 4 px outside the corner.');
    });

  // ====================================================================== EFFECTS
  const EF = { category: 'effects' };
  const demoCard = (s, x, y, w, h, shadow, name) => {
    s.addShape('roundRect', { x, y, w, h, rectRadius: 0.08, fill: { color: COL.white }, line: { color: COL.fog, width: 0.75 }, shadow, objectName: name });
    T(s, '[CONTEXT TAG]', { x: x + 0.3, y: y + 0.3, w: w - 0.6, h: 0.3, fontSize: 9, bold: true, charSpacing: 2, color: COL.slate });
    T(s, '[₹1,284 cr]', { x: x + 0.3, y: y + 0.6, w: w - 0.6, h: 0.7, fontSize: 28, bold: true, color: COL.deep });
    T(s, '[One line of context for the figure]', { x: x + 0.3, y: y + 1.35, w: w - 0.6, h: 0.5, fontSize: 11, color: COL.slate });
  };
  add('effect.card-e1', { ...EF, name: 'Card shadow e1', subcategory: 'Shadows', description: 'Elevation 1: Fog keyline with a 4 px blur, 2 px offset shadow at 12% in Deep Current.', tags: ['shadow', 'card', 'elevation'] },
    'KSA_TITLE_MIST', (s) => { demoCard(s, CX - 2.2, BODY_Y + 0.8, 4.4, 2.1, { type: 'outer', blur: 4, offset: 2, angle: 90, color: COL.deep, opacity: 0.12 }, 'Card e1'); caption(s, 'e1: resting cards and tiles. Blur 4, offset 2, Deep Current at 12%.'); });
  add('effect.card-e2', { ...EF, name: 'Card shadow e2', subcategory: 'Shadows', description: 'Elevation 2: 12 px blur, 4 px offset shadow at 14% for raised cards and popovers.', tags: ['shadow', 'card', 'elevation'] },
    'KSA_TITLE_MIST', (s) => { demoCard(s, CX - 2.2, BODY_Y + 0.8, 4.4, 2.1, { type: 'outer', blur: 12, offset: 4, angle: 90, color: COL.deep, opacity: 0.14 }, 'Card e2'); caption(s, 'e2: raised cards, popovers and tooltips. Blur 12, offset 4, Deep Current at 14%.'); });
  add('effect.card-e3', { ...EF, name: 'Card shadow e3', subcategory: 'Shadows', description: 'Elevation 3: 24 px blur, 8 px offset shadow at 16% for dialogs and hero cards.', tags: ['shadow', 'card', 'elevation'] },
    'KSA_TITLE_MIST', (s) => { demoCard(s, CX - 2.2, BODY_Y + 0.8, 4.4, 2.1, { type: 'outer', blur: 24, offset: 8, angle: 90, color: COL.deep, opacity: 0.16 }, 'Card e3'); caption(s, 'e3: dialogs and hero cards. Blur 24, offset 8, Deep Current at 16%.'); });
  add('effect.blade-crop', { ...EF, name: 'Blade crop mask', subcategory: 'Images', description: 'A picture with its top-right corner cut on the blade angle by an overlay in the background colour; replace the picture and keep the overlay.', tags: ['crop', 'mask', 'blade', 'image'] },
    'KSA_TITLE', (s) => {
      const x = M.l + 1.2, y = BODY_Y + 0.2, w = 5.4, h = 3.3;
      s.addImage({ path: K.patternPng('11', 'brand-light'), x, y, w, h, sizing: { type: 'cover', w, h }, objectName: 'Picture' });
      s.addShape('custGeom', { x: x + w - 1.6, y, w: 1.6, h: 1.1, points: [{ x: 0, y: 0 }, { x: 1.6, y: 0 }, { x: 1.6, y: 1.1 }, { close: true }], fill: { color: COL.white }, line: { color: COL.white, width: 0 }, objectName: 'Blade crop overlay' });
      T(s, '[Photo]', { x, y, w, h, fontSize: 12, bold: true, charSpacing: 3, color: COL.deep, align: 'center', valign: 'middle' });
      T(s, 'Blade crop. The overlay matches the slide background and cuts the corner at 62 degrees. Right-click the picture to change it; leave the overlay in place.', { x: x + w + 0.6, y: y + 0.4, w: CW - w - 1.8, h: 2.5, fontSize: 13, color: COL.slate, valign: 'top', lineSpacingMultiple: 1.25 });
    });
  add('effect.duotone', { ...EF, name: 'Duotone overlay', subcategory: 'Images', description: 'A picture under a Deep Current overlay at 35% transparency with reversed text on top.', tags: ['duotone', 'overlay', 'image', 'tint'] },
    'KSA_TITLE', (s) => {
      const x = M.l + 1.2, y = BODY_Y + 0.2, w = 5.4, h = 3.3;
      s.addImage({ path: K.patternPng('09', 'brand-light'), x, y, w, h, sizing: { type: 'cover', w, h }, objectName: 'Picture' });
      s.addShape('rect', { x, y, w, h, fill: { color: COL.deep, transparency: 35 }, line: { color: COL.deep, width: 0 }, objectName: 'Duotone overlay' });
      T(s, '[Headline over the picture]', { x: x + 0.4, y: y + h - 1.2, w: w - 0.8, h: 0.9, fontSize: 20, bold: true, color: COL.white, valign: 'bottom' });
      T(s, 'Duotone. Deep Current at 65% opacity over the picture keeps text legible and brings any photograph into the palette. Replace the picture; keep the overlay.', { x: x + w + 0.6, y: y + 0.4, w: CW - w - 1.8, h: 2.5, fontSize: 13, color: COL.slate, valign: 'top', lineSpacingMultiple: 1.25 });
    });
  add('effect.pattern-panel', { ...EF, name: 'Pattern overlay panel', subcategory: 'Backgrounds', description: 'A Sea Mist panel carrying the tonal-light Wake Lines pattern, for sidebars and call-outs.', tags: ['pattern', 'panel', 'background', 'sidebar'] },
    'KSA_TITLE', (s) => {
      const x = M.l, y = BODY_Y, w = 4.6, h = BODY_H;
      s.addImage({ path: K.patternPng('05', 'tonal-light'), x, y, w, h, sizing: { type: 'cover', w, h }, objectName: 'Pattern panel' });
      T(s, 'KEY TAKEAWAYS', { x: x + 0.4, y: y + 0.4, w: w - 0.8, h: 0.3, fontSize: 10, bold: true, charSpacing: 2, color: COL.water });
      T(s, [
        { text: '[First takeaway]', options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 8 } },
        { text: '[Second takeaway]', options: { bullet: { indent: 12 }, breakLine: true, paraSpaceAfter: 8 } },
        { text: '[Third takeaway]', options: { bullet: { indent: 12 } } },
      ], { x: x + 0.4, y: y + 0.85, w: w - 0.8, h: 2.5, fontSize: 14, color: COL.deep, valign: 'top' });
      T(s, 'Pattern overlay panel. Tonal-light patterns sit behind text at low contrast; use one pattern per deck for panels. The panel is a picture: resize it and the pattern crops rather than stretches.', { x: x + w + 0.6, y: y + 0.4, w: CW - w - 0.6, h: 2.5, fontSize: 13, color: COL.slate, valign: 'top', lineSpacingMultiple: 1.25 });
    });

  const out = await K.finish(pres, 'KSA_Slide_Library.pptx');
  fs.writeFileSync(path.join(__dirname, 'slide-library-index.json'), JSON.stringify(INDEX, null, 2));
  console.log('wrote', out, pres.slides.length, 'slides;', Object.keys(INDEX).length, 'ids');
}
main().catch((e) => { console.error(e); process.exit(1); });
