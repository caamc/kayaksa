// KSA_Service_Proposal.pptx: a 14-slide proposal skeleton with bracketed placeholders.
'use strict';
const K = require('./lib/ksa');
const { COL, CLUSTERS, SERIF, px, M, CW, W, H } = K;

async function main() {
  const pres = K.newPres({ title: 'Kayak Strategic Advisors · Service proposal', subject: 'Proposal template' });
  K.defineLayouts(pres, { footer: 'Kayak Strategic Advisors · Proposal for [Client name] · Confidential' });
  const BODY_Y = 2.15, BODY_B = 6.4, BODY_H = BODY_B - BODY_Y;
  const T = (s, text, o) => s.addText(text, { margin: 0, isTextBox: true, ...o });
  const R = (s, x, y, w, h, color, name = 'Rectangle') => s.addShape('rect', { x, y, w, h, fill: { color }, line: { color, width: 0 }, objectName: name });
  const head = (s, e, t) => { s.addText(e, { placeholder: 'eyebrow' }); s.addText(t, { placeholder: 'title' }); };
  const bullets = (items, o = {}) => items.map((t, i) => ({ text: t, options: { bullet: { indent: 14 }, breakLine: i < items.length - 1, paraSpaceAfter: o.gap || 8 } }));
  let s;

  // 1 cover
  pres.addSection({ title: 'Proposal' });
  s = pres.addSlide({ masterName: 'KSA_COVER', sectionTitle: 'Proposal' });
  s.addText('[Project name]', { placeholder: 'title' });
  s.addText('A proposal for [Client name]: [one line on the question we will answer]', { placeholder: 'subtitle' });
  s.addText('PROPOSAL · [DD MONTH YYYY] · CONFIDENTIAL', { placeholder: 'meta' });
  s.addNotes('Replace every bracketed placeholder. Keep the cover to the project name, the client and the date.');

  // 2 understanding of your needs
  s = pres.addSlide({ masterName: 'KSA_SPLIT', sectionTitle: 'Proposal' });
  head(s, 'OUR UNDERSTANDING OF YOUR NEEDS', '[The question you need answered, in one sentence]');
  s.addText('[Two or three sentences on the situation as we heard it: what has changed, what is at stake and when the decision has to be made.]', { placeholder: 'body' });
  {
    const x = M.l + 4.9, w = CW - 4.9, rowH = 1.15;
    [['What we heard', '[The context and the trigger for this work, in the client’s words]'], ['What matters most', '[The two or three things the answer has to get right]'], ['What success looks like', '[The decision, approval or result this work must enable]'], ['Where the risks lie', '[The constraints, sensitivities and dependencies we must respect]']].forEach((r, i) => {
      const y = M.t + 0.34 + i * rowH;
      s.addShape('line', { x, y, w, h: 0, line: { color: i === 0 ? COL.deep : COL.fog, width: i === 0 ? 1.5 : 0.75 }, objectName: 'Rule' });
      T(s, `0${i + 1}`, { x, y: y + px(18), w: 0.7, h: 0.4, fontSize: 18, bold: true, color: i === 3 ? COL.saffron : COL.water });
      T(s, r[0], { x: x + 0.7, y: y + px(18), w: w - 0.7, h: 0.35, fontSize: 16, bold: true, color: COL.deep });
      T(s, r[1], { x: x + 0.7, y: y + px(18) + 0.38, w: w - 0.7, h: 0.6, fontSize: 13, color: COL.slate, valign: 'top' });
    });
    s.addShape('line', { x, y: M.t + 0.34 + 4 * rowH, w, h: 0, line: { color: COL.fog, width: 0.75 }, objectName: 'Rule' });
  }
  s.addNotes('Play back the brief in the client’s own words. If the client reads nothing else, this slide should show we listened.');

  // 3 objectives
  s = pres.addSlide({ masterName: 'KSA_TITLE_MIST', sectionTitle: 'Proposal' });
  head(s, 'OBJECTIVES', 'Three objectives, each with a measure of success');
  {
    const gap = px(32), cw = (CW - 2 * gap) / 3, ch = BODY_H - 0.2;
    for (let i = 0; i < 3; i++) {
      const x = M.l + i * (cw + gap), last = i === 2;
      R(s, x, BODY_Y, cw, ch, last ? COL.deep : COL.white, 'Objective card');
      T(s, `0${i + 1}`, { x: x + 0.4, y: BODY_Y + 0.35, w: 1.5, h: 0.45, fontSize: 22, bold: true, color: last ? COL.saffron : COL.water });
      T(s, `[Objective ${i + 1}]`, { x: x + 0.4, y: BODY_Y + 0.9, w: cw - 0.8, h: 0.7, fontSize: 18, bold: true, color: last ? COL.white : COL.deep, valign: 'top' });
      T(s, '[What we will establish, decide or deliver, in one or two sentences.]', { x: x + 0.4, y: BODY_Y + 1.65, w: cw - 0.8, h: 1.1, fontSize: 13.5, color: last ? COL.spray : COL.slate, valign: 'top', lineSpacingMultiple: 1.2 });
      s.addShape('line', { x: x + 0.4, y: BODY_Y + ch - 1.25, w: cw - 0.8, h: 0, line: { color: last ? COL.undertow : COL.fog, width: 0.75 }, objectName: 'Rule' });
      T(s, 'MEASURE OF SUCCESS', { x: x + 0.4, y: BODY_Y + ch - 1.1, w: cw - 0.8, h: 0.3, fontSize: 9, bold: true, charSpacing: 2, color: last ? COL.shallows : COL.water });
      T(s, '[How the client will know this objective has been met]', { x: x + 0.4, y: BODY_Y + ch - 0.8, w: cw - 0.8, h: 0.6, fontSize: 12.5, color: last ? COL.white : COL.deep, valign: 'top' });
    }
  }
  s.addNotes('Keep to three objectives. Each needs a measure the client can check at the end of the engagement.');

  // 4 scope by cluster
  s = pres.addSlide({ masterName: 'KSA_TITLE', sectionTitle: 'Proposal' });
  head(s, 'SCOPE', 'Scope by cluster: what is in, and what is not');
  {
    const cls = [CLUSTERS[0], CLUSTERS[1], CLUSTERS[2]];
    const gap = px(40), cw = (CW - 2 * gap) / 3;
    cls.forEach((cl, i) => {
      const x = M.l + i * (cw + gap);
      R(s, x, BODY_Y, 0.5, 0.5, cl.color, 'Cluster badge');
      s.addImage({ path: K.iconPng(cl.icon, 'Line_White'), x: x + 0.1, y: BODY_Y + 0.1, w: 0.3, h: 0.3 });
      T(s, `[${cl.name}]`, { x: x + 0.65, y: BODY_Y, w: cw - 0.65, h: 0.5, fontSize: 15, bold: true, color: COL.deep, valign: 'middle' });
      s.addShape('line', { x, y: BODY_Y + 0.7, w: cw, h: 0, line: { color: COL.deep, width: 1.5 }, objectName: 'Rule' });
      T(s, 'IN SCOPE', { x, y: BODY_Y + 0.85, w: cw, h: 0.3, fontSize: 9, bold: true, charSpacing: 2, color: COL.water });
      T(s, bullets(['[Activity or question one]', '[Activity or question two]', '[Activity or question three]', '[Activity or question four]']), { x, y: BODY_Y + 1.15, w: cw, h: 1.9, fontSize: 13, color: COL.slate, valign: 'top' });
      s.addShape('line', { x, y: BODY_Y + 3.15, w: cw, h: 0, line: { color: COL.fog, width: 0.75 }, objectName: 'Hairline' });
      T(s, 'OUT OF SCOPE', { x, y: BODY_Y + 3.3, w: cw, h: 0.3, fontSize: 9, bold: true, charSpacing: 2, color: COL.clay });
      T(s, bullets(['[Excluded activity, and who covers it]']), { x, y: BODY_Y + 3.6, w: cw, h: 0.6, fontSize: 13, color: COL.slate, valign: 'top' });
    });
  }
  s.addNotes('Swap the three clusters for the ones this engagement draws on. Legal opinions and statutory audit are always out of scope.');

  // 5 approach
  s = pres.addSlide({ masterName: 'KSA_TITLE', sectionTitle: 'Proposal' });
  head(s, 'OUR APPROACH', 'Four strokes, from first look to lasting result');
  {
    const steps = [['01', 'Read the water', 'Diagnose', '[Interviews, data request, document review and a first hypothesis]'], ['02', 'Set the heading', 'Decide', '[Analysis, options, a recommendation and the case for it]'], ['03', 'Paddle together', 'Deliver', '[Working sessions with your team to carry the plan through]'], ['04', 'Hold the course', 'Sustain', '[Measures, a review rhythm and hand-over of the capability]']];
    const gap = px(24), cw = (CW - 3 * gap) / 4;
    steps.forEach((st, i) => {
      const x = M.l + i * (cw + gap), last = i === 3;
      s.addShape(i === 0 ? 'homePlate' : 'chevron', { x, y: BODY_Y, w: cw, h: 0.6, fill: { color: last ? COL.saffron : COL.water }, line: { color: last ? COL.saffron : COL.water, width: 0 }, objectName: 'Step chevron' });
      T(s, `${st[0]}  ${st[2].toUpperCase()}`, { x: x + (i === 0 ? 0.3 : 0.55), y: BODY_Y, w: cw - 0.9, h: 0.6, fontSize: 11, bold: true, charSpacing: 2, color: last ? COL.deep : COL.white, valign: 'middle' });
      R(s, x, BODY_Y + 0.8, cw, BODY_H - 0.9, last ? COL.deep : COL.mist, 'Step card');
      T(s, st[1], { x: x + 0.3, y: BODY_Y + 1.05, w: cw - 0.6, h: 0.5, fontSize: 18, bold: true, color: last ? COL.white : COL.deep });
      T(s, st[3], { x: x + 0.3, y: BODY_Y + 1.65, w: cw - 0.6, h: 1.5, fontSize: 13, color: last ? COL.spray : COL.slate, valign: 'top', lineSpacingMultiple: 1.2 });
      T(s, '[WEEKS x TO y]', { x: x + 0.3, y: BODY_Y + BODY_H - 0.55, w: cw - 0.6, h: 0.3, fontSize: 9.5, bold: true, charSpacing: 2, color: last ? COL.shallows : COL.water });
    });
  }
  s.addNotes('The four strokes are the same on every engagement; what changes is the weight of each. Give the weeks for each stroke.');

  // 6 workplan gantt
  s = pres.addSlide({ masterName: 'KSA_TITLE', sectionTitle: 'Proposal' });
  head(s, 'WORKPLAN', '[Twelve] weeks from kick-off to final read-out');
  {
    const lx = M.l + 2.6, gw = CW - 2.6, weeks = 12, cw = gw / weeks, top = BODY_Y;
    for (let w = 0; w < weeks; w++) {
      T(s, `W${w + 1}`, { x: lx + w * cw, y: top, w: cw, h: 0.3, fontSize: 9.5, bold: true, color: COL.slate, align: 'center' });
      s.addShape('line', { x: lx + w * cw, y: top + 0.35, w: 0, h: 3.3, line: { color: COL.fog, width: 0.75 }, objectName: 'Grid' });
    }
    s.addShape('line', { x: lx + weeks * cw, y: top + 0.35, w: 0, h: 3.3, line: { color: COL.fog, width: 0.75 }, objectName: 'Grid' });
    const rows = [['[Mobilise and data request]', 0, 2, COL.slate], ['[Diagnose: interviews and analysis]', 1, 4, COL.deep], ['[Decide: options and recommendation]', 4, 3, COL.water], ['[Deliver: working sessions]', 6, 4, COL.water], ['[Sustain: hand-over and review]', 9, 3, COL.shallows]];
    rows.forEach((r, i) => {
      const y = top + 0.55 + i * 0.6;
      T(s, r[0], { x: M.l, y, w: 2.5, h: 0.4, fontSize: 11.5, bold: true, color: COL.deep, valign: 'middle' });
      R(s, lx + r[1] * cw + 0.03, y + 0.05, r[2] * cw - 0.06, 0.3, r[3], `Bar ${i + 1}`);
    });
    const my = top + 0.55 + 5 * 0.6 + 0.2;
    T(s, 'MILESTONES', { x: M.l, y: my - 0.2, w: 2.5, h: 0.4, fontSize: 9.5, bold: true, charSpacing: 2, color: COL.slate, valign: 'middle' });
    s.addShape('line', { x: lx, y: my, w: gw, h: 0, line: { color: COL.water, width: 1.5, dashType: 'dash' }, objectName: 'Route line' });
    [[2, '[Kick-off]'], [5, '[Interim read-out]'], [9, '[Recommendation]'], [12, '[Final read-out]']].forEach((m, i) => {
      const x = lx + m[0] * cw, last = i === 3;
      s.addShape('diamond', { x: x - 0.14, y: my - 0.14, w: 0.28, h: 0.28, fill: { color: last ? COL.saffron : COL.white }, line: { color: last ? COL.saffron : COL.water, width: 1.5 }, objectName: 'Milestone' });
      T(s, m[1], { x: last ? x - 1.8 : x - 0.9, y: my + 0.22, w: 1.8, h: 0.3, fontSize: 10, bold: true, color: COL.deep, align: last ? 'right' : 'center' });
    });
  }
  s.addNotes('Bars and milestones are plain shapes: drag them to the right weeks. Keep the four milestones; they are the client’s checkpoints.');

  // 7 team
  s = pres.addSlide({ masterName: 'KSA_TITLE', sectionTitle: 'Proposal' });
  head(s, 'YOUR TEAM', 'Senior people, start to finish');
  {
    const gap = px(32), cw = (CW - 3 * gap) / 4, ch = BODY_H - 0.1;
    [['AB', '[Lead partner]'], ['CD', '[Engagement manager]'], ['EF', '[Senior adviser]'], ['GH', '[Analyst]']].forEach((p, i) => {
      const x = M.l + i * (cw + gap), y = BODY_Y;
      R(s, x, y, cw, ch, COL.mist, 'Team card');
      R(s, x + px(32), y + px(32), 1.1, 1.1, COL.deep, 'Portrait placeholder');
      T(s, p[0], { x: x + px(32), y: y + px(32), w: 1.1, h: 1.1, fontSize: 22, bold: true, color: COL.white, align: 'center', valign: 'middle' });
      T(s, '[Full Name]', { x: x + px(32), y: y + 1.6, w: cw - px(64), h: 0.4, fontSize: 16, bold: true, color: COL.deep });
      T(s, p[1], { x: x + px(32), y: y + 2.0, w: cw - px(64), h: 0.35, fontSize: 12, bold: true, color: COL.water });
      T(s, '[Role on this engagement and relevant experience, in two lines]', { x: x + px(32), y: y + 2.45, w: cw - px(64), h: 1.0, fontSize: 12.5, color: COL.slate, valign: 'top', lineSpacingMultiple: 1.15 });
      T(s, '[x] days on site', { x: x + px(32), y: y + ch - 0.55, w: cw - px(64), h: 0.3, fontSize: 10.5, bold: true, charSpacing: 1, color: COL.slate });
    });
  }
  s.addNotes('Name the lead partner first. The people on this slide are the people who do the work.');

  // 8 deliverables table
  s = pres.addSlide({ masterName: 'KSA_TITLE', sectionTitle: 'Proposal' });
  head(s, 'DELIVERABLES', 'What you will receive, and when');
  {
    const hdr = ['#', 'DELIVERABLE', 'WHAT IT CONTAINS', 'FORMAT', 'WEEK'].map((t, i) => ({ text: t, options: { bold: true, fontSize: 9.5, color: COL.slate, charSpacing: 1.5, align: i === 4 ? 'right' : 'left', border: [{ type: 'none' }, { type: 'none' }, { pt: 1.5, color: COL.deep }, { type: 'none' }] } }));
    const rows = [
      ['1', '[Scoping note]', '[Question, approach, team and timeline agreed at kick-off]', 'Word', '[1]'],
      ['2', '[Interim read-out]', '[Early findings and the emerging hypothesis for discussion]', 'PowerPoint', '[5]'],
      ['3', '[Recommendation report]', '[Options, recommendation, the evidence and the risks]', 'PowerPoint and Word', '[9]'],
      ['4', '[Implementation plan]', '[Workstreams, owners, milestones and measures]', 'Excel and PowerPoint', '[11]'],
      ['5', '[Final read-out and hand-over]', '[Board presentation and capability hand-over pack]', 'PowerPoint', '[12]'],
    ].map((r) => r.map((c, i) => ({ text: c, options: { fontSize: 12, color: i === 1 ? COL.deep : COL.slate, bold: i === 1, align: i === 4 ? 'right' : 'left' } })));
    s.addTable([hdr, ...rows], { x: M.l, y: BODY_Y, w: CW, colW: [0.5, 3.0, 4.9, 2.2, 0.956], rowH: 0.55, fontFace: 'Archivo', margin: [0.06, 0.08, 0.06, 0.08], valign: 'middle', border: { type: 'solid', pt: 0.75, color: COL.fog }, fill: { color: COL.white }, objectName: 'Deliverables table' });
    T(s, 'All deliverables are issued in draft for comment before final issue. Working files are handed over at the end of the engagement.', { x: M.l, y: BODY_Y + 6 * 0.55 + 0.3, w: CW, h: 0.5, fontSize: 11, color: COL.slate });
  }
  s.addNotes('One row per deliverable. The week column should match the milestones on the workplan.');

  // 9 fees
  s = pres.addSlide({ masterName: 'KSA_TITLE', sectionTitle: 'Proposal' });
  head(s, 'FEES', 'A fixed fee, agreed before work begins');
  {
    const hdr = ['PHASE', 'SCOPE', 'TIMING', 'FEE (₹ LAKH)'].map((t, i) => ({ text: t, options: { bold: true, fontSize: 9.5, color: COL.slate, charSpacing: 1.5, align: i >= 2 ? 'right' : 'left', border: [{ type: 'none' }, { type: 'none' }, { pt: 1.5, color: COL.deep }, { type: 'none' }] } }));
    const body = [
      ['[Diagnose]', '[Interviews, data analysis and interim read-out]', '[Weeks 1 to 5]', '[00.0]'],
      ['[Decide]', '[Options, recommendation and report]', '[Weeks 5 to 9]', '[00.0]'],
      ['[Deliver and sustain]', '[Working sessions, plan and hand-over]', '[Weeks 9 to 12]', '[00.0]'],
    ].map((r) => r.map((c, i) => ({ text: c, options: { fontSize: 12, color: i === 0 ? COL.deep : COL.slate, bold: i === 0, align: i >= 2 ? 'right' : 'left' } })));
    const total = ['Total professional fees', '', 'Excluding GST and expenses', '[00.0]'].map((c, i) => ({ text: c, options: { fontSize: 12.5, bold: i !== 2, color: COL.deep, align: i >= 2 ? 'right' : 'left', fill: { color: COL.haze }, border: [{ pt: 1, color: COL.deep }, { type: 'none' }, { pt: 1.5, color: COL.deep }, { type: 'none' }] } }));
    s.addTable([hdr, ...body, total], { x: M.l, y: BODY_Y, w: 7.4, colW: [1.8, 2.7, 1.4, 1.5], rowH: 0.55, fontFace: 'Archivo', margin: [0.06, 0.08, 0.06, 0.08], valign: 'middle', border: { type: 'solid', pt: 0.75, color: COL.fog }, fill: { color: COL.white }, objectName: 'Fee table' });
    const nx = M.l + 7.9, nw = CW - 7.9;
    R(s, nx, BODY_Y, nw, BODY_H - 0.2, COL.mist, 'Fee notes');
    T(s, 'HOW WE INVOICE', { x: nx + 0.3, y: BODY_Y + 0.3, w: nw - 0.6, h: 0.3, fontSize: 9.5, bold: true, charSpacing: 2, color: COL.water });
    T(s, bullets(['[Milestone billing: [x]% at kick-off, [y]% at the recommendation, [z]% at final read-out]', '[Expenses at cost, capped at [x]% of fees, with prior approval]', '[GST at the prevailing rate]', '[Payment within [30] days of invoice]', '[Changes to scope agreed in writing before work starts]'], { gap: 6 }), { x: nx + 0.3, y: BODY_Y + 0.7, w: nw - 0.6, h: BODY_H - 1.1, fontSize: 12, color: COL.deep, valign: 'top', lineSpacingMultiple: 1.15 });
  }
  s.addNotes('Figures in lakh; use crore for larger engagements. State what is excluded, and the invoicing schedule, on the same slide.');

  // 10 assumptions
  s = pres.addSlide({ masterName: 'KSA_TITLE_MIST', sectionTitle: 'Proposal' });
  head(s, 'ASSUMPTIONS AND DEPENDENCIES', 'What the plan and the fee depend on');
  {
    const gap = px(32), cw = (CW - gap) / 2, ch = BODY_H - 0.2;
    [['ASSUMPTIONS', ['[Access to the data and documents listed in the data request within [x] days of kick-off]', '[Availability of [n] interviewees in weeks 1 to 4]', '[A single client sponsor with authority to make decisions]', '[Work carried out in English, remotely and on site in [City]]', '[Scope limited to the entities and markets named in this proposal]']], ['DEPENDENCIES AND YOUR TEAM', ['[A named counterpart for each workstream]', '[Fortnightly steering meetings of 45 minutes]', '[Timely review of drafts: comments within [5] working days]', '[Legal and audit matters handled by your existing advisers]', '[Decisions on scope changes within one week]']]].forEach((c, i) => {
      const x = M.l + i * (cw + gap);
      R(s, x, BODY_Y, cw, ch, COL.white, 'Panel');
      T(s, c[0], { x: x + 0.4, y: BODY_Y + 0.35, w: cw - 0.8, h: 0.3, fontSize: 10, bold: true, charSpacing: 2, color: i === 0 ? COL.water : COL.saffron });
      T(s, bullets(c[1], { gap: 10 }), { x: x + 0.4, y: BODY_Y + 0.8, w: cw - 0.8, h: ch - 1.1, fontSize: 13, color: COL.slate, valign: 'top', lineSpacingMultiple: 1.15 });
    });
  }
  s.addNotes('Every assumption here protects the fee and the timeline. Agree them with the sponsor before signature.');

  // 11 why kayak
  s = pres.addSlide({ masterName: 'KSA_TITLE_DARK', sectionTitle: 'Proposal' });
  head(s, 'WHY KAYAK', 'A boutique’s attention, with the reach of a full firm');
  {
    const items = [['strategy', 'Strategy and risk in one room', 'Growth and protection decided together, not in separate meetings.'], ['user', 'Senior people, every day', 'A small, experienced team that stays with you throughout.'], ['globe', 'India depth, global reach', 'Sector knowledge at home and an International Desk for cross-border work.'], ['check', 'Answers you can act on', 'Clear recommendations, and help to carry them through.']];
    const gap = px(40), cw = (CW - gap) / 2, ch = 1.9;
    items.forEach((it, i) => {
      const x = M.l + (i % 2) * (cw + gap), y = BODY_Y + 0.1 + Math.floor(i / 2) * (ch + gap);
      s.addImage({ path: K.iconPng(it[0], 'Duotone_Reversed'), x, y: y + 0.05, w: 0.5, h: 0.5 });
      T(s, it[1], { x: x + 0.8, y, w: cw - 0.8, h: 0.5, fontSize: 20, bold: true, color: COL.white, valign: 'middle' });
      T(s, it[2], { x: x + 0.8, y: y + 0.6, w: cw - 0.8, h: 1.0, fontSize: 15, fontFace: SERIF, color: COL.spray, valign: 'top', lineSpacingMultiple: 1.25 });
      if (i < 2) s.addShape('line', { x, y: y + ch, w: cw, h: 0, line: { color: COL.undertow, width: 0.75 }, objectName: 'Rule' });
    });
  }
  s.addNotes('Add one example relevant to this client under each reason when presenting.');

  // 12 next steps
  s = pres.addSlide({ masterName: 'KSA_TITLE', sectionTitle: 'Proposal' });
  head(s, 'NEXT STEPS', 'From this proposal to kick-off in [three] weeks');
  {
    const steps = [['01', '[Proposal discussion]', '[Walk through scope, team and fees with the sponsor]', '[Week 0]'], ['02', '[Engagement letter]', '[Sign the letter, non-disclosure agreement and data-handling terms]', '[Week 1]'], ['03', '[Data request and interviews]', '[Issue the request list and schedule the first interviews]', '[Week 2]'], ['04', '[Kick-off]', '[Half-day session with your team to confirm the plan]', '[Week 3]']];
    const gap = px(32), cw = (CW - 3 * gap) / 4, ly = BODY_Y + 0.45;
    s.addShape('line', { x: M.l + cw / 2, y: ly, w: CW - cw, h: 0, line: { color: COL.water, width: 1.5, dashType: 'dash' }, objectName: 'Route line' });
    steps.forEach((st, i) => {
      const x = M.l + i * (cw + gap), cx = x + cw / 2, last = i === 3;
      s.addShape('diamond', { x: cx - 0.17, y: ly - 0.17, w: 0.34, h: 0.34, fill: { color: last ? COL.saffron : COL.white }, line: { color: last ? COL.saffron : COL.water, width: 1.5 }, objectName: 'Waypoint' });
      T(s, st[3], { x, y: ly + 0.35, w: cw, h: 0.35, fontSize: 10, bold: true, charSpacing: 2, color: COL.slate, align: 'center' });
      R(s, x, ly + 0.85, cw, 2.6, last ? COL.deep : COL.mist, 'Card');
      T(s, st[0], { x: x + px(28), y: ly + 1.05, w: cw - px(56), h: 0.4, fontSize: 18, bold: true, color: last ? COL.saffron : COL.water });
      T(s, st[1], { x: x + px(28), y: ly + 1.5, w: cw - px(56), h: 0.75, fontSize: 16, bold: true, color: last ? COL.white : COL.deep, valign: 'top' });
      T(s, st[2], { x: x + px(28), y: ly + 2.3, w: cw - px(56), h: 1.0, fontSize: 12.5, color: last ? COL.spray : COL.slate, valign: 'top', lineSpacingMultiple: 1.15 });
    });
  }
  s.addNotes('Propose a date for the proposal discussion before the meeting ends.');

  // 13 appendix divider
  pres.addSection({ title: 'Appendix' });
  s = pres.addSlide({ masterName: 'KSA_DIVIDER', sectionTitle: 'Appendix' });
  s.addText('A', { placeholder: 'number' });
  s.addText('Appendix', { placeholder: 'title' });
  s.addText('Credentials, detailed workplan, data request and terms of business.', { placeholder: 'subtitle' });
  s.addNotes('Add appendix slides after this divider: team CVs, relevant credentials, the detailed data request and terms of business.');

  // 14 closing
  s = pres.addSlide({ masterName: 'KSA_CLOSING', sectionTitle: 'Appendix' });
  s.addText('Thank you', { placeholder: 'title' });
  s.addText('Two paddlers. One course. We would be glad to make the crossing with you.', { placeholder: 'subtitle' });
  s.addText([
    { text: '[Full Name], [Designation]', options: { bold: true, breakLine: true } },
    { text: '[name]@kayaksa.com · [+91 00000 00000]', options: { breakLine: true } },
    { text: 'www.kayaksa.com · [Office address], [City]' },
  ], { placeholder: 'contact' });
  s.addNotes('This proposal is confidential to [Client name] and valid for [30] days from the date on the cover.');

  const out = await K.finish(pres, 'KSA_Service_Proposal.pptx');
  console.log('wrote', out, pres.slides.length, 'slides');
}
main().catch((e) => { console.error(e); process.exit(1); });
