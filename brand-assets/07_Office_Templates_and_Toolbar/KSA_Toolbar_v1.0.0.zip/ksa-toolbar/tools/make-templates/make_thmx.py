#!/usr/bin/env python3
"""Build KSA_Office_Theme.thmx from the theme part of a pptxgenjs deck that applyTheme has
already written the KSA colours and fonts into.

Usage: python3 make_thmx.py <deck.pptx> <out.thmx>
"""
import sys
import zipfile

CT = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/theme/theme/themeManager.xml" ContentType="application/vnd.openxmlformats-officedocument.themeManager+xml"/>
<Override PartName="/theme/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/>
</Types>'''
ROOT_RELS = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="theme/theme/themeManager.xml"/>
</Relationships>'''
MANAGER = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<a:themeManager xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main"/>'''
MANAGER_RELS = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme" Target="theme1.xml"/>
</Relationships>'''


def main(pptx, out):
    with zipfile.ZipFile(pptx) as z:
        theme = z.read('ppt/theme/theme1.xml')
    assert b'0E2F3C' in theme and b'Archivo' in theme, 'theme part does not carry the KSA colours and fonts; run the deck generator first'
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml', CT)
        z.writestr('_rels/.rels', ROOT_RELS)
        z.writestr('theme/theme/themeManager.xml', MANAGER)
        z.writestr('theme/theme/_rels/themeManager.xml.rels', MANAGER_RELS)
        z.writestr('theme/theme/theme1.xml', theme)
    print('wrote', out)


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
