// KSA_Corporate_Presentation.pptx: the 19-slide corporate deck, rebuilt natively.
'use strict';
const K = require('./lib/ksa');
const { COL, CLUSTERS, SERIF, px, M, CW, W, H } = K;

async function main() {
  const pres = K.newPres({ title: 'Kayak Strategic Advisors · Corporate presentation', subject: 'Corporate presentation' });
  K.defineLayouts(pres, { footer: 'Kayak Strategic Advisors · Corporate presentation' });

  const BODY_Y = 2.15;                 // top of the content zone under the title

  // ---- helpers -------------------------------------------------------------
  function head(slide, eyebrow, title) {
    slide.addText(eyebrow, { placeholder: 'eyebrow' });
    slide.addText(title, { placeholder: 'title' });
  }
  function card(slide, x, y, w, h, o) {
    const dark = !!o.dark;
    const fill = o.fill || (dark ? COL.deep : COL.white);
    slide.addShape('rect', { x, y, w, h, fill: { color: fill }, line: { color: fill, width: 0 }, objectName: 'Card' });
    let cy = y + px(40);
    const pad = px(40);
    if (o.icon) {
      slide.addImage({ path: K.iconPng(o.icon, dark ? 'Duotone_Reversed' : 'Duotone'), x: x + pad, y: cy, w: 0.42, h: 0.42 });
      cy += 0.6;
    }
    if (o.number) {
      slide.addText(o.number, { x: x + pad, y: cy, w: 1.2, h: 0.45, fontSize: 22, bold: true, color: o.numberColor || (dark ? COL.saffron : COL.water), margin: 0, isTextBox: true, objectName: 'Number' });
      cy += 0.55;
    }
    if (o.head) {
      const hh = o.headH || 0.5;
      slide.addText(o.head, { x: x + pad, y: cy, w: w - pad * 2, h: hh, fontSize: o.headSize || 16, bold: true, color: dark ? COL.white : COL.deep, margin: 0, valign: 'top', isTextBox: true, objectName: 'Card title', lineSpacingMultiple: 1.05 });
      cy += hh + px(8);
    }
    if (o.body) {
      slide.addText(o.body, { x: x + pad, y: cy, w: w - pad * 2, h: y + h - cy - px(24), fontSize: o.bodySize || 13, fontFace: o.serif ? SERIF : undefined, color: dark ? COL.spray : COL.slate, margin: 0, valign: 'top', isTextBox: true, objectName: 'Card body', lineSpacingMultiple: 1.15 });
    }
  }
  function rows(slide, x, y, w, items, { numW = 0.7, rowH = 0.95, headSize = 16, bodySize = 13, lastSaffron = true } = {}) {
    items.forEach((it, i) => {
      const ry = y + i * rowH;
      slide.addShape('line', { x, y: ry, w, h: 0, line: { color: i === 0 ? COL.deep : COL.fog, width: i === 0 ? 1.5 : 0.75 }, objectName: 'Rule' });
      slide.addText(it.n, { x, y: ry + px(18), w: numW, h: 0.45, fontSize: 20, bold: true, color: (lastSaffron && i === items.length - 1) ? COL.saffron : COL.water, margin: 0, isTextBox: true, objectName: 'Number' });
      slide.addText(it.head, { x: x + numW, y: ry + px(18), w: w - numW, h: 0.36, fontSize: headSize, bold: true, color: COL.deep, margin: 0, isTextBox: true, objectName: 'Row title' });
      slide.addText(it.body, { x: x + numW, y: ry + px(18) + 0.36, w: w - numW, h: rowH - 0.36 - px(18), fontSize: bodySize, color: COL.slate, margin: 0, valign: 'top', isTextBox: true, objectName: 'Row body' });
    });
    slide.addShape('line', { x, y: y + items.length * rowH, w, h: 0, line: { color: COL.fog, width: 0.75 }, objectName: 'Rule' });
  }

  // ---- 1 cover -------------------------------------------------------------
  pres.addSection({ title: 'Introduction' });
  let s = pres.addSlide({ masterName: 'KSA_COVER', sectionTitle: 'Introduction' });
  s.addText('Clear advice for consequential decisions', { placeholder: 'title' });
  s.addText('Strategy, deals, regulation and resilience for India’s boards, promoters and investors', { placeholder: 'subtitle' });
  s.addText('CORPORATE PRESENTATION · 2026 · WWW.KAYAKSA.COM', { placeholder: 'meta' });
  s.addNotes('Open with the name and the promise. Kayak Strategic Advisors helps leaders make consequential decisions with clear, evidence-led advice across strategy, transactions, risk and investigations.');

  // ---- 2 contents ----------------------------------------------------------
  s = pres.addSlide({ masterName: 'KSA_SPLIT', sectionTitle: 'Introduction' });
  head(s, 'CONTENTS', 'A short introduction to Kayak');
  s.addText('Who we are, what we do, how we work with you, and how to start a conversation.', { placeholder: 'body' });
  rows(s, M.l + 4.9, M.t + 0.34, CW - 4.9, [
    { n: '01', head: 'Who we are', body: 'The water our clients cross, our name and what we stand for' },
    { n: '02', head: 'What we do', body: 'Six practices, twelve services and the industries we serve' },
    { n: '03', head: 'How we work', body: 'Our approach, engagement models, standards and team' },
    { n: '04', head: 'Next steps', body: 'How a first conversation becomes an engagement' },
  ], { rowH: 1.3, headSize: 18, bodySize: 14, numW: 0.85 });
  s.addNotes('Four parts. Keep this slide brief; it sets expectations for a 30-minute introduction.');

  // ---- 3 context -----------------------------------------------------------
  pres.addSection({ title: 'Who we are' });
  s = pres.addSlide({ masterName: 'KSA_TITLE_MIST', sectionTitle: 'Who we are' });
  head(s, 'THE WATER WE ALL CROSS', 'Indian business is moving faster, through rougher water');
  {
    const gap = px(32), cw = (CW - 3 * gap) / 4, ch = 3.9;
    const items = [
      { icon: 'regulatory', head: 'Regulation is tightening', body: 'Data protection, disclosure, related-party and ESG reporting rules now reach the boardroom.' },
      { icon: 'due-diligence', head: 'Deals are harder to judge', body: 'More capital, more counterparties and less time make diligence the decision, not a formality.' },
      { icon: 'cybersecurity', head: 'Risk has gone digital', body: 'Counterfeits, impersonation and fraud now spread online at the speed of a marketplace.' },
      { icon: 'governance', head: 'Boards are answerable', body: 'Directors, promoters and investors are expected to know, and to show how they know.' },
    ];
    items.forEach((it, i) => card(s, M.l + i * (cw + gap), BODY_Y, cw, ch, { ...it, headH: 0.75, bodySize: 14 }));
  }
  s.addNotes('Set the context in the client’s terms before talking about Kayak. Examples to use in conversation: the Digital Personal Data Protection Act 2023, SEBI disclosure and related-party norms, BRSR reporting for listed companies, online counterfeiting during festive seasons.');

  // ---- 4 who ---------------------------------------------------------------
  s = pres.addSlide({ masterName: 'KSA_SPLIT_DARK', sectionTitle: 'Who we are' });
  s.addText('WHO WE ARE', { placeholder: 'eyebrow' });
  s.addText([{ text: 'Two paddlers.\nOne course.', options: { fontSize: 44 } }], { placeholder: 'title' });
  s.addText([
    { text: 'A kayak is a disciplined, agile craft. It crosses changing water through balance, direction and steady navigation. That is how we help clients through complex business, regulatory, technology and risk conditions.', options: { breakLine: true, paraSpaceAfter: 14 } },
    { text: 'Kayak Strategic Advisors gives independent, structured advice and hands-on support, working beside our clients like two kayakers moving as one.' },
  ], { x: M.l, y: 3.15, w: 7.2, h: 3.0, fontFace: SERIF, fontSize: 16, color: COL.spray, margin: 0, valign: 'top', isTextBox: true, lineSpacingMultiple: 1.35 });
  s.addImage({ path: K.logoPng('KSA_Identifier_Reversed', 800), x: 9.25, y: 2.2, w: 2.76, h: 3.0 });
  s.addNotes('The name carries the story. The identifier’s two blades are the client and Kayak: two strokes that converge on one stem, one decision carried through.');

  // ---- 5 values ------------------------------------------------------------
  s = pres.addSlide({ masterName: 'KSA_TITLE_MIST', sectionTitle: 'Who we are' });
  head(s, 'WHAT WE STAND FOR', 'Three values, drawn from the craft');
  {
    const gap = px(40), cw = (CW - 2 * gap) / 3, ch = 3.7;
    [
      { number: '01', head: 'Balance', body: 'A steady core that keeps every engagement upright, whatever the conditions.' },
      { number: '02', head: 'Clarity', body: 'Reading the water as it really is: the facts, the risks and what lies beneath the surface.' },
      { number: '03', head: 'Direction', body: 'A clear heading, and the conviction to act on it together with the client.', dark: true },
    ].forEach((it, i) => card(s, M.l + i * (cw + gap), BODY_Y + 0.1, cw, ch, { ...it, headSize: 24, headH: 0.55, serif: true, bodySize: 15 }));
  }
  s.addNotes('Balance, clarity and direction are what a good kayaker needs in rough water, and what a board needs from its advisers.');

  // ---- 6 principles --------------------------------------------------------
  pres.addSection({ title: 'How we work' });
  s = pres.addSlide({ masterName: 'KSA_SPLIT', sectionTitle: 'How we work' });
  head(s, 'HOW WE WORK', 'Five promises to every client');
  s.addText('They decide who we hire, how we staff an engagement and what we put in front of a board.', { placeholder: 'body' });
  rows(s, M.l + 4.9, M.t + 0.34, CW - 4.9, [
    { n: '01', head: 'Independent by design', body: 'Our advice serves your decision and nothing else.' },
    { n: '02', head: 'Senior-led, start to finish', body: 'The people who scope the work are the people who do it.' },
    { n: '03', head: 'Evidence before opinion', body: 'Every finding is sourced, tested and shown.' },
    { n: '04', head: 'Plain English, clear choices', body: 'Options, a recommendation and the reasons, on one page.' },
    { n: '05', head: 'Built to be carried out', body: 'We stay to help your team put the answer to work.' },
  ], { rowH: 1.02, headSize: 16, bodySize: 13, numW: 0.7 });
  s.addNotes('These five promises are the test for every piece of work. The fifth is the one clients remember: we do not hand over a report and leave.');

  // ---- 7 services divider --------------------------------------------------
  pres.addSection({ title: 'What we do' });
  s = pres.addSlide({ masterName: 'KSA_DIVIDER', sectionTitle: 'What we do' });
  s.addText('02', { placeholder: 'number' });
  s.addText('What we do', { placeholder: 'title' });
  s.addText('Six clusters of expertise, one team and one point of contact for the client.', { placeholder: 'subtitle' });
  s.addNotes('Section divider for the services part of the presentation.');

  // ---- 8 clusters ----------------------------------------------------------
  s = pres.addSlide({ masterName: 'KSA_TITLE_MIST', sectionTitle: 'What we do' });
  head(s, 'OUR SIX CLUSTERS', 'One firm for consequential decisions');
  {
    const descs = [
      'Where to grow, what to buy, and how to close well.',
      'Tax, compliance and reporting that keep pace with new rules.',
      'Risk, investigations and brand protection, before and after the storm.',
      'Digital, data and AI that are useful, governed and secure.',
      'Ongoing compliance, finance and monitoring, run for you.',
      'Into India, out of India, and the deals that cross borders.',
    ];
    const gap = px(28), cw = (CW - 2 * gap) / 3, ch = 1.95;
    CLUSTERS.forEach((cl, i) => {
      const x = M.l + (i % 3) * (cw + gap), y = BODY_Y + Math.floor(i / 3) * (ch + gap);
      s.addShape('rect', { x, y, w: cw, h: ch, fill: { color: COL.white }, line: { color: COL.white, width: 0 }, objectName: 'Card' });
      s.addShape('rect', { x: x + px(32), y: y + px(32), w: 0.6, h: 0.6, fill: { color: cl.color }, line: { color: cl.color, width: 0 }, objectName: 'Cluster badge' });
      s.addImage({ path: K.iconPng(cl.icon, 'Line_White'), x: x + px(32) + 0.12, y: y + px(32) + 0.12, w: 0.36, h: 0.36 });
      s.addText(cl.name, { x: x + px(32) + 0.8, y: y + px(28), w: cw - 0.8 - px(56), h: 0.42, fontSize: 16, bold: true, color: COL.deep, margin: 0, valign: 'middle', isTextBox: true, objectName: 'Cluster name' });
      s.addText(descs[i], { x: x + px(32) + 0.8, y: y + px(28) + 0.5, w: cw - 0.8 - px(56), h: ch - 0.5 - px(44), fontSize: 13, color: COL.slate, margin: 0, valign: 'top', isTextBox: true, objectName: 'Cluster description', lineSpacingMultiple: 1.15 });
    });
  }
  s.addNotes('Six clusters, one team. Clients get a single lead partner who draws on whichever clusters the question needs.');

  // ---- 9 and 10 services ---------------------------------------------------
  const services = [
    { eyebrow: 'WHAT EACH CLUSTER DOES · 1 OF 2', title: 'Growth, rules and the storms in between', cols: [
      { cl: CLUSTERS[0], items: ['Growth and market-entry strategy', 'M&A advisory, buy side and sell side', 'Commercial, financial and integrity due diligence', 'Valuation support and deal structuring', 'Post-deal integration and fundraising readiness'] },
      { cl: CLUSTERS[1], items: ['Direct tax, GST and transfer-pricing support', 'SEBI, RBI, FEMA and Companies Act compliance', 'Data protection readiness under the DPDP Act', 'ESG and BRSR reporting', 'Regulatory change monitoring and board briefings'] },
      { cl: CLUSTERS[2], items: ['Enterprise and third-party risk', 'Fraud, forensic and workplace investigations', 'Brand protection and anti-counterfeiting', 'IP enforcement support with your counsel', 'Crisis management and business continuity'] },
    ], notes: 'Tailor the bullets to the client before sending. Legal opinions and statutory audit are outside our scope; we work alongside the client’s counsel and auditors.' },
    { eyebrow: 'WHAT EACH CLUSTER DOES · 2 OF 2', title: 'Technology, continuity and reach', cols: [
      { cl: CLUSTERS[3], items: ['Digital and data strategy', 'AI adoption, use cases and governance', 'Analytics, dashboards and data quality', 'Cyber-risk assessment', 'Technology due diligence for deals'] },
      { cl: CLUSTERS[4], items: ['Outsourced compliance calendars and filings support', 'Virtual CFO and finance operations', 'HR and payroll compliance', 'Always-on brand and marketplace monitoring', 'Third-party due diligence as a service'] },
      { cl: CLUSTERS[5], items: ['India entry for overseas companies', 'Outbound expansion for Indian businesses', 'Cross-border deals and structuring', 'FDI, ODI and FEMA support', 'International due diligence and background checks'] },
    ], notes: 'Managed Services turns one-off work into a steady rhythm. The International Desk is the single entry point for cross-border work in both directions.' },
  ];
  for (const sv of services) {
    s = pres.addSlide({ masterName: 'KSA_TITLE', sectionTitle: 'What we do' });
    head(s, sv.eyebrow, sv.title);
    const gap = px(48), cw = (CW - 2 * gap) / 3;
    sv.cols.forEach((col, i) => {
      const x = M.l + i * (cw + gap);
      s.addShape('rect', { x, y: BODY_Y, w: 0.52, h: 0.52, fill: { color: col.cl.color }, line: { color: col.cl.color, width: 0 }, objectName: 'Cluster badge' });
      s.addImage({ path: K.iconPng(col.cl.icon, 'Line_White'), x: x + 0.1, y: BODY_Y + 0.1, w: 0.32, h: 0.32 });
      s.addText(col.cl.name, { x: x + 0.68, y: BODY_Y, w: cw - 0.68, h: 0.52, fontSize: 16, bold: true, color: COL.deep, margin: 0, valign: 'middle', isTextBox: true, objectName: 'Cluster name' });
      s.addShape('line', { x, y: BODY_Y + 0.75, w: cw, h: 0, line: { color: COL.deep, width: 1.5 }, objectName: 'Rule' });
      s.addText(col.items.map((t, j) => ({ text: t, options: { bullet: { indent: 14 }, breakLine: j < col.items.length - 1, paraSpaceAfter: 10 } })),
        { x, y: BODY_Y + 0.9, w: cw, h: 3.6, fontSize: 14, color: COL.slate, margin: 0, valign: 'top', isTextBox: true, objectName: 'Services', lineSpacingMultiple: 1.15 });
    });
    s.addNotes(sv.notes);
  }

  // ---- 11 industries -------------------------------------------------------
  s = pres.addSlide({ masterName: 'KSA_SPLIT_MIST', sectionTitle: 'What we do' });
  head(s, 'INDUSTRIES', 'Built around how each sector really works');
  s.addText('Our sector framework covers all 45 industries tracked by IBEF. For each one we map the value chain, the regulators and the questions boards ask most.', { placeholder: 'body', h: 1.6 });
  s.addText('45', { x: M.l, y: 4.3, w: 3, h: 1.2, fontSize: 72, bold: true, color: COL.water, margin: 0, isTextBox: true, objectName: 'Big number' });
  s.addText('sectors, one consistent way of reading them', { x: M.l, y: 5.55, w: 4.2, h: 0.5, fontSize: 13, color: COL.slate, margin: 0, isTextBox: true });
  {
    const names = ['Banking & financial services', 'Pharma & healthcare', 'Automotive & mobility', 'IT, BPM & digital', 'Retail & consumer', 'Infrastructure & real estate', 'Energy & renewables', 'Metals & manufacturing', 'Telecom & media', 'Agriculture & food'];
    const x0 = M.l + 5.2, gap = px(20), tw = (CW - 5.2 - gap) / 2, th = 0.72;
    names.forEach((n, i) => {
      const x = x0 + (i % 2) * (tw + gap), y = BODY_Y + Math.floor(i / 2) * (th + gap);
      s.addShape('rect', { x, y, w: tw, h: th, fill: { color: COL.white }, line: { color: COL.white, width: 0 }, objectName: 'Tile' });
      K.addBlade(s, x + px(24), y + th / 2 - 0.09, 0.14, 0.18, { dir: 'left', color: i === 9 ? COL.saffron : COL.water, name: 'Blade bullet' });
      s.addText(n, { x: x + 0.6, y, w: tw - 0.7, h: th, fontSize: 14, bold: true, color: COL.deep, margin: 0, valign: 'middle', isTextBox: true, objectName: 'Sector' });
    });
  }
  s.addNotes('Ten sector groups shown; the full framework covers all 45 IBEF industries. Swap in the sectors most relevant to the client.');

  // ---- 12 approach ---------------------------------------------------------
  s = pres.addSlide({ masterName: 'KSA_TITLE', sectionTitle: 'How we work' });
  head(s, 'OUR APPROACH', 'Four strokes, from first look to lasting result');
  {
    const steps = [
      { number: '01', head: 'Read the water', body: 'Diagnose: the facts, the risks, the people and what lies beneath.' },
      { number: '02', head: 'Set the heading', body: 'Decide: clear options, a recommendation and a plan you can defend.' },
      { number: '03', head: 'Paddle together', body: 'Deliver: we work alongside your team to carry the plan through.' },
      { number: '04', head: 'Hold the course', body: 'Sustain: measure, adjust and hand over with the capability in place.', dark: true },
    ];
    const gap = px(24), cw = (CW - 3 * gap) / 4;
    steps.forEach((st, i) => {
      const x = M.l + i * (cw + gap);
      s.addShape('chevron', { x, y: BODY_Y, w: cw, h: 0.6, fill: { color: st.dark ? COL.saffron : COL.water }, line: { color: st.dark ? COL.saffron : COL.water, width: 0 }, objectName: 'Step chevron' });
      s.addText(st.number, { x: x + 0.3, y: BODY_Y, w: cw - 0.6, h: 0.6, fontSize: 14, bold: true, color: st.dark ? COL.deep : COL.white, margin: 0, valign: 'middle', isTextBox: true, objectName: 'Step number' });
      card(s, x, BODY_Y + 0.8, cw, 3.1, { head: st.head, body: st.body, dark: st.dark, fill: st.dark ? COL.deep : COL.mist, headSize: 18, headH: 0.5, bodySize: 14 });
    });
  }
  s.addNotes('Every engagement follows the same four strokes, whether it is a two-week diligence or a year-long transformation. The fourth stroke is where most advisers stop and where we stay.');

  // ---- 13 engagement -------------------------------------------------------
  s = pres.addSlide({ masterName: 'KSA_TITLE_MIST', sectionTitle: 'How we work' });
  head(s, 'WAYS TO WORK WITH US', 'Four engagement models, one standard');
  {
    const items = [
      { icon: 'target', head: 'Focused project', body: 'A defined question, scope, team and fee. Best for strategy, diligence and reviews.' },
      { icon: 'partnership', head: 'Advisory retainer', body: 'A standing adviser for the board and leadership, on call when questions arise.' },
      { icon: 'calendar', head: 'Managed service', body: 'An ongoing function we run for you, with agreed service levels and reporting.' },
      { icon: 'risk', head: 'Rapid response', body: 'For a crisis, an allegation or a deal deadline: a senior team mobilised at short notice.' },
    ];
    const gap = px(28), cw = (CW - gap) / 2, ch = 1.85;
    items.forEach((it, i) => {
      const x = M.l + (i % 2) * (cw + gap), y = BODY_Y + Math.floor(i / 2) * (ch + gap);
      s.addShape('rect', { x, y, w: cw, h: ch, fill: { color: COL.white }, line: { color: COL.white, width: 0 }, objectName: 'Card' });
      s.addImage({ path: K.iconPng(it.icon), x: x + px(36), y: y + px(36), w: 0.5, h: 0.5 });
      s.addText(it.head, { x: x + 1.1, y: y + px(30), w: cw - 1.3, h: 0.45, fontSize: 18, bold: true, color: COL.deep, margin: 0, valign: 'middle', isTextBox: true, objectName: 'Model' });
      s.addText(it.body, { x: x + 1.1, y: y + px(30) + 0.5, w: cw - 1.3, h: ch - 0.5 - px(44), fontSize: 14, color: COL.slate, margin: 0, valign: 'top', isTextBox: true, objectName: 'Description', lineSpacingMultiple: 1.15 });
    });
  }
  s.addNotes('Fees are agreed before work starts and set out in the proposal: fixed, milestone-based or retainer, depending on the model.');

  // ---- 14 why --------------------------------------------------------------
  s = pres.addSlide({ masterName: 'KSA_TITLE_DARK', sectionTitle: 'How we work' });
  head(s, 'WHY KAYAK', 'A boutique’s attention, with the reach of a full firm');
  {
    const items = [
      { icon: 'strategy', head: 'Strategy and risk in one room', body: 'Growth and protection decided together, not in separate meetings.' },
      { icon: 'user', head: 'Senior people, every day', body: 'A small, experienced team that stays with you throughout.' },
      { icon: 'globe', head: 'India depth, global reach', body: 'Sector knowledge at home and an International Desk for cross-border work.' },
      { icon: 'check', head: 'Answers you can act on', body: 'Clear recommendations, and help to carry them through.' },
    ];
    const gap = px(40), cw = (CW - gap) / 2, ch = 1.9;
    items.forEach((it, i) => {
      const x = M.l + (i % 2) * (cw + gap), y = BODY_Y + 0.1 + Math.floor(i / 2) * (ch + gap);
      s.addImage({ path: K.iconPng(it.icon, 'Duotone_Reversed'), x, y: y + 0.05, w: 0.5, h: 0.5 });
      s.addText(it.head, { x: x + 0.8, y, w: cw - 0.8, h: 0.5, fontSize: 20, bold: true, color: COL.white, margin: 0, valign: 'middle', isTextBox: true, objectName: 'Reason' });
      s.addText(it.body, { x: x + 0.8, y: y + 0.6, w: cw - 0.8, h: 1.0, fontSize: 15, fontFace: SERIF, color: COL.spray, margin: 0, valign: 'top', isTextBox: true, objectName: 'Description', lineSpacingMultiple: 1.25 });
      if (i < 2) s.addShape('line', { x, y: y + ch, w: cw, h: 0, line: { color: COL.undertow, width: 0.75 }, objectName: 'Rule' });
    });
  }
  s.addNotes('The four reasons clients choose a boutique adviser. Use one client-specific example in conversation for each.');

  // ---- 15 trust ------------------------------------------------------------
  s = pres.addSlide({ masterName: 'KSA_TITLE_MIST', sectionTitle: 'How we work' });
  head(s, 'OUR STANDARDS', 'Discretion is part of the work');
  {
    const items = [
      { icon: 'contract', head: 'Confidential by default', body: 'A non-disclosure agreement before detailed talks; need-to-know teams.' },
      { icon: 'filters', head: 'Conflicts checked first', body: 'Every new engagement is screened before we accept it.' },
      { icon: 'data', head: 'Data handled with care', body: 'Personal data processed in line with the DPDP Act 2023.' },
      { icon: 'investigations', head: 'Evidence you can rely on', body: 'Documented sources and a clear chain of custody.' },
      { icon: 'compliance', head: 'Lawful, ethical methods', body: 'We decline work that would breach the law or our values.' },
      { icon: 'partnership', head: 'Alongside your advisers', body: 'We work with your lawyers and auditors, never in place of them.' },
    ];
    const gap = px(24), cw = (CW - 2 * gap) / 3, ch = 1.9;
    items.forEach((it, i) => {
      const x = M.l + (i % 3) * (cw + gap), y = BODY_Y + Math.floor(i / 3) * (ch + gap);
      s.addShape('rect', { x, y, w: cw, h: ch, fill: { color: i === 5 ? COL.deep : COL.white }, line: { color: i === 5 ? COL.deep : COL.white, width: 0 }, objectName: 'Card' });
      s.addImage({ path: K.iconPng(it.icon, i === 5 ? 'Duotone_Reversed' : 'Duotone'), x: x + px(32), y: y + px(32), w: 0.42, h: 0.42 });
      s.addText(it.head, { x: x + px(32), y: y + px(32) + 0.55, w: cw - px(64), h: 0.4, fontSize: 15, bold: true, color: i === 5 ? COL.white : COL.deep, margin: 0, valign: 'top', isTextBox: true, objectName: 'Standard' });
      s.addText(it.body, { x: x + px(32), y: y + px(32) + 0.95, w: cw - px(64), h: ch - 0.95 - px(44), fontSize: 12.5, color: i === 5 ? COL.spray : COL.slate, margin: 0, valign: 'top', isTextBox: true, objectName: 'Description', lineSpacingMultiple: 1.15 });
    });
  }
  s.addNotes('These standards matter most for investigations and transactions. Confirm the client’s own policies on data sharing during scoping.');

  // ---- 16 confluence -------------------------------------------------------
  s = pres.addSlide({ masterName: 'KSA_SPLIT', sectionTitle: 'How we work' });
  head(s, 'OUR MONTHLY MAGAZINE', 'Confluence: where strategy and risk meet');
  s.addText('Named after the meeting of two streams in our identifier. Each issue brings one cover story and a monthly read across all six clusters, free to clients and subscribers.', { placeholder: 'body', h: 2.2 });
  {
    const rx = M.l + 4.9, rw = CW - 4.9 - 3.4 - 0.4;
    const secs = ['Deal Water', 'Regulatory Radar', 'Storm Watch', 'Signal', 'Across the Water', 'By the Numbers'];
    const gap = px(12), tw = rw, th = 0.5;
    s.addText('SIX REGULAR SECTIONS', { x: rx, y: M.t + 0.34, w: rw, h: 0.3, fontSize: 10, bold: true, charSpacing: 2, color: COL.slate, margin: 0, isTextBox: true });
    secs.forEach((n, i) => {
      const x = rx, y = M.t + 0.75 + i * (th + gap);
      s.addShape('rect', { x, y, w: tw, h: th, fill: { color: COL.mist }, line: { color: COL.mist, width: 0 }, objectName: 'Section tile' });
      s.addText(n, { x: x + 0.2, y, w: tw - 0.3, h: th, fontSize: 13, bold: true, color: COL.deep, margin: 0, valign: 'middle', isTextBox: true, objectName: 'Section name' });
    });
    s.addText([{ text: 'First Tuesday of every month · ' }, { text: 'kayaksa.com/confluence', options: { bold: true, color: COL.water } }], { x: rx, y: M.t + 0.75 + 6 * (th + gap) + 0.1, w: rw, h: 0.6, fontSize: 12, color: COL.slate, margin: 0, isTextBox: true });
    // magazine cover mock on the right
    const mw = 3.4, mh = H - M.t - M.b - 0.5, mx = W - M.r - mw, my = M.t;
    s.addImage({ path: K.patternPng('09', 'accent-dark'), x: mx, y: my, w: mw, h: mh, sizing: { type: 'cover', w: mw, h: mh } });
    s.addText('ISSUE 01 · [MONTH] 2026', { x: mx + 0.3, y: my + 0.3, w: mw - 0.6, h: 0.3, fontSize: 9, bold: true, charSpacing: 2, color: COL.spray, margin: 0, isTextBox: true });
    s.addText('CONFLUENCE', { x: mx + 0.3, y: my + 0.7, w: mw - 0.5, h: 0.6, fontSize: 24, bold: true, charSpacing: 3, color: COL.white, margin: 0, isTextBox: true, fit: 'shrink' });
    s.addText('The Kayak monthly on strategy, risk and the decisions between them', { x: mx + 0.3, y: my + 1.35, w: mw - 0.6, h: 0.6, fontSize: 10, fontFace: SERIF, italic: true, color: COL.spray, margin: 0, isTextBox: true });
    s.addImage({ path: K.markPng('blade-rule-saffron'), x: mx + 0.3, y: my + mh - 1.55, w: px(72), h: px(9) });
    s.addText('Growth and risk are one decision', { x: mx + 0.3, y: my + mh - 1.4, w: mw - 0.6, h: 1.1, fontSize: 20, bold: true, color: COL.white, margin: 0, valign: 'top', isTextBox: true });
  }
  s.addNotes('Offer to add the client’s leadership team to the Confluence distribution list. The Kayak Brief email announces each issue.');

  // ---- 17 team -------------------------------------------------------------
  s = pres.addSlide({ masterName: 'KSA_TITLE', sectionTitle: 'How we work' });
  head(s, 'LEADERSHIP', 'The people you will work with');
  {
    const gap = px(32), cw = (CW - 3 * gap) / 4, ch = 3.9;
    ['AB', 'CD', 'EF', 'GH'].forEach((ini, i) => {
      const x = M.l + i * (cw + gap), y = BODY_Y;
      s.addShape('rect', { x, y, w: cw, h: ch, fill: { color: COL.mist }, line: { color: COL.mist, width: 0 }, objectName: 'Team card' });
      s.addShape('rect', { x: x + px(32), y: y + px(32), w: 1.1, h: 1.1, fill: { color: COL.deep }, line: { color: COL.deep, width: 0 }, objectName: 'Portrait placeholder' });
      s.addText(ini, { x: x + px(32), y: y + px(32), w: 1.1, h: 1.1, fontSize: 22, bold: true, color: COL.white, align: 'center', valign: 'middle', margin: 0, isTextBox: true, objectName: 'Initials' });
      s.addText('[Full Name]', { x: x + px(32), y: y + 1.6, w: cw - px(64), h: 0.4, fontSize: 16, bold: true, color: COL.deep, margin: 0, isTextBox: true, objectName: 'Name' });
      s.addText('[Designation]', { x: x + px(32), y: y + 2.0, w: cw - px(64), h: 0.35, fontSize: 12, bold: true, color: COL.water, margin: 0, isTextBox: true, objectName: 'Designation' });
      s.addText('[Cluster and areas of expertise, in one or two lines]', { x: x + px(32), y: y + 2.45, w: cw - px(64), h: 1.1, fontSize: 12.5, color: COL.slate, margin: 0, valign: 'top', isTextBox: true, objectName: 'Bio', lineSpacingMultiple: 1.15 });
    });
  }
  s.addNotes('Replace the initials with square-cropped portraits in natural light, and name the lead partner for this client first.');

  // ---- 18 next steps -------------------------------------------------------
  pres.addSection({ title: 'Next steps' });
  s = pres.addSlide({ masterName: 'KSA_TITLE_MIST', sectionTitle: 'Next steps' });
  head(s, 'NEXT STEPS', 'From first conversation to first result');
  {
    const steps = [
      { n: '01', head: 'A confidential conversation', body: 'You tell us the question; we listen and ask what matters.' },
      { n: '02', head: 'A short scoping note', body: 'The question, approach, team and timeline on two pages.' },
      { n: '03', head: 'A clear proposal', body: 'Scope, deliverables and a fee agreed before work begins.' },
      { n: '04', head: 'We start paddling', body: 'Kick-off with your team, and a first read-out within [x] weeks.' },
    ];
    const gap = px(32), cw = (CW - 3 * gap) / 4, ly = BODY_Y + 0.45;
    // route line with waypoint diamonds (navigator's marks)
    s.addShape('line', { x: M.l + cw / 2, y: ly, w: CW - cw, h: 0, line: { color: COL.water, width: 1.5, dashType: 'dash' }, objectName: 'Route line' });
    steps.forEach((st, i) => {
      const x = M.l + i * (cw + gap), cx = x + cw / 2;
      const last = i === steps.length - 1;
      s.addShape('diamond', { x: cx - 0.17, y: ly - 0.17, w: 0.34, h: 0.34, fill: { color: last ? COL.saffron : COL.mist }, line: { color: last ? COL.saffron : COL.water, width: 1.5 }, objectName: 'Waypoint' });
      s.addText(st.n, { x, y: ly + 0.45, w: cw, h: 0.45, fontSize: 20, bold: true, color: last ? COL.saffron : COL.water, align: 'center', margin: 0, isTextBox: true, objectName: 'Step number' });
      s.addShape('rect', { x, y: ly + 1.0, w: cw, h: 2.5, fill: { color: last ? COL.deep : COL.white }, line: { color: last ? COL.deep : COL.white, width: 0 }, objectName: 'Card' });
      s.addText(st.head, { x: x + px(28), y: ly + 1.2, w: cw - px(56), h: 0.8, fontSize: 17, bold: true, color: last ? COL.white : COL.deep, margin: 0, valign: 'top', isTextBox: true, objectName: 'Step title', lineSpacingMultiple: 1.05 });
      s.addText(st.body, { x: x + px(28), y: ly + 2.05, w: cw - px(56), h: 1.3, fontSize: 13.5, color: last ? COL.spray : COL.slate, margin: 0, valign: 'top', isTextBox: true, objectName: 'Step body', lineSpacingMultiple: 1.15 });
    });
  }
  s.addNotes('Close with a concrete next step: propose a date for the confidential conversation before the meeting ends. Replace [x] with the timeline agreed for this client.');

  // ---- 19 closing ----------------------------------------------------------
  s = pres.addSlide({ masterName: 'KSA_CLOSING', sectionTitle: 'Next steps' });
  s.addText('Thank you', { placeholder: 'title' });
  s.addText('Two paddlers. One course. We would be glad to make the crossing with you.', { placeholder: 'subtitle' });
  s.addText([
    { text: '[Full Name], [Designation]', options: { bold: true, breakLine: true } },
    { text: '[name]@kayaksa.com · [+91 00000 00000]', options: { breakLine: true } },
    { text: 'www.kayaksa.com · [Office address], [City]' },
  ], { placeholder: 'contact' });
  s.addNotes('Leave the contact slide up during questions. Send the deck as a PDF after the meeting with a short covering note.');

  const out = await K.finish(pres, 'KSA_Corporate_Presentation.pptx');
  console.log('wrote', out, pres.slides.length, 'slides');
}
main().catch((e) => { console.error(e); process.exit(1); });
