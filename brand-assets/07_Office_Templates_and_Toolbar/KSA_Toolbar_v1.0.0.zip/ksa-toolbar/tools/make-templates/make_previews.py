#!/usr/bin/env python3
"""Render preview PNGs (480 px wide) into assets/templates/previews:
  <library id>.png      every slide of KSA_Slide_Library.pptx, named by its id
  report.<block>.png    every page of KSA_Report_Layouts.docx, named by block id
  tpl-<name>.png        the cover of every template file
  tpl-office-theme.png  a swatch sheet for the .thmx

Usage: python3 make_previews.py   (paths are resolved relative to this script)
"""
import json
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
TEMPLATES = ROOT / 'assets/templates'
PREVIEWS = TEMPLATES / 'previews'
SOFFICE = '/mnt/skills/public/pptx/scripts/office/soffice.py'
WIDTH = 480


def to_pdf(src: Path, workdir: Path) -> Path:
    subprocess.run([sys.executable, SOFFICE, '--headless', '--convert-to', 'pdf', '--outdir', str(workdir), str(src)], check=True, capture_output=True)
    return workdir / (src.stem + '.pdf')


def pages(pdf: Path, workdir: Path, prefix: str, first=None, last=None):
    cmd = ['pdftoppm', '-png', '-scale-to-x', str(WIDTH), '-scale-to-y', '-1']
    if first:
        cmd += ['-f', str(first)]
    if last:
        cmd += ['-l', str(last)]
    cmd += [str(pdf), str(workdir / prefix)]
    subprocess.run(cmd, check=True)
    return sorted(workdir.glob(prefix + '-*.png'), key=lambda p: int(p.stem.rsplit('-', 1)[1]))


def swatch_png(out: Path):
    from PIL import Image, ImageDraw
    cols = [('0E2F3C', 'Deep Current'), ('FFFFFF', 'White'), ('3E5563', 'Storm Slate'), ('EEF4F1', 'Sea Mist'), ('17807E', 'Open Water'), ('EE9B1E', 'Beacon Saffron'),
            ('2D6A9F', 'Tidewater Blue'), ('4B7A4E', 'Kelp Green'), ('9C630E', 'Burnished Gold'), ('5E4B78', 'Dusk Plum')]
    im = Image.new('RGB', (WIDTH, 270), 'white')
    d = ImageDraw.Draw(im)
    w = WIDTH // 5
    for i, (hexc, name) in enumerate(cols):
        x, y = (i % 5) * w, (i // 5) * 120 + 20
        d.rectangle([x + 6, y, x + w - 6, y + 70], fill='#' + hexc, outline='#D4DEE2')
        d.text((x + 8, y + 76), name, fill='#3E5563')
    d.text((8, 250), 'KSA Office theme: Archivo / Archivo', fill='#0E2F3C')
    im.save(out)


def main():
    PREVIEWS.mkdir(parents=True, exist_ok=True)
    work = Path(tempfile.mkdtemp())
    # slide library, one PNG per id
    index = json.loads((HERE / 'slide-library-index.json').read_text())
    pdf = to_pdf(TEMPLATES / 'KSA_Slide_Library.pptx', work)
    imgs = pages(pdf, work, 'lib')
    for sl in index['slides']:
        shutil.copy(imgs[sl['slideIndex'] - 1], PREVIEWS / f"{sl['id']}.png")
    shutil.copy(imgs[0], PREVIEWS / 'tpl-slide-library.png')
    # report layout blocks, one PNG per page
    rindex = json.loads((HERE / 'report-layouts-index.json').read_text())
    pdf = to_pdf(TEMPLATES / 'KSA_Report_Layouts.docx', work)
    imgs = pages(pdf, work, 'rep')
    for bl in rindex['blocks']:
        shutil.copy(imgs[bl['page'] - 1], PREVIEWS / f"{bl['id']}.png")
    shutil.copy(imgs[0], PREVIEWS / 'tpl-report-layouts.png')
    # template covers
    for src, name in [('KSA_Corporate_Presentation.pptx', 'tpl-corporate-presentation'), ('KSA_Service_Proposal.pptx', 'tpl-service-proposal'),
                      ('KSA_Service_Proposal.docx', 'tpl-service-proposal-docx'), ('KSA_Thought_Leadership.docx', 'tpl-thought-leadership'),
                      ('KSA_Excel_Charts.xlsx', 'tpl-excel-charts')]:
        pdf = to_pdf(TEMPLATES / src, work)
        page = 2 if src.endswith('.xlsx') else 1   # the workbook's first sheet is the read-me; show the first chart sheet
        imgs = pages(pdf, work, name, first=page, last=page)
        shutil.copy(imgs[0], PREVIEWS / f'{name}.png')
    swatch_png(PREVIEWS / 'tpl-office-theme.png')
    shutil.rmtree(work)
    print('previews:', len(list(PREVIEWS.glob('*.png'))), 'files in', PREVIEWS)


if __name__ == '__main__':
    main()
