# make-templates

Generators for every native Office file the KSA Toolbar ships in `assets/templates/`,
the Word layout snippets in `assets/layouts/word/` and the two index files the add-in reads.
Everything is built from code so a brand change is a one-line edit in `lib/ksa.js`.

## What gets built

| Output | Generator | Notes |
|---|---|---|
| `assets/templates/KSA_Corporate_Presentation.pptx` | `build-corporate.js` | 19 slides from `S/deck2/project/slides`, speaker notes included |
| `assets/templates/KSA_Slide_Library.pptx` + `slide-library-index.json` | `build-library.js` then `postprocess_library.py` | 68 insertable slides: 14 layouts, 12 charts, 12 diagrams, 10 infographics, 14 shapes, 6 effects. Title placeholder = library id |
| `assets/templates/KSA_Service_Proposal.pptx` | `build-proposal.js` | 14 slides, bracketed placeholders |
| `assets/templates/KSA_Service_Proposal.docx`, `KSA_Thought_Leadership.docx`, `KSA_Report_Layouts.docx` | `build-docx.js` | A4, Archivo body, Source Serif 4 standfirsts; also writes one .docx per layout block into `.cache/blocks/` and `report-layouts-index.json` |
| `assets/layouts/word/<block>.xml` | `make_ooxml_blocks.py` | flat `pkg:package` snippets for `insertOoxml`, built from `.cache/blocks/*.docx` |
| `assets/templates/KSA_Excel_Charts.xlsx` | `build-xlsx.py` | openpyxl; native charts and a RAG scorecard with formulas and conditional formatting |
| `assets/templates/KSA_Office_Theme.thmx` | `make_thmx.py` | theme part lifted from the corporate deck after `applyTheme` |
| `assets/templates/previews/*.png` | `make_previews.py` | 480 px wide: one per library id, one per report block (`report.<id>.png`), `tpl-<name>.png` per template |

## Regenerate everything

```bash
cd tools/make-templates
node build-corporate.js
node build-library.js && python3 postprocess_library.py ../../assets/templates/KSA_Slide_Library.pptx slide-library-index.json
node build-proposal.js
node build-docx.js && python3 make_ooxml_blocks.py .cache/blocks ../../assets/layouts/word report-layouts-index.json
python3 build-xlsx.py
python3 make_thmx.py ../../assets/templates/KSA_Corporate_Presentation.pptx ../../assets/templates/KSA_Office_Theme.thmx
python3 make_previews.py
```

Then validate (every file should report `All validations PASSED!`):

```bash
for f in ../../assets/templates/*.pptx ../../assets/templates/*.docx; do python3 /mnt/skills/public/pptx/scripts/office/validate.py "$f"; done
python3 /mnt/skills/public/xlsx/scripts/recalc.py ../../assets/templates/KSA_Excel_Charts.xlsx
```

Visual QA: `python3 /mnt/skills/public/pptx/scripts/office/soffice.py --headless --convert-to pdf <file>` then `pdftoppm -jpeg -r 60 <file>.pdf page`.
Archivo and Source Serif 4 are installed in the build environment, so renders are true to width.

## Dependencies

* Node: `pptxgenjs` 4.x, `docx` 9.x, `sharp` (all preinstalled; no `npm install` needed). `lib/ksa.js` also requires
  `/mnt/skills/public/pptx/scripts/apply_theme.js` to write the KSA colour scheme into each deck.
* Python 3: `openpyxl`, `lxml`, `Pillow`; LibreOffice (`soffice`) and Poppler (`pdftoppm`) for previews.
* Source material (read only): the scratchpad `S` with the KSA icons (`S/icons/out/.../SVG/<variant>`), patterns
  (`S/vg/out/KSA_Brand_Patterns`) and the logo SVGs in `assets/logo`. Icons and logos are rasterised to PNG with sharp on
  first use and cached in `.cache/` (safe to delete).

## How the pieces fit

* `lib/ksa.js` holds the theme (`THEME`: dk1 0E2F3C, lt1 FFFFFF, dk2 3E5563, lt2 EEF4F1, accent1 17807E ... fonts Archivo /
  Archivo), the colour table, the slide grid (13.333 x 7.5 in, margins 128 / 96 / 64 px), the KSA layouts
  (`KSA_COVER`, `KSA_COVER_LIGHT`, `KSA_DIVIDER`, `KSA_TITLE`, `KSA_TITLE_MIST`, `KSA_TITLE_DARK`, `KSA_SPLIT*`,
  `KSA_CLOSING`), the brand shapes drawn as custom geometry (blades, tags, blade rule, split rule) and `chartBase()`,
  the chart preset that applies the chart rules (Open Water primary, Fog gridlines, no borders, `+mn-lt` fonts).
* `lib/ksadocx.js` is the Word counterpart: A4 page set-up (15 / 20 / 22 mm), styles, header and footer, and the ten
  report layout blocks used by both the long documents and the standalone snippets.
* `postprocess_library.py` wraps the shapes of every diagram, infographic and shape slide into a single `<p:grpSp>` so
  the asset moves as one object, hides the waterfall's base series, names each slide after its id and records the numeric
  slide id (`sourceSlideId`) for `insertSlidesFromBase64`.
* `slide-library-index.json`: `{ file, slides: [{ id, slideIndex (1-based), sourceSlideIds ["256"...], name, category, subcategory, description, tags, preview, grouped }] }`.
  `report-layouts-index.json`: `{ file, blocks: [{ id: "report.<block>", page, name, category, description, tags, file: "assets/layouts/word/report.<block>.xml", preview, fullPage }] }`.
* `assets/templates/KSA_Email_Templates.html` is hand-written (three inline-styled tables with `{{name}} {{title}} {{phone}} {{email}}` tokens); it has no generator.

## Conventions

* British English, no em dashes, placeholders in square brackets, no client names.
* One Beacon Saffron accent per slide; every chart native (`addChart`), every diagram editable shapes.
* Chart text uses `+mn-lt` so it follows the theme body font.
* If you add a library slide, register it with `add()` in `build-library.js`; the index, grouping and previews follow.
