#!/usr/bin/env python3
"""Turn each standalone block .docx (written by build-docx.js into .cache/blocks) into a
flat OPC package (pkg:package XML) that Word's Office.js insertOoxml accepts.

Each package carries the document part, its relationships, styles, numbering and any
media (base64 binary parts). Header, footer, settings and font-table relationships are
dropped, and the body's final sectPr is removed so the block inserts inline.

Usage: python3 make_ooxml_blocks.py <blocks-dir> <out-dir> <report-layouts-index.json>
"""
import base64
import json
import re
import sys
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

PKG_NS = 'http://schemas.microsoft.com/office/2006/xmlPackage'
CT = {
    '/_rels/.rels': 'application/vnd.openxmlformats-package.relationships+xml',
    '/word/document.xml': 'application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml',
    '/word/_rels/document.xml.rels': 'application/vnd.openxmlformats-package.relationships+xml',
    '/word/styles.xml': 'application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml',
    '/word/numbering.xml': 'application/vnd.openxmlformats-officedocument.wordprocessingml.numbering+xml',
}
DROP_REL_TYPES = ('/header', '/footer', '/settings', '/fontTable', '/webSettings', '/theme', '/comments', '/footnotes', '/endnotes', '/core-properties', '/extended-properties', '/customXml')


def strip_decl(xml: str) -> str:
    return re.sub(r'^\s*<\?xml[^>]*\?>\s*', '', xml)


def build_package(docx_path: Path, full_page: bool) -> str:
    with zipfile.ZipFile(docx_path) as z:
        names = set(z.namelist())
        read = lambda n: z.read(n).decode('utf-8')
        document = strip_decl(read('word/document.xml'))
        # drop the final section properties so the block inserts inline; full-page blocks end with a page break
        if full_page:
            document = re.sub(r'<w:sectPr\b.*?</w:sectPr>', '<w:p><w:r><w:br w:type="page"/></w:r></w:p>', document, count=1, flags=re.S)
        else:
            document = re.sub(r'<w:sectPr\b.*?</w:sectPr>', '', document, count=1, flags=re.S)
        rels = strip_decl(read('word/_rels/document.xml.rels'))
        rels = re.sub(r'<Relationship\b[^>]*Type="[^"]*(?:%s)"[^>]*/>' % '|'.join(re.escape(t) for t in DROP_REL_TYPES), '', rels)
        parts = []
        parts.append(('/_rels/.rels', CT['/_rels/.rels'], '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>'))
        parts.append(('/word/document.xml', CT['/word/document.xml'], document))
        parts.append(('/word/_rels/document.xml.rels', CT['/word/_rels/document.xml.rels'], rels))
        parts.append(('/word/styles.xml', CT['/word/styles.xml'], strip_decl(read('word/styles.xml'))))
        if 'word/numbering.xml' in names:
            parts.append(('/word/numbering.xml', CT['/word/numbering.xml'], strip_decl(read('word/numbering.xml'))))
        media = []
        for n in sorted(names):
            if n.startswith('word/media/'):
                ext = n.rsplit('.', 1)[-1].lower()
                ctype = {'png': 'image/png', 'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'gif': 'image/gif', 'svg': 'image/svg+xml'}.get(ext, 'application/octet-stream')
                media.append(('/' + n, ctype, base64.b64encode(z.read(n)).decode('ascii')))
    out = ['<?xml version="1.0" encoding="UTF-8" standalone="yes"?>', f'<pkg:package xmlns:pkg="{PKG_NS}">']
    for name, ctype, xml in parts:
        out.append(f'<pkg:part pkg:name="{name}" pkg:contentType="{ctype}"><pkg:xmlData>{xml}</pkg:xmlData></pkg:part>')
    for name, ctype, b64 in media:
        out.append(f'<pkg:part pkg:name="{name}" pkg:contentType="{ctype}" pkg:compression="store"><pkg:binaryData>{b64}</pkg:binaryData></pkg:part>')
    out.append('</pkg:package>')
    return '\n'.join(out)


def main(blocks_dir, out_dir, index_path):
    blocks_dir, out_dir = Path(blocks_dir), Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    index = json.loads(Path(index_path).read_text())
    by_file = {Path(v['file']).stem: v for v in index['blocks']}
    n = 0
    for docx in sorted(blocks_dir.glob('*.docx')):
        meta = by_file.get(docx.stem, {})
        xml = build_package(docx, bool(meta.get('fullPage')))
        (out_dir / f'{docx.stem}.xml').write_text(xml, encoding='utf-8')
        n += 1
    print(f'wrote {n} OOXML block packages to {out_dir}')


if __name__ == '__main__':
    main(*sys.argv[1:4])
