#!/usr/bin/env python3
"""KSA_Excel_Charts.xlsx: sample sheets with KSA-styled native charts and a RAG scorecard.

Usage: python3 build-xlsx.py <out.xlsx>
"""
import sys
from pathlib import Path

from openpyxl import Workbook
from openpyxl.chart import BarChart, LineChart, DoughnutChart, Reference, Series
from openpyxl.chart.label import DataLabelList
from openpyxl.chart.layout import Layout, ManualLayout
from openpyxl.chart.shapes import GraphicalProperties
from openpyxl.chart.text import RichText
from openpyxl.drawing.line import LineProperties
from openpyxl.drawing.text import CharacterProperties, Paragraph, ParagraphProperties, Font as DFont
from openpyxl.formatting.rule import CellIsRule, FormulaRule
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter
from openpyxl.worksheet.table import Table, TableStyleInfo

C = dict(deep='0E2F3C', water='17807E', saffron='EE9B1E', mist='EEF4F1', slate='3E5563', fog='D4DEE2', river='8B9A9C',
         kelp='4B7A4E', clay='B4472F', tide='2D6A9F', gold='9C630E', plum='5E4B78', sand='D8C5A1', shallows='5DB2AB',
         haze='FBEBCD', white='FFFFFF', ink='1D2F38')
CAT = [C['water'], C['tide'], C['kelp'], C['slate'], C['sand'], C['plum'], C['shallows'], '9AAD5A']
FONT = 'Archivo'


# ---------------------------------------------------------------- cell styles
def style_header(ws, row, ncols, left_cols=1):
    for c in range(1, ncols + 1):
        cell = ws.cell(row=row, column=c)
        cell.font = Font(name=FONT, size=9, bold=True, color=C['slate'])
        cell.alignment = Alignment(horizontal='left' if c <= left_cols else 'right', vertical='center')
        cell.border = Border(bottom=Side(style='medium', color=C['deep']))
        cell.fill = PatternFill('solid', fgColor=C['white'])


def style_body(ws, r0, r1, ncols, left_cols=1, number_format='#,##0.0'):
    for r in range(r0, r1 + 1):
        for c in range(1, ncols + 1):
            cell = ws.cell(row=r, column=c)
            cell.font = Font(name=FONT, size=10, color=C['ink'])
            cell.alignment = Alignment(horizontal='left' if c <= left_cols else 'right', vertical='center')
            cell.border = Border(bottom=Side(style='hair', color=C['fog']))
            if c > left_cols:
                cell.number_format = number_format


def title(ws, text, sub, row=1):
    ws.cell(row=row, column=1, value=text).font = Font(name=FONT, size=14, bold=True, color=C['deep'])
    ws.cell(row=row + 1, column=1, value=sub).font = Font(name=FONT, size=9, color=C['slate'])
    ws.row_dimensions[row].height = 24


def source(ws, row, text='Source: [Source]; KSA analysis'):
    ws.cell(row=row, column=1, value=text).font = Font(name=FONT, size=8, color=C['slate'])


# ---------------------------------------------------------------- chart styling
def txpr(size=900, color=C['slate'], bold=False):
    cp = CharacterProperties(sz=size, b=bold, solidFill=color, latin=DFont(typeface=FONT))
    return RichText(p=[Paragraph(pPr=ParagraphProperties(defRPr=cp), endParaRPr=cp)])


def ksa_chart(chart, w=18, h=9):
    chart.width, chart.height = w, h
    chart.style = 2
    chart.legend = None
    chart.graphical_properties = GraphicalProperties(ln=LineProperties(noFill=True))
    chart.graphical_properties.noFill = True
    if hasattr(chart, 'y_axis') and chart.y_axis is not None:
        chart.y_axis.majorGridlines.spPr = GraphicalProperties(ln=LineProperties(solidFill=C['fog'], w=6350))
        chart.y_axis.graphicalProperties = GraphicalProperties(ln=LineProperties(noFill=True))
        chart.y_axis.txPr = txpr()
        chart.y_axis.number_format = '#,##0'
        chart.y_axis.delete = False
    if hasattr(chart, 'x_axis') and chart.x_axis is not None:
        chart.x_axis.graphicalProperties = GraphicalProperties(ln=LineProperties(solidFill=C['river'], w=6350))
        chart.x_axis.txPr = txpr()
        chart.x_axis.delete = False
        if getattr(chart.x_axis, 'majorGridlines', None) is not None:
            chart.x_axis.majorGridlines = None
    return chart


def colour_series(s, color, line=False, width=2.0, dash=None):
    if line:
        s.graphicalProperties.line.solidFill = color
        s.graphicalProperties.line.width = int(width * 12700)
        if dash:
            s.graphicalProperties.line.dashStyle = dash
        s.marker.symbol = 'none'
        s.smooth = False
    else:
        s.graphicalProperties.solidFill = color
        s.graphicalProperties.line.noFill = True


def labels(s, pos='outEnd', fmt='#,##0.0', color=C['deep']):
    s.dLbls = DataLabelList()
    s.dLbls.showVal = True
    s.dLbls.showSerName = False
    s.dLbls.showCatName = False
    s.dLbls.showLegendKey = False
    s.dLbls.position = pos
    s.dLbls.numFmt = fmt
    s.dLbls.txPr = txpr(color=color)


# ---------------------------------------------------------------- sheets
def sheet_column(wb):
    ws = wb.active
    ws.title = 'Column highlight'
    title(ws, 'EBITDA margin crossed the peer median in FY25, the first time in a decade', 'EBITDA margin, % of revenue, FY21 to FY26')
    ws.append([])
    ws.append(['Year', 'Margin %', 'Peer median %'])
    data = [('FY21', 10.2, 14.0), ('FY22', 10.8, 14.0), ('FY23', 11.4, 14.0), ('FY24', 11.1, 14.0), ('FY25', 15.1, 14.0), ('FY26E', 15.8, 14.0)]
    for r in data:
        ws.append(list(r))
    style_header(ws, 4, 3)
    style_body(ws, 5, 10, 3)
    source(ws, 12)
    bar = BarChart()
    bar.type = 'col'
    bar.gapWidth = 60
    bar.add_data(Reference(ws, min_col=2, min_row=4, max_row=10), titles_from_data=True)
    bar.set_categories(Reference(ws, min_col=1, min_row=5, max_row=10))
    s = bar.series[0]
    colour_series(s, C['water'])
    labels(s)
    # highlight FY25 (index 4) in saffron
    from openpyxl.chart.marker import DataPoint
    pt = DataPoint(idx=4)
    pt.graphicalProperties.solidFill = C['saffron']
    pt.graphicalProperties.line.noFill = True
    s.dPt.append(pt)
    line = LineChart()
    line.add_data(Reference(ws, min_col=3, min_row=4, max_row=10), titles_from_data=True)
    colour_series(line.series[0], C['slate'], line=True, width=1.0, dash='dash')
    bar += line
    ksa_chart(bar)
    ws.add_chart(bar, 'E4')
    ws.column_dimensions['A'].width = 12
    ws.column_dimensions['B'].width = 12
    ws.column_dimensions['C'].width = 14


def sheet_bar(wb):
    ws = wb.create_sheet('Sorted bar')
    title(ws, 'The client leads the peer set on CASA ratio', 'CASA ratio, % of deposits, Q1 FY26; sorted largest first')
    ws.append([])
    ws.append(['Entity', 'CASA %'])
    for r in [('[Peer E]', 29.4), ('[Peer D]', 33.0), ('[Peer C]', 36.9), ('[Peer B]', 38.5), ('[Peer A]', 41.8), ('[Client]', 44.2)]:
        ws.append(list(r))
    style_header(ws, 4, 2)
    style_body(ws, 5, 10, 2)
    source(ws, 12)
    bar = BarChart()
    bar.type = 'bar'
    bar.gapWidth = 45
    bar.add_data(Reference(ws, min_col=2, min_row=4, max_row=10), titles_from_data=True)
    bar.set_categories(Reference(ws, min_col=1, min_row=5, max_row=10))
    s = bar.series[0]
    colour_series(s, C['river'])
    labels(s)
    from openpyxl.chart.marker import DataPoint
    pt = DataPoint(idx=5)
    pt.graphicalProperties.solidFill = C['saffron']
    pt.graphicalProperties.line.noFill = True
    s.dPt.append(pt)
    ksa_chart(bar)
    bar.y_axis.delete = True
    bar.y_axis.majorGridlines = None
    ws.add_chart(bar, 'D4')
    ws.column_dimensions['A'].width = 12


def sheet_grouped(wb):
    ws = wb.create_sheet('Grouped and stacked')
    title(ws, 'Fee income grows in every cluster', 'Fees by cluster, ₹ crore, FY23 to FY26')
    ws.append([])
    ws.append(['Year', 'Strategy & Deals', 'Tax & Regulatory', 'Crisis & Resilience'])
    for r in [('FY23', 42, 31, 18), ('FY24', 48, 35, 21), ('FY25', 53, 36, 26), ('FY26E', 57, 41, 28)]:
        ws.append(list(r))
    style_header(ws, 4, 4)
    style_body(ws, 5, 8, 4, number_format='#,##0')
    source(ws, 10)
    grouped = BarChart()
    grouped.type = 'col'
    grouped.grouping = 'clustered'
    grouped.gapWidth = 80
    grouped.add_data(Reference(ws, min_col=2, max_col=4, min_row=4, max_row=8), titles_from_data=True)
    grouped.set_categories(Reference(ws, min_col=1, min_row=5, max_row=8))
    for i, s in enumerate(grouped.series):
        colour_series(s, CAT[i])
    ksa_chart(grouped, w=15, h=8)
    grouped.legend = None
    from openpyxl.chart.legend import Legend
    grouped.legend = Legend()
    grouped.legend.position = 'b'
    grouped.legend.txPr = txpr()
    ws.add_chart(grouped, 'F4')
    stacked = BarChart()
    stacked.type = 'col'
    stacked.grouping = 'stacked'
    stacked.overlap = 100
    stacked.gapWidth = 70
    stacked.add_data(Reference(ws, min_col=2, max_col=4, min_row=4, max_row=8), titles_from_data=True)
    stacked.set_categories(Reference(ws, min_col=1, min_row=5, max_row=8))
    for i, s in enumerate(stacked.series):
        colour_series(s, CAT[i])
        labels(s, pos='ctr', fmt='#,##0', color=C['white'])
    ksa_chart(stacked, w=15, h=8)
    stacked.legend = Legend()
    stacked.legend.position = 'b'
    stacked.legend.txPr = txpr()
    ws.add_chart(stacked, 'F22')
    for col, w in zip('ABCD', (10, 18, 18, 20)):
        ws.column_dimensions[col].width = w


def sheet_line(wb):
    ws = wb.create_sheet('Line and benchmark')
    title(ws, 'Unsecured retail credit growth halved after the RBI raised risk weights', 'Year-on-year growth, %, by quarter; benchmark dashed')
    ws.append([])
    ws.append(['Quarter', 'Growth %', 'Benchmark %'])
    q = ['Q1 FY23', 'Q2', 'Q3', 'Q4', 'Q1 FY24', 'Q2', 'Q3', 'Q4', 'Q1 FY25', 'Q2', 'Q3', 'Q4']
    v = [22.1, 24.6, 27.0, 29.4, 28.1, 24.2, 20.3, 17.6, 15.1, 13.0, 11.8, 10.6]
    for i, (qq, vv) in enumerate(zip(q, v)):
        ws.append([qq, vv, 18.0])
    style_header(ws, 4, 3)
    style_body(ws, 5, 16, 3)
    source(ws, 18, 'Source: RBI sectoral deployment data; KSA analysis. Illustrative figures.')
    line = LineChart()
    line.add_data(Reference(ws, min_col=2, max_col=3, min_row=4, max_row=16), titles_from_data=True)
    line.set_categories(Reference(ws, min_col=1, min_row=5, max_row=16))
    colour_series(line.series[0], C['water'], line=True, width=2.0)
    colour_series(line.series[1], C['slate'], line=True, width=1.0, dash='dash')
    ksa_chart(line)
    from openpyxl.chart.legend import Legend
    line.legend = Legend()
    line.legend.position = 'b'
    line.legend.txPr = txpr()
    ws.add_chart(line, 'E4')
    ws.column_dimensions['A'].width = 12


def sheet_donut(wb):
    ws = wb.create_sheet('Donut')
    title(ws, 'Strategy and Tax earn six in ten rupees of fees', 'FY25 fees by cluster, % of total')
    ws.append([])
    ws.append(['Cluster', 'Share %'])
    for r in [('Strategy & Deals', 36), ('Tax & Regulatory', 25), ('Crisis & Resilience', 19), ('Technology & AI', 11), ('Other', 9)]:
        ws.append(list(r))
    style_header(ws, 4, 2)
    style_body(ws, 5, 9, 2, number_format='0')
    source(ws, 11)
    d = DoughnutChart()
    d.holeSize = 82
    d.add_data(Reference(ws, min_col=2, min_row=4, max_row=9), titles_from_data=True)
    d.set_categories(Reference(ws, min_col=1, min_row=5, max_row=9))
    from openpyxl.chart.marker import DataPoint
    s = d.series[0]
    for i, col in enumerate([C['water'], C['gold'], C['slate'], C['tide'], C['river']]):
        pt = DataPoint(idx=i)
        pt.graphicalProperties.solidFill = col
        pt.graphicalProperties.line.solidFill = C['white']
        pt.graphicalProperties.line.width = 25400
        s.dPt.append(pt)
    d.width, d.height = 12, 9
    d.style = 2
    from openpyxl.chart.legend import Legend
    d.legend = Legend()
    d.legend.position = 'r'
    d.legend.txPr = txpr()
    d.graphical_properties = GraphicalProperties(ln=LineProperties(noFill=True))
    ws.add_chart(d, 'D4')
    ws.column_dimensions['A'].width = 20


def sheet_scorecard(wb):
    ws = wb.create_sheet('RAG scorecard')
    title(ws, 'Two of six controls are off track; KYC backlog is growing', 'Compliance programme, [Client name], Q2 FY27. Status is computed from actual vs target; shape and colour follow the rules below.')
    ws.append([])
    hdr = ['KPI', 'Actual', 'Target', 'Higher is better', 'Variance', 'Status']
    ws.append(hdr)
    rows = [('Vendor DD coverage %', 86, 95, 'Yes'), ('Whistle-blower response within 30 days %', 92, 85, 'Yes'), ('KYC backlog, accounts', 14820, 5000, 'No'),
            ('Policy attestation %', 98, 98, 'Yes'), ('Incident containment, hours', 6.2, 4.0, 'No'), ('Audit points closed %', 71, 90, 'Yes')]
    r0 = 5
    for i, (k, a, t, hb) in enumerate(rows):
        r = r0 + i
        ws.append([k, a, t, hb])
        ws.cell(row=r, column=5, value=f'=IF(D{r}="Yes",(B{r}-C{r})/C{r},(C{r}-B{r})/C{r})')
        ws.cell(row=r, column=6, value=f'=IF(E{r}>=0,"● On track",IF(E{r}>=-0.1,"▲ At risk","◆ Off track"))')
    r1 = r0 + len(rows) - 1
    style_header(ws, 4, 6, left_cols=1)
    style_body(ws, r0, r1, 6, left_cols=1, number_format='#,##0.0')
    for r in range(r0, r1 + 1):
        ws.cell(row=r, column=4).alignment = Alignment(horizontal='center')
        ws.cell(row=r, column=5).number_format = '+0.0%;-0.0%;0.0%'
        ws.cell(row=r, column=6).alignment = Alignment(horizontal='left')
        ws.cell(row=r, column=6).font = Font(name=FONT, size=10, bold=True)
    rng = f'F{r0}:F{r1}'
    ws.conditional_formatting.add(rng, FormulaRule(formula=[f'LEFT(F{r0},1)="●"'], font=Font(name=FONT, bold=True, color=C['kelp']), fill=PatternFill('solid', fgColor='EAF1EA')))
    ws.conditional_formatting.add(rng, FormulaRule(formula=[f'LEFT(F{r0},1)="▲"'], font=Font(name=FONT, bold=True, color=C['gold']), fill=PatternFill('solid', fgColor=C['haze'])))
    ws.conditional_formatting.add(rng, FormulaRule(formula=[f'LEFT(F{r0},1)="◆"'], font=Font(name=FONT, bold=True, color=C['clay']), fill=PatternFill('solid', fgColor='F7E7E3')))
    ws.conditional_formatting.add(f'E{r0}:E{r1}', CellIsRule(operator='lessThan', formula=['0'], font=Font(name=FONT, color=C['clay'])))
    n = r1 + 2
    ws.cell(row=n, column=1, value='Rules: On track when actual meets target; At risk within 10% of target; Off track beyond. Shape carries status (circle, triangle, diamond); colour confirms it (Kelp, Burnished Gold, Red Clay).').font = Font(name=FONT, size=8, color=C['slate'])
    for col, w in zip('ABCDEF', (40, 12, 12, 16, 12, 16)):
        ws.column_dimensions[col].width = w


def sheet_readme(wb):
    ws = wb.create_sheet('Read me', 0)
    title(ws, 'KSA Excel charts', 'Sample sheets with Kayak Strategic Advisors chart styling. Copy a chart or sheet into your workbook and replace the data.')
    lines = [
        '',
        'Chart rules',
        'Primary series Open Water (#17807E); one Beacon Saffron (#EE9B1E) highlight per chart; context in Riverstone (#8B9A9C).',
        'Gridlines Fog (#D4DEE2) 0.5 pt; zero baseline; no chart border; no 3D, no pies, no dual axes unless the units differ.',
        'Categorical order: Open Water, Tidewater Blue, Kelp Green, Storm Slate, Estuary Sand, Dusk Plum, Shallows, Lichen.',
        'Donut thickness 18% (hole 82%); lines 2 pt; benchmark dashed Storm Slate 1 pt; labels Archivo 9 pt in Storm Slate.',
        'Every exhibit carries an insight title, a subtitle with measure and unit, and a source line.',
        '',
        'Sheets',
        'Column highlight: single series with the highlighted year in saffron and a dashed benchmark line.',
        'Sorted bar: horizontal bars sorted largest first; the client in saffron, peers in Riverstone.',
        'Grouped and stacked: three series in the categorical order, clustered and stacked.',
        'Line and benchmark: one line plus a dashed benchmark.',
        'Donut: five segments, legend on the right.',
        'RAG scorecard: actual vs target with a computed status and conditional formatting.',
        '',
        'Fonts: install Archivo and Source Serif 4 from the KSA brand package; Excel substitutes Arial if they are missing.',
    ]
    for i, t in enumerate(lines):
        c = ws.cell(row=4 + i, column=1, value=t)
        c.font = Font(name=FONT, size=11 if t in ('Chart rules', 'Sheets') else 10, bold=t in ('Chart rules', 'Sheets'), color=C['deep'] if t in ('Chart rules', 'Sheets') else C['ink'])
    ws.column_dimensions['A'].width = 120
    ws.sheet_view.showGridLines = False


def main(out):
    wb = Workbook()
    sheet_column(wb)
    sheet_bar(wb)
    sheet_grouped(wb)
    sheet_line(wb)
    sheet_donut(wb)
    sheet_scorecard(wb)
    sheet_readme(wb)
    for ws in wb.worksheets:
        ws.sheet_properties.tabColor = C['water']
        ws.page_setup.orientation = 'landscape'
        ws.page_setup.fitToWidth = 1
        ws.page_setup.fitToHeight = 0
        ws.sheet_properties.pageSetUpPr.fitToPage = True
        if ws.title != 'Read me':
            ws.sheet_view.showGridLines = False
    wb.properties.creator = 'Kayak Strategic Advisors'
    wb.properties.title = 'KSA Excel charts'
    wb.save(out)
    print('wrote', out, len(wb.worksheets), 'sheets')


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else str(Path(__file__).resolve().parents[2] / 'assets/templates/KSA_Excel_Charts.xlsx'))
