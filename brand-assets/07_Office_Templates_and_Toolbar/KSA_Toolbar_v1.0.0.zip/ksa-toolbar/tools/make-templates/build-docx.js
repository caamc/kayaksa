// Word templates: KSA_Service_Proposal.docx, KSA_Thought_Leadership.docx, KSA_Report_Layouts.docx,
// plus one standalone .docx per report layout block in .cache/blocks (make_ooxml_blocks.py turns
// those into pkg:package snippets for Word's insertOoxml).
'use strict';
const fs = require('fs');
const path = require('path');
const D = require('./lib/ksadocx');
const K = require('./lib/ksa');
const { docx, COL, CW, mm } = D;
const { Header, Footer, Paragraph, TextRun, Table, TableRow, TableCell, WidthType, AlignmentType, TableLayoutType, BorderStyle, PositionalTab, PositionalTabAlignment, PositionalTabLeader, PositionalTabRelativeTo } = docx;

const OUT = K.TEMPLATES;
const BLOCKS = path.join(K.CACHE, 'blocks');
fs.mkdirSync(BLOCKS, { recursive: true });
const emptyHF = { headers: { default: new Header({ children: [] }) }, footers: { default: new Footer({ children: [] }) } };

const contentsList = (items) => items.map(([n, t, p]) => new Paragraph({
  spacing: { before: 0, after: 0 }, tabStops: [{ type: docx.TabStopType.RIGHT, position: CW }], border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: COL.fog, space: 8 } },
  children: [
    new TextRun({ text: n, font: D.FONT, size: 20, bold: true, color: n === '05' ? COL.saffron : COL.water }),
    new TextRun({ text: '    ' + t, font: D.FONT, size: 20, bold: true, color: COL.deep }),
    new TextRun({ text: '\t' + p, font: D.FONT, size: 18, color: COL.slate }),
  ],
})).flatMap((p) => [p, new Paragraph({ spacing: { before: 0, after: 160 }, children: [] })]);

// ============================================================ 1. Service proposal
async function proposal() {
  const foot = 'Proposal for [Client name] · Confidential · [Month YYYY]';
  const main = [];
  main.push(D.styled('Eyebrow', 'CONTENTS'));
  main.push(D.styled('DocTitle', 'Proposal for [Client name]'));
  main.push(D.styled('Standfirst', '[Project name]: [one line on the question this proposal answers].'));
  main.push(...contentsList([['01', 'Our understanding of your needs', '3'], ['02', 'Objectives and scope', '4'], ['03', 'Our approach and workplan', '5'], ['04', 'Deliverables and team', '6'], ['05', 'Fees, assumptions and next steps', '7']]));
  main.push(D.pageBreak());

  main.push(D.H1('01  Our understanding of your needs'));
  main.push(D.styled('Standfirst', '[Two or three sentences on the situation as we heard it: what has changed, what is at stake and when the decision has to be made.]'));
  main.push(D.H2('What we heard'));
  main.push(D.body('[The context and the trigger for this work, in your words. Keep this to one paragraph that a board member would recognise as their own situation.]'));
  main.push(D.H2('What matters most'));
  main.push(...D.bullets(['[The first thing the answer has to get right]', '[The second thing the answer has to get right]', '[The constraint or sensitivity we must respect]']));
  main.push(D.H2('What success looks like'));
  main.push(D.body('[The decision, approval or result this work must enable, and the date by which it is needed.]'));
  main.push(...D.calloutBlock({ label: 'CONFIDENTIALITY', text: 'This proposal is confidential to [Client name]. It is valid for [30] days from the date on the cover and is subject to our standard terms of business in the appendix.' }));
  main.push(D.pageBreak());

  main.push(D.H1('02  Objectives and scope'));
  main.push(D.styled('Standfirst', 'Three objectives, each with a measure of success, and a scope that says what is in and what is not.'));
  main.push(...D.numbered([
    [new TextRun({ text: '[Objective one]. ', bold: true }), new TextRun('[What we will establish, decide or deliver.] Measure of success: [how you will know].')],
    [new TextRun({ text: '[Objective two]. ', bold: true }), new TextRun('[What we will establish, decide or deliver.] Measure of success: [how you will know].')],
    [new TextRun({ text: '[Objective three]. ', bold: true }), new TextRun('[What we will establish, decide or deliver.] Measure of success: [how you will know].')],
  ]));
  main.push(D.H2('Scope by cluster'));
  main.push(...D.dataTableBlock({ title: 'Scope: what is in, and what is not', subtitle: 'By service cluster', columns: ['Cluster', 'In scope', 'Out of scope'], rows: [['[Strategy, Deal & Transactions]', '[Activities and questions]', '[Excluded activity]'], ['[Tax & Regulatory]', '[Activities and questions]', '[Excluded activity]'], ['[Crisis & Resilience]', '[Activities and questions]', '[Excluded activity]']], highlight: -1, total: ['Always out of scope', 'Legal opinions and statutory audit', 'Handled by your advisers'], source: 'We work alongside your counsel and auditors, never in place of them.' }));
  main.push(D.pageBreak());

  main.push(D.H1('03  Our approach and workplan'));
  main.push(D.styled('Standfirst', 'Every engagement follows the same four strokes: read the water, set the heading, paddle together, hold the course.'));
  main.push(...D.numbered([
    [new TextRun({ text: 'Read the water (diagnose), weeks [1 to 4]. ', bold: true }), new TextRun('[Interviews, data request, document review and a first hypothesis.]')],
    [new TextRun({ text: 'Set the heading (decide), weeks [5 to 8]. ', bold: true }), new TextRun('[Analysis, options, a recommendation and the case for it.]')],
    [new TextRun({ text: 'Paddle together (deliver), weeks [9 to 11]. ', bold: true }), new TextRun('[Working sessions with your team to carry the plan through.]')],
    [new TextRun({ text: 'Hold the course (sustain), week [12] and after. ', bold: true }), new TextRun('[Measures, a review rhythm and hand-over of the capability.]')],
  ]));
  main.push(...D.exhibitFrameBlock({ number: 'EXHIBIT 1', headline: '[Twelve] weeks from kick-off to final read-out', subtitle: 'Workplan by week; milestones marked', source: 'Source: KSA workplan. Insert the Gantt from the proposal deck or the slide library (diagram.roadmap).', note: 'Note: dates assume kick-off on [date] and the data request met within [x] days.', height: mm(70) }));
  main.push(...D.pullQuoteBlock({ quote: 'The fourth stroke is where most advisers stop, and where we stay.', attribution: 'Kayak Strategic Advisors' }));
  main.push(D.pageBreak());

  main.push(D.H1('04  Deliverables and team'));
  main.push(...D.dataTableBlock({ title: 'What you will receive, and when', subtitle: 'Deliverables by week', columns: ['Deliverable', 'Contents', 'Format', 'Week'], rows: [['[Scoping note]', '[Question, approach, team, timeline]', 'Word', '[1]'], ['[Interim read-out]', '[Early findings and hypothesis]', 'PowerPoint', '[5]'], ['[Recommendation report]', '[Options, recommendation, evidence]', 'PowerPoint, Word', '[9]'], ['[Implementation plan]', '[Workstreams, owners, measures]', 'Excel, PowerPoint', '[11]']], highlight: -1, total: ['[Final read-out and hand-over]', '[Board presentation, hand-over pack]', 'PowerPoint', '[12]'], source: 'All deliverables are issued in draft for comment before final issue.' }));
  main.push(D.H2('Your team'));
  main.push(...D.twoColumnBlock({ left: ['[Full Name], lead partner', '[Role on this engagement and relevant experience, in three lines. The people who scope the work are the people who do it.]', '[Full Name], engagement manager: [role and experience].'], right: ['[Full Name], senior adviser', '[Role on this engagement and relevant experience, in three lines.]', '[Full Name], analyst: [role and experience].'] }));
  main.push(...D.sidebarBlock({ heading: 'HOW WE STAFF THE WORK', lead: 'A small senior team that stays with you throughout. We draw on the other clusters as the question needs.', items: ['[x] partner days, [y] manager days, [z] analyst days', 'Fortnightly steering with your sponsor', 'One point of contact at Kayak'] }));
  main.push(D.pageBreak());

  main.push(D.H1('05  Fees, assumptions and next steps'));
  main.push(...D.dataTableBlock({ title: 'A fixed fee, agreed before work begins', subtitle: '₹ lakh, excluding GST and expenses', columns: ['Phase', 'Timing', 'Fee'], rows: [['[Diagnose]', '[Weeks 1 to 5]', '[00.0]'], ['[Decide]', '[Weeks 5 to 9]', '[00.0]'], ['[Deliver and sustain]', '[Weeks 9 to 12]', '[00.0]']], highlight: -1, total: ['Total professional fees', 'Excluding GST and expenses', '[00.0]'], source: 'Milestone billing: [x]% at kick-off, [y]% at the recommendation, [z]% at final read-out. Expenses at cost, capped at [x]% of fees. Payment within [30] days of invoice.' }));
  main.push(D.H2('Assumptions and dependencies'));
  main.push(...D.bullets(['[Access to the data and documents in the data request within [x] days of kick-off]', '[Availability of [n] interviewees in weeks 1 to 4]', '[A single client sponsor with authority to make decisions]', '[Timely review of drafts: comments within [5] working days]', '[Scope limited to the entities and markets named in this proposal]']));
  main.push(D.H2('Next steps'));
  main.push(...D.keyTakeawaysBlock({ items: ['[Proposal discussion with the sponsor, week 0]', '[Engagement letter, non-disclosure agreement and data-handling terms signed, week 1]', '[Data request issued and first interviews scheduled, week 2; kick-off in week 3]'] }));
  main.push(D.body('We would be glad to make the crossing with you.', { spacing: { before: 240 }, run: { font: D.SERIF, italics: true, size: 24, color: COL.deep } }));
  main.push(D.body('[Full Name], [Designation], Kayak Strategic Advisors', { run: { bold: true, color: COL.deep } }));

  const doc = D.makeDocument({ title: 'Kayak Strategic Advisors · Service proposal', subject: 'Proposal template', sections: [
    { properties: D.sectionProps(), ...emptyHF, children: D.coverBlock({ eyebrow: 'PROPOSAL · [MONTH YEAR]', title: '[Project name]', standfirst: 'A proposal for [Client name]: [one line on the question we will answer].', meta: 'Prepared for [Client name] · Confidential' }) },
    { properties: D.sectionProps({ pageNumberStart: 2 }), headers: { default: D.header('Proposal · [Project name]') }, footers: { default: D.footer(foot) }, children: main },
    { properties: D.sectionProps(), ...emptyHF, children: D.backCoverBlock() },
  ] });
  return D.write(doc, path.join(OUT, 'KSA_Service_Proposal.docx'));
}

// ============================================================ 2. Thought leadership report
async function report() {
  const foot = '[Report title] · Kayak Strategic Advisors · [Month YYYY]';
  const m = [];
  m.push(D.styled('Eyebrow', 'CONTENTS'));
  m.push(D.styled('DocTitle', '[Report title]'));
  m.push(D.styled('Standfirst', '[Subtitle: what the report shows and who it is for.]'));
  m.push(...contentsList([['01', 'Executive summary', '3'], ['02', '[Chapter one title]', '4'], ['03', '[Chapter two title]', '7'], ['04', 'What boards should do now', '8'], ['05', 'Methodology and sources', '9']]));
  m.push(D.styled('Eyebrow', 'EXHIBITS', { spacing: { before: 360, after: 80 } }));
  m.push(...D.bullets(['Exhibit 1  [Exhibit headline]', 'Exhibit 2  [Exhibit headline]', 'Exhibit 3  [Exhibit headline]']));
  m.push(D.pageBreak());

  m.push(D.H1('01  Executive summary'));
  m.push(D.styled('Standfirst', '[The argument of the report in three sentences: what is happening, why it matters and what to do about it.]'));
  m.push(D.body('[Body text in Archivo 10.5 on a 12 pt baseline. One idea per paragraph; short paragraphs; the finding first and the evidence after it. Numbers carry their unit the first time they appear: ₹1,240 crore, 18.6%, 4.2x.]'));
  m.push(D.body('[Second paragraph. Each chapter of the report answers one question for the reader, and the executive summary previews those answers in order.]'));
  m.push(...D.keyTakeawaysBlock({ items: ['[First finding, stated as a sentence the reader can repeat]', '[Second finding, with the number that proves it]', '[Third finding, and the decision it points to]'] }));
  m.push(D.H2('Who this report is for'));
  m.push(D.body('[Boards, promoters and investors who have to decide on [topic] in the next [twelve] months, and the executives who prepare those decisions.]'));
  m.push(D.pageBreak());

  m.push(...D.chapterOpenerBlock({ number: '02', title: '[Chapter one title]', standfirst: '[Two sentences that say what the chapter shows and why it matters to the reader.]' }));
  m.push(D.pageBreak());

  m.push(D.H2('[Section heading stated as a finding]'));
  m.push(D.body('[Body text. The chapter opens with the finding, then shows the evidence. Three or four paragraphs per spread; one exhibit per idea.]'));
  m.push(D.body('[Second paragraph. Where a number carries the argument, give it in the text and in the exhibit, with the same rounding.]'));
  m.push(...D.pullQuoteBlock());
  m.push(D.body('[Third paragraph. A pull quote is a line from the text, never a new claim; it sits between the paragraphs that contain it.]'));
  m.push(...D.sidebarBlock({ heading: '[SIDEBAR HEADING]', lead: '[A sidebar explains one thing the body cannot stop to explain: a definition, a method, a regulation.]', items: ['[What it is]', '[Why it matters here]', '[Where to read more]'] }));
  m.push(D.body('[Fourth paragraph, continuing the argument after the sidebar.]'));
  m.push(D.pageBreak());

  m.push(...D.exhibitFrameBlock({ number: 'EXHIBIT 1', headline: '[The finding, stated as a full sentence]', subtitle: '[Measure, unit, period]', height: mm(110) }));
  m.push(D.body('[One paragraph that reads the exhibit for the reader: what to look at, what it shows and what follows from it.]'));
  m.push(...D.calloutBlock({ label: 'HOW TO READ THIS EXHIBIT', text: '[Definitions, exclusions and the basis of any estimate, so a reader can check the figure.]' }));
  m.push(D.pageBreak());

  m.push(...D.chapterOpenerBlock({ number: '03', title: '[Chapter two title]', standfirst: '[Two sentences that say what the chapter shows and why it matters to the reader.]', figures: [['[x]%', '[Figure one, with unit]'], ['[₹x] cr', '[Figure two, with unit]'], ['[x] of 10', '[Figure three, with unit]']] }));
  m.push(D.H2('[Section heading stated as a finding]'));
  m.push(D.body('[Body text. The second chapter turns the finding into choices: what the options are and what each one costs.]'));
  m.push(...D.twoColumnBlock({ left: ['[Option one]', '[What it involves, what it costs and what it needs to succeed.]'], right: ['[Option two]', '[What it involves, what it costs and what it needs to succeed.]'] }));
  m.push(D.pageBreak());

  m.push(D.styled('Eyebrow', 'EXHIBIT 2'));
  m.push(...D.dataTableBlock({ title: '[EBITDA compounds at 20% a year as margin widens 300 bps]', subtitle: '[Listed auto-components maker], consolidated, ₹ crore; FY26E is a KSA estimate' }));
  m.push(D.body('[One paragraph that reads the table for the reader. Figures line up on the decimal, units live in the header and one row carries the message.]'));
  m.push(D.pageBreak());

  m.push(D.H1('04  What boards should do now'));
  m.push(D.styled('Standfirst', '[The actions that follow from the findings, in the order a board would take them.]'));
  m.push(...D.numbered([
    [new TextRun({ text: '[First action]. ', bold: true }), new TextRun('[What to do, who owns it and by when.]')],
    [new TextRun({ text: '[Second action]. ', bold: true }), new TextRun('[What to do, who owns it and by when.]')],
    [new TextRun({ text: '[Third action]. ', bold: true }), new TextRun('[What to do, who owns it and by when.]')],
  ]));
  m.push(D.H1('05  Methodology and sources'));
  m.push(D.body('[How the analysis was done: the data set, the period, the sample, the adjustments and the limits of the method. Every exhibit in this report carries its source; where KSA has transformed the data, the source line says "KSA analysis".]'));
  m.push(D.styled('Source', '1  [Source one, with date accessed].'));
  m.push(D.styled('Source', '2  [Source two, with date accessed].'));
  m.push(D.pageBreak());

  m.push(D.H1('About Kayak Strategic Advisors'));
  m.push(D.styled('Standfirst', 'Clear advice for consequential decisions: strategy, deals, regulation and resilience for India’s boards, promoters and investors.'));
  m.push(D.body('Kayak Strategic Advisors is a strategy and risk consulting boutique. A kayak is a disciplined, agile craft: it crosses changing water through balance, direction and steady navigation. That is how we help clients through complex business, regulatory, technology and risk conditions, working beside them like two kayakers moving as one.'));
  m.push(D.H3('Six clusters, one team'));
  m.push(...D.bullets(K.CLUSTERS.map((c) => c.name)));
  m.push(D.H3('Confluence'));
  m.push(D.body('Confluence is the Kayak monthly on strategy, risk and the decisions between them, free to clients and subscribers. kayaksa.com/confluence'));
  m.push(D.H3('Contact'));
  m.push(D.body('[Full Name], [Designation] · [name]@kayaksa.com · [+91 00000 00000] · www.kayaksa.com'));

  const doc = D.makeDocument({ title: 'Kayak Strategic Advisors · Thought leadership report', subject: 'Report template', sections: [
    { properties: D.sectionProps(), ...emptyHF, children: D.coverBlock({ eyebrow: '[SERIES NAME] · [MONTH YEAR]', title: '[Report title]', standfirst: '[Subtitle: what the report shows and who it is for.]', meta: 'Kayak Strategic Advisors · Insight' }) },
    { properties: D.sectionProps({ pageNumberStart: 2 }), headers: { default: D.header('[Report title]') }, footers: { default: D.footer(foot) }, children: m },
    { properties: D.sectionProps(), ...emptyHF, children: D.backCoverBlock() },
  ] });
  return D.write(doc, path.join(OUT, 'KSA_Thought_Leadership.docx'));
}

// ============================================================ 3. Report layouts (one block per page) + standalone block files
const BLOCK_DEFS = [
  { id: 'cover', name: 'Cover block', description: 'Full-page dark cover: pattern, logo, blade rule, eyebrow, title, standfirst and meta line.', tags: ['cover', 'title'], make: () => D.coverBlock(), fullPage: true },
  { id: 'chapter-opener', name: 'Chapter opener', description: 'Sea Mist band with the chapter number, blade rule, title, standfirst and three figures.', tags: ['chapter', 'opener', 'section'], make: () => D.chapterOpenerBlock() },
  { id: 'exhibit-frame', name: 'Exhibit frame', description: 'Exhibit number, headline, subtitle, a framed area for the chart and the source and note lines.', tags: ['exhibit', 'chart', 'figure', 'source'], make: () => D.exhibitFrameBlock() },
  { id: 'pull-quote', name: 'Pull quote', description: 'Serif italic quotation with blade quote marks and an attribution line.', tags: ['quote', 'pull quote'], make: () => D.pullQuoteBlock() },
  { id: 'sidebar-box', name: 'Sidebar box', description: 'Sea Mist box with a heading, a lead sentence and saffron-dash bullets.', tags: ['sidebar', 'box', 'aside'], make: () => D.sidebarBlock() },
  { id: 'two-column-text', name: 'Two-column text', description: 'Two text columns with headings, built as a borderless table so it inserts anywhere.', tags: ['columns', 'two column', 'text'], make: () => D.twoColumnBlock() },
  { id: 'callout', name: 'Callout', description: 'Haze-tinted note with a Burnished Gold label for caveats, definitions and warnings.', tags: ['callout', 'note', 'warning'], make: () => D.calloutBlock() },
  { id: 'key-takeaways', name: 'Key takeaways box', description: 'Sea Mist box with three numbered takeaways.', tags: ['takeaways', 'summary', 'box'], make: () => D.keyTakeawaysBlock() },
  { id: 'data-table', name: 'Data table', description: 'Financial table with Deep Current header rule, Fog hairlines, one Haze highlight row, a totals row and a source line.', tags: ['table', 'data', 'financials'], make: () => D.dataTableBlock() },
  { id: 'back-cover', name: 'Back cover', description: 'Full-page dark back cover with identifier, one-line description, contact and logo.', tags: ['back cover', 'contact'], make: () => D.backCoverBlock(), fullPage: true },
];

async function layouts() {
  const sections = [];
  const index = {};
  BLOCK_DEFS.forEach((b, i) => {
    index[`report.${b.id}`] = { id: `report.${b.id}`, page: i + 1, name: b.name, category: 'report-layouts', subcategory: 'Report layouts', description: b.description, tags: b.tags, file: `assets/layouts/word/report.${b.id}.xml`, preview: `assets/templates/previews/report.${b.id}.png`, fullPage: !!b.fullPage };
    const children = b.fullPage ? b.make() : [D.styled('Eyebrow', `REPORT LAYOUT · ${b.name.toUpperCase()}`, { run: { color: COL.slate }, spacing: { after: 240 } }), ...b.make()];
    sections.push(b.fullPage
      ? { properties: D.sectionProps(), ...emptyHF, children }
      : { properties: D.sectionProps(), headers: { default: D.header('Report layouts') }, footers: { default: D.footer('KSA report layouts · insert from the KSA Toolbar') }, children });
  });
  const doc = D.makeDocument({ title: 'Kayak Strategic Advisors · Report layouts', subject: 'Report layout blocks', sections });
  const out = await D.write(doc, path.join(OUT, 'KSA_Report_Layouts.docx'));
  // standalone block documents for make_ooxml_blocks.py
  for (const b of BLOCK_DEFS) {
    const d = D.makeDocument({ title: b.name, subject: 'KSA report layout block', sections: [{ properties: D.sectionProps(), ...emptyHF, children: b.make() }] });
    await D.write(d, path.join(BLOCKS, `report.${b.id}.docx`));
  }
  fs.writeFileSync(path.join(__dirname, 'report-layouts-index.json'), JSON.stringify({ file: 'assets/templates/KSA_Report_Layouts.docx', blocks: Object.values(index) }, null, 2) + '\n');
  return out;
}

(async () => {
  console.log('wrote', await proposal());
  console.log('wrote', await report());
  console.log('wrote', await layouts(), `+ ${BLOCK_DEFS.length} block files in ${BLOCKS}`);
})().catch((e) => { console.error(e); process.exit(1); });
