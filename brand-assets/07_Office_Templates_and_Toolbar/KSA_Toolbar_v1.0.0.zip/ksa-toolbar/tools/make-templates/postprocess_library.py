#!/usr/bin/env python3
"""Post-process KSA_Slide_Library.pptx after pptxgenjs has written it.

1. Groups every non-placeholder shape on diagram, infographic and shape slides into one
   <p:grpSp>, so the asset moves and scales as a single editable object.
2. Makes the waterfall's base series invisible (noFill, no labels).
3. Names each slide (<p:cSld name="...">) after its library id and records the numeric
   slide id from presentation.xml in slide-library-index.json as "sourceSlideId".

Usage: python3 postprocess_library.py <library.pptx> <slide-library-index.json>
"""
import json
import re
import shutil
import sys
import tempfile
import zipfile
from pathlib import Path

from lxml import etree

NS = {
    'p': 'http://schemas.openxmlformats.org/presentationml/2006/main',
    'a': 'http://schemas.openxmlformats.org/drawingml/2006/main',
    'r': 'http://schemas.openxmlformats.org/officeDocument/2006/relationships',
    'c': 'http://schemas.openxmlformats.org/drawingml/2006/chart',
}
P = '{%s}' % NS['p']
A = '{%s}' % NS['a']
C = '{%s}' % NS['c']


def xfrm_of(el):
    """Return (x, y, cx, cy) of a shape element, or None."""
    sppr = el.find('p:spPr', NS)
    if sppr is None:
        return None
    xf = sppr.find('a:xfrm', NS)
    if xf is None:
        return None
    off, ext = xf.find('a:off', NS), xf.find('a:ext', NS)
    return int(off.get('x')), int(off.get('y')), int(ext.get('cx')), int(ext.get('cy'))


def group_slide(tree, name):
    root = tree.getroot()
    sp_tree = root.find('.//p:cSld/p:spTree', NS)
    members = []
    for el in list(sp_tree):
        if el.tag not in (P + 'sp', P + 'pic', P + 'cxnSp'):
            continue
        nv = el.find('.//p:nvPr', NS)
        if nv is not None and nv.find('p:ph', NS) is not None:
            continue  # placeholder: leave on the slide
        if xfrm_of(el) is None:
            continue
        members.append(el)
    if len(members) < 2:
        return False
    xs = [xfrm_of(m) for m in members]
    x0 = min(x for x, y, cx, cy in xs)
    y0 = min(y for x, y, cx, cy in xs)
    x1 = max(x + cx for x, y, cx, cy in xs)
    y1 = max(y + cy for x, y, cx, cy in xs)
    max_id = max([int(e.get('id')) for e in root.iter(P + 'cNvPr')] + [1])
    grp = etree.SubElement(sp_tree, P + 'grpSp')
    nv = etree.SubElement(grp, P + 'nvGrpSpPr')
    cnv = etree.SubElement(nv, P + 'cNvPr', id=str(max_id + 1), name=name)
    etree.SubElement(nv, P + 'cNvGrpSpPr')
    etree.SubElement(nv, P + 'nvPr')
    gpr = etree.SubElement(grp, P + 'grpSpPr')
    xf = etree.SubElement(gpr, A + 'xfrm')
    etree.SubElement(xf, A + 'off', x=str(x0), y=str(y0))
    etree.SubElement(xf, A + 'ext', cx=str(x1 - x0), cy=str(y1 - y0))
    etree.SubElement(xf, A + 'chOff', x=str(x0), y=str(y0))
    etree.SubElement(xf, A + 'chExt', cx=str(x1 - x0), cy=str(y1 - y0))
    # move members into the group, keeping their z-order; the group sits where the first member was
    first_index = list(sp_tree).index(members[0])
    for m in members:
        sp_tree.remove(m)
        grp.append(m)
    sp_tree.remove(grp)
    sp_tree.insert(first_index, grp)
    return True


def hide_waterfall_base(chart_xml):
    tree = etree.fromstring(chart_xml)
    for ser in tree.iter(C + 'ser'):
        idx = ser.find('c:idx', NS)
        if idx is None or idx.get('val') != '0':
            continue
        sppr = ser.find('c:spPr', NS)
        if sppr is None:
            sppr = etree.Element(C + 'spPr')
            tx = ser.find('c:tx', NS)
            (tx if tx is not None else idx).addnext(sppr)
        for child in list(sppr):
            sppr.remove(child)
        etree.SubElement(sppr, A + 'noFill')
        ln = etree.SubElement(sppr, A + 'ln')
        etree.SubElement(ln, A + 'noFill')
        dl = ser.find('c:dLbls', NS)
        if dl is not None:
            for child in list(dl):
                dl.remove(child)
            etree.SubElement(dl, C + 'delete', val='1')
    return etree.tostring(tree, xml_declaration=True, encoding='UTF-8', standalone=True)


def main(pptx, index_path):
    index = json.loads(Path(index_path).read_text())
    if 'slides' in index:  # already in list form (re-run): rebuild the id -> meta map
        index = {sl['id']: {'index': sl['slideIndex'], 'name': sl['name'], 'category': sl['category'], 'subcategory': sl['subcategory'], 'description': sl['description'], 'tags': sl['tags'], 'group': sl.get('grouped', False)} for sl in index['slides']}
    by_slide = {v['index']: (k, v) for k, v in index.items()}
    tmp = Path(tempfile.mkdtemp())
    with zipfile.ZipFile(pptx) as z:
        z.extractall(tmp)
    # slide ids from presentation.xml, in order
    pres = etree.parse(str(tmp / 'ppt/presentation.xml'))
    rels = etree.parse(str(tmp / 'ppt/_rels/presentation.xml.rels'))
    rid_to_target = {r.get('Id'): r.get('Target') for r in rels.getroot()}
    sld_ids = pres.getroot().find('p:sldIdLst', NS)
    order = []
    for sld in sld_ids:
        rid = sld.get('{%s}id' % NS['r'])
        order.append((int(sld.get('id')), rid_to_target[rid]))
    grouped = 0
    for n, (sid, target) in enumerate(order, start=1):
        if n not in by_slide:
            continue
        lib_id, meta = by_slide[n]
        meta['sourceSlideId'] = str(sid)
        slide_path = tmp / 'ppt' / target
        tree = etree.parse(str(slide_path))
        csld = tree.getroot().find('p:cSld', NS)
        csld.set('name', lib_id)
        if meta.get('group'):
            if group_slide(tree, meta['name']):
                grouped += 1
        if lib_id == 'chart.waterfall':
            srels = etree.parse(str(tmp / 'ppt/slides/_rels' / (Path(target).name + '.rels')))
            for r in srels.getroot():
                if r.get('Type', '').endswith('/chart'):
                    t = r.get('Target')
                    cpath = (tmp / 'ppt' / t.lstrip('/').removeprefix('ppt/')) if t.startswith('/') else (slide_path.parent / t).resolve()
                    cpath.write_bytes(hide_waterfall_base(cpath.read_bytes()))
        tree.write(str(slide_path), xml_declaration=True, encoding='UTF-8', standalone=True)
    slides = []
    for lib_id, v in index.items():
        slides.append({'id': lib_id, 'slideIndex': v['index'], 'sourceSlideIds': [v['sourceSlideId']], 'name': v['name'],
                       'category': v['category'], 'subcategory': v['subcategory'], 'description': v['description'],
                       'tags': v['tags'], 'preview': f'assets/templates/previews/{lib_id}.png', 'grouped': bool(v.get('group'))})
    Path(index_path).write_text(json.dumps({'file': 'assets/templates/KSA_Slide_Library.pptx', 'slides': slides}, indent=2) + '\n')
    out = Path(pptx)
    out.unlink()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as z:
        ct = tmp / '[Content_Types].xml'
        z.write(ct, '[Content_Types].xml')
        for f in sorted(tmp.rglob('*')):
            if f.is_file() and f != ct:
                z.write(f, f.relative_to(tmp).as_posix())
    shutil.rmtree(tmp)
    print(f'post-processed {out.name}: {len(order)} slides, {grouped} grouped')


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
