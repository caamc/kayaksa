#!/usr/bin/env python3
"""build-library.py: builds the KSA Toolbar asset folders and writes assets/library.json.

Usage
    python3 tools/build-library.py [--source S] [--skip-raster] [--only logo,icons,...]

What it does (see tools/README.md for the full story)
    assets/logo             PNG (1024 px) + preview (240 px) for every logo SVG already in the folder
    assets/icons            48 KSA icons: svg/<variant>, png/<variant> (256 px), preview (96 px)
    assets/industry-icons   45 industries x 48 icons: <slug>/svg/{duotone,line}, <slug>/preview (96 px)
    assets/patterns         11 patterns x 6 colourways: tile svg, 1920x1080 png, preview (320 px)
    assets/shapes           editable brand shapes generated here as SVG + preview (320 px)
    assets/effects          preset json, blade crop mask, previews
    charts / diagrams / infographics / layouts / report-layouts / templates
                            catalogue entries, merged from the templates owner's index files when present
    assets/library.json     the catalogue consumed by src/modules/library.js

Rasterising is done by tools/rasterise.js (sharp) in one batch at the end.
"""
import argparse
import csv
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
ASSETS = ROOT / "assets"
DEFAULT_SOURCE = ROOT.parent.parent  # the scratchpad "S" in the brief

# ---------------------------------------------------------------- brand tokens
C = {
    "deep": "#0E2F3C", "water": "#17807E", "saffron": "#EE9B1E", "mist": "#EEF4F1", "slate": "#3E5563",
    "fog": "#D4DEE2", "river": "#8B9A9C", "kelp": "#4B7A4E", "clay": "#B4472F", "tide": "#2D6A9F",
    "gold": "#9C630E", "plum": "#5E4B78", "sand": "#D8C5A1", "shallows": "#5DB2AB", "spray": "#CDE8E3",
    "lagoon": "#0B5654", "undertow": "#1F4B5F", "haze": "#FBEBCD", "dawn": "#F5C46D", "white": "#FFFFFF",
    "lichen": "#9AAD5A", "coral": "#E2735C",
}
FONT = "Archivo, Arial, sans-serif"
SERIF = "'Source Serif 4', Georgia, serif"

CLUSTERS = [
    (1, "Strategy, Deal & Transactions", "Strategy & Deals", C["water"], "strategy"),
    (2, "Tax & Regulatory", "Tax & Regulatory", C["gold"], "regulatory"),
    (3, "Crisis & Resilience", "Crisis & Resilience", C["slate"], "risk"),
    (4, "Technology & AI", "Technology & AI", C["tide"], "technology"),
    (5, "Managed Services", "Managed Services", C["kelp"], "briefcase"),
    (6, "International Desk", "International Desk", C["plum"], "globe"),
]

CATEGORIES = [
    ("logo", "Logo & colour", "logo", "The KAYAK logo, identifier, monogram and app icon in every approved version."),
    ("colours", "Colours", "palette", "The KSA palette, service cluster colours and the Office theme."),
    ("icons", "Icons", "icons", "48 KSA service, advisory, business and interface icons in six versions."),
    ("industry-icons", "Industry icons", "industry", "2,160 icons across the 45 IBEF industries: value chain, services, advisory and digital."),
    ("shapes", "Shapes", "shapes", "Blades, chevrons, deltas, rules, badges, stamps and marks as editable vectors."),
    ("infographics", "Infographics", "infographic", "Editable infographic blocks: big numbers, timelines, comparisons and scorecards."),
    ("diagrams", "Smart diagrams", "diagram", "Editable grouped-shape diagrams: processes, cycles, matrices, funnels and maps."),
    ("charts", "Charts", "chart", "Native, editable charts styled to the KSA data rules."),
    ("patterns", "Patterns", "pattern", "Eleven seamless brand patterns in six colourways, as tiles and full HD backgrounds."),
    ("effects", "Effects", "effects", "One-click KSA styling for the selection: fills, lines, type, shadows and the theme."),
    ("layouts", "Layouts", "layout", "Slide layouts for decks, from cover to closing."),
    ("report-layouts", "Report layouts", "report", "Word page layouts: covers, chapter openers, exhibits, tables and back pages."),
    ("templates", "Templates", "template", "The corporate presentation, service proposal, thought-leadership report, slide library and more."),
    ("assistant", "KSA Assistant", "assistant", "Ask for charts, exhibit slides, summaries and tables built from your data."),
]
CAT_ORDER = {c[0]: i for i, c in enumerate(CATEGORIES)}
ALL_HOSTS = ["powerpoint", "word", "excel", "outlook"]
DOC_HOSTS = ["powerpoint", "word", "excel"]
SVG_INSERT = {"powerpoint": "svg", "word": "svg", "excel": "svg", "outlook": "png"}
PNG_INSERT = {"powerpoint": "png", "word": "png", "excel": "png", "outlook": "png"}

WARNINGS = []
RASTER_JOBS = []
ITEMS = []


def warn(msg):
    WARNINGS.append(msg)
    print("WARNING: " + msg)


def rel(p: Path) -> str:
    return p.resolve().relative_to(ROOT.resolve()).as_posix()


def raster(src: Path, out: Path, width: int, **kw):
    job = {"src": str(src.resolve()), "out": str(out.resolve()), "width": width}
    job.update(kw)
    RASTER_JOBS.append(job)


def copy(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if not dst.exists() or src.stat().st_mtime > dst.stat().st_mtime or src.stat().st_size != dst.stat().st_size:
        shutil.copy2(src, dst)


SKIP_RASTER = False


def reset_dir(p: Path):
    """Empties a generated folder. Preview folders are kept when --skip-raster is given, since they would not be rebuilt."""
    if p.exists() and not (SKIP_RASTER and p.name == "preview"):
        shutil.rmtree(p)
    p.mkdir(parents=True, exist_ok=True)


def title_words(slug: str) -> str:
    return slug.replace("-", " ").replace("_", " ").strip().capitalize()


def tags_from(*parts, limit=8):
    seen, out = set(), []
    for part in parts:
        if not part:
            continue
        for w in re.split(r"[\s,/&·()+-]+", str(part).lower()):
            w = w.strip()
            if len(w) > 1 and w not in seen and w not in ("and", "the", "of", "for", "with", "ksa"):
                seen.add(w)
                out.append(w)
    return out[:limit]


def add_item(**it):
    it.setdefault("hosts", ALL_HOSTS)
    it.setdefault("editable", False)
    ITEMS.append(it)
    return it


def svg_size(text: str):
    m = re.search(r'viewBox="([^"]+)"', text)
    if m:
        p = m.group(1).split()
        if len(p) == 4:
            return float(p[2]), float(p[3])
    return 100.0, 100.0


# ---------------------------------------------------------------- 1. logo
LOGO_SETS = [
    ("Full logo", "KSA_Logo_Full", [("FullColour", "Full colour"), ("Reversed", "Reversed"), ("Mono-DeepCurrent", "Mono Deep Current"), ("Mono-White", "Mono white"), ("Mono-Black", "Mono black")]),
    ("Wordmark", "KSA_Wordmark", [("FullColour", "Full colour"), ("Reversed", "Reversed"), ("Mono-DeepCurrent", "Mono Deep Current"), ("Mono-White", "Mono white"), ("Mono-Black", "Mono black")]),
    ("Identifier", "KSA_Identifier", [("FullColour", "Full colour"), ("Reversed", "Reversed"), ("Mono-DeepCurrent", "Mono Deep Current"), ("Mono-White", "Mono white"), ("Mono-Black", "Mono black")]),
    ("Monogram", "KSA_Monogram", [("FullColour", "Full colour"), ("Reversed", "Reversed"), ("Mono-DeepCurrent", "Mono Deep Current"), ("Tile_DeepCurrent_Rounded", "Tile, rounded")]),
    ("App icon", "KSA_AppIcon", [("DeepCurrent", "Deep Current"), ("DeepCurrent_Rounded", "Deep Current, rounded"), ("White", "White")]),
]


def build_logo():
    d = ASSETS / "logo"
    (d / "png").mkdir(parents=True, exist_ok=True)
    (d / "preview").mkdir(parents=True, exist_ok=True)
    for group, stem, variants in LOGO_SETS:
        for suffix, label in variants:
            svg = d / f"{stem}_{suffix}.svg"
            if not svg.exists():
                warn(f"logo missing: {svg.name}")
                continue
            w, h = svg_size(svg.read_text())
            png = d / "png" / f"{stem}_{suffix}.png"
            prev = d / "preview" / f"{stem}_{suffix}.png"
            raster(svg, png, 1024)
            raster(svg, prev, 240)
            dark = suffix in ("Reversed", "Mono-White", "White")
            name = f"{group} · {label}"
            slug = f"{group.lower().replace(' ', '-')}.{suffix.lower().replace('_', '-')}"
            it = add_item(
                id=f"logo.{slug}", category="logo", subcategory=group, name=name,
                description=f"{group} in the {label.lower()} version." + (" Use on Deep Current or dark photography." if dark else ""),
                tags=tags_from(group, label, "logo", "kayak"),
                preview=rel(prev),
                formats={"svg": rel(svg), "png": rel(png)},
                insert=dict(SVG_INSERT), hosts=ALL_HOSTS,
                size={"w": round(w), "h": round(h)}, editable=False,
            )
            if dark:
                it["dark"] = True
            if suffix == "FullColour" and group in ("Full logo", "Identifier"):
                it["featured"] = True


# ---------------------------------------------------------------- 2. KSA icons
ICON_VARIANTS = [("duotone", "Duotone"), ("duotone-reversed", "Duotone_Reversed"), ("line-deep", "Line_DeepCurrent"), ("line-black", "Line_Black"), ("line-white", "Line_White"), ("badge", "Badge")]
ICON_GROUPS = [
    ("Services", ["strategy", "transactions", "risk", "investigations", "brand-protection", "intellectual-property", "technology", "data", "human-resources", "compliance", "tax", "finance"]),
    ("Advisory", ["due-diligence", "governance", "regulatory", "cybersecurity", "esg", "analytics", "growth", "target", "navigation", "partnership", "network", "globe"]),
    ("Business", ["report", "contract", "calendar", "timeline", "mail", "mobile", "location", "website", "chat", "user", "presentation", "briefcase"]),
    ("Interface", ["arrow-right", "external-link", "chevron-right", "check", "close", "plus", "menu", "search", "download", "share", "filters", "info"]),
]
ICON_SYNONYMS = {
    "strategy": ["compass", "direction"], "transactions": ["deal", "m&a", "handshake"], "risk": ["warning", "alert"],
    "investigations": ["magnifier", "evidence"], "brand-protection": ["shield", "trademark"], "intellectual-property": ["ip", "patent"],
    "technology": ["chip", "ai"], "data": ["database", "analytics"], "human-resources": ["people", "talent", "hr"],
    "compliance": ["tick", "checklist"], "tax": ["rupee", "levy"], "finance": ["money", "capital"],
    "due-diligence": ["review", "audit"], "governance": ["board", "building"], "regulatory": ["scales", "law"],
    "cybersecurity": ["lock", "security"], "esg": ["leaf", "sustainability"], "analytics": ["chart", "insight"],
    "growth": ["arrow", "trend"], "target": ["goal", "bullseye"], "navigation": ["route", "map"], "partnership": ["alliance", "jv"],
    "network": ["nodes", "ecosystem"], "globe": ["world", "international"], "report": ["document", "paper"],
    "contract": ["agreement", "signature"], "calendar": ["date", "schedule"], "timeline": ["milestones", "plan"],
    "mail": ["email", "envelope"], "mobile": ["phone"], "location": ["pin", "office"], "website": ["web", "browser"],
    "chat": ["message", "conversation"], "user": ["person", "profile"], "presentation": ["slides", "deck"],
    "briefcase": ["services", "work"], "arrow-right": ["next"], "external-link": ["open"], "chevron-right": ["more"],
    "check": ["done", "yes"], "close": ["cancel", "x"], "plus": ["add", "new"], "menu": ["hamburger"], "search": ["find"],
    "download": ["save"], "share": ["send"], "filters": ["sliders"], "info": ["help"],
}


def build_icons(source: Path):
    src = source / "icons/out/KSA_Monogram_and_Icons/02_Icons"
    if not src.exists():
        warn(f"KSA icons source not found: {src}")
        return
    d = ASSETS / "icons"
    for key, folder in ICON_VARIANTS:
        reset_dir(d / "svg" / key)
        reset_dir(d / "png" / key)
        for f in sorted((src / "SVG" / folder).glob("ksa-icon-*.svg")):
            copy(f, d / "svg" / key / f.name)
        for f in sorted((src / "PNG_256px" / folder).glob("ksa-icon-*.png")):
            copy(f, d / "png" / key / f.name)
    reset_dir(d / "preview")
    group_of = {n: g for g, names in ICON_GROUPS for n in names}
    for f in sorted((d / "svg" / "duotone").glob("ksa-icon-*.svg")):
        name = f.stem.replace("ksa-icon-", "")
        group = group_of.get(name, "Other")
        if group == "Other":
            warn(f"icon {name} is not in any group")
        prev = d / "preview" / f"{name}.png"
        raster(f, prev, 96)
        variants = {key: rel(d / "svg" / key / f.name) for key, _ in ICON_VARIANTS if (d / "svg" / key / f.name).exists()}
        add_item(
            id=f"icon.{name}", category="icons", subcategory=group, name=title_words(name),
            tags=tags_from(name, group, *ICON_SYNONYMS.get(name, [])),
            preview=rel(prev),
            formats={"svg": variants["duotone"], "png": rel(d / "png" / "duotone" / f"{f.stem}.png"), "svgVariants": variants},
            defaultVariant="duotone",
            insert=dict(SVG_INSERT), hosts=ALL_HOSTS, size={"w": 96, "h": 96}, editable=True,
        )


# ---------------------------------------------------------------- 3. industry icons
def build_industry(source: Path):
    src = source / "ind/out/KSA_Industry_Icons"
    index = src / "KSA_Industry_Icon_Index.csv"
    if not index.exists():
        warn(f"industry icon index not found: {index}")
        return
    rows = list(csv.DictReader(index.open(encoding="utf-8")))
    folders = {}
    for p in sorted(src.iterdir()):
        if p.is_dir() and re.match(r"^\d\d_", p.name):
            folders[re.sub(r"[^a-z0-9]", "", p.name[3:].lower())] = p
    d = ASSETS / "industry-icons"
    industries = {}
    for r in rows:
        ind = r["Industry"].strip()
        key = r["Icon key"].strip()
        fname = r["File name (add .svg / .png)"].strip()
        label = r["Label"].strip()
        row_name = r["Row"].strip()
        if ind not in industries:
            slug = fname[4:-(len(key) + 1)] if fname.startswith("ksa-") and fname.endswith("-" + key) else re.sub(r"[^a-z0-9]+", "-", ind.lower()).strip("-")
            fkey = re.sub(r"[^a-z0-9]", "", ind.lower().replace("&", "and"))
            folder = (folders.get(fkey) or folders.get(re.sub(r"[^a-z0-9]", "", ind.lower()))
                      or next((p for p in folders.values() if (p / "SVG" / "Duotone" / f"{fname}.svg").exists()), None))
            if folder is None:
                warn(f"no folder for industry {ind}")
            industries[ind] = {"slug": slug, "folder": folder, "done": False}
        info = industries[ind]
        if info["folder"] is None:
            continue
        if not info["done"]:
            reset_dir(d / info["slug"] / "svg" / "duotone")
            reset_dir(d / info["slug"] / "svg" / "line")
            reset_dir(d / info["slug"] / "preview")
            info["done"] = True
        duo_src = info["folder"] / "SVG" / "Duotone" / f"{fname}.svg"
        line_src = info["folder"] / "SVG" / "Line_DeepCurrent" / f"{fname}.svg"
        if not duo_src.exists() or not line_src.exists():
            warn(f"industry icon missing: {fname}")
            continue
        duo = d / info["slug"] / "svg" / "duotone" / f"{fname}.svg"
        line = d / info["slug"] / "svg" / "line" / f"{fname}.svg"
        copy(duo_src, duo)
        copy(line_src, line)
        prev = d / info["slug"] / "preview" / f"{key}.png"
        raster(duo, prev, 96)
        add_item(
            id=f"ind.{info['slug']}.{key}", category="industry-icons", subcategory=ind, name=label,
            tags=tags_from(ind, row_name, label, limit=7),
            preview=rel(prev),
            formats={"svg": rel(duo), "svgVariants": {"duotone": rel(duo), "line": rel(line)}},
            defaultVariant="duotone",
            insert=dict(SVG_INSERT), hosts=ALL_HOSTS, size={"w": 96, "h": 96}, editable=True,
        )


# ---------------------------------------------------------------- 4. patterns
PATTERN_INFO = {
    "01": ("confluence", "Confluence", "Geometric", "The identifier's two blades repeated in a half-drop; teal and saffron meet in every unit."),
    "02": ("paddle-rhythm", "Paddle rhythm", "Geometric", "Left and right blades stack in a herringbone, a kinetic supergraphic for covers and banners."),
    "03": ("delta", "Delta", "Geometric", "The A's trapezoid, upright and inverted, interlocks like a river delta."),
    "04": ("monogram-canvas", "Monogram canvas", "Geometric", "The monogram and identifier in a heritage half-drop, for premium moments."),
    "05": ("wake-lines", "Wake lines", "Line", "Hairlines on the blade angle; the quietest pattern for backgrounds and overlays."),
    "06": ("chevron-wake", "Chevron wake", "Line", "Two strokes converge but never touch; ideal for section openers and bands."),
    "07": ("k-lattice", "K-lattice", "Line", "A lattice on the angle of the K's arms with saffron nodes at points of decision."),
    "08": ("pinstripe", "Pinstripe", "Line", "Stem and split as a tailored pinstripe for letterheads, folders and slide margins."),
    "09": ("current", "Current", "Atmospheric", "Flow lines traced from the monogram's S; calm movement for large backgrounds."),
    "10": ("soundings", "Soundings", "Atmospheric", "A field of depth marks with one beacon; works behind data and dashboards."),
    "11": ("chart-contours", "Chart contours", "Atmospheric", "Depth contours from a navigation chart; the signature backdrop for reports and keynotes."),
}
THEMES = [("brand-dark", "brand dark", "Display strength on Deep Current. Covers and supergraphics only."),
          ("brand-light", "brand light", "Display strength on Sea Mist. Covers and supergraphics only."),
          ("accent-dark", "accent dark", "Accent strength on Deep Current with one saffron unit. Section openers and banners."),
          ("accent-light", "accent light", "Accent strength on Sea Mist with one saffron unit. Section openers and banners."),
          ("tonal-dark", "tonal dark", "Tone on tone at 6 to 16 percent. Backgrounds behind UI, charts and type."),
          ("tonal-light", "tonal light", "Tone on tone at 6 to 16 percent. Backgrounds behind UI, charts and type.")]


def build_patterns(source: Path):
    src = source / "vg/out/KSA_Brand_Patterns"
    if not src.exists():
        warn(f"patterns source not found: {src}")
        return
    d = ASSETS / "patterns"
    for folder in sorted(src.iterdir()):
        m = re.match(r"^(\d\d)_(.+)$", folder.name)
        if not m or not folder.is_dir():
            continue
        num, raw = m.groups()
        slug, pname, family, desc = PATTERN_INFO.get(num, (raw.lower().replace("_", "-"), raw.replace("_", " "), "Pattern", ""))
        if SKIP_RASTER:
            (d / slug).mkdir(parents=True, exist_ok=True)  # keep the previews we are not regenerating
        else:
            reset_dir(d / slug)
        for theme, tlabel, tdesc in THEMES:
            base = f"KSA_Pattern_{num}_{raw}_{theme}"
            tile_src = folder / f"{base}_tile.svg"
            png_src = folder / f"{base}_1920x1080.png"
            if not tile_src.exists() or not png_src.exists():
                warn(f"pattern files missing for {base}")
                continue
            tile = d / slug / f"{slug}_{theme}_tile.svg"
            png = d / slug / f"{slug}_{theme}_1920x1080.png"
            prev = d / slug / f"{slug}_{theme}_preview.png"
            copy(tile_src, tile)
            copy(png_src, png)
            raster(png, prev, 320)
            it = add_item(
                id=f"pattern.{slug}.{theme}", category="patterns", subcategory=pname, name=f"{pname} · {tlabel}",
                description=f"{desc} {tdesc}",
                tags=tags_from(pname, family, theme, "background", "pattern", limit=8),
                preview=rel(prev),
                formats={"png": rel(png), "svg": rel(tile)},
                insert=dict(PNG_INSERT), hosts=ALL_HOSTS, size={"w": 1920, "h": 1080}, editable=False,
                note="Inserts the full HD background as a picture. The SVG download is the seamless tile.",
            )
            if theme.endswith("-dark"):
                it["dark"] = True
            if slug == "chart-contours" and theme == "brand-dark":
                it["featured"] = True


# ---------------------------------------------------------------- 5. shapes (generated)
def svg_doc(w, h, body, title=""):
    t = f"<title>{title}</title>" if title else ""
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 {w} {h}" width="{w}" height="{h}">{t}{body}</svg>')


def icon_body(source: Path, name: str, colour: str) -> str:
    """Inner markup of a KSA icon (Line_White variant recoloured), for embedding in badges."""
    f = ASSETS / "icons" / "svg" / "line-white" / f"ksa-icon-{name}.svg"
    if not f.exists():
        f = source / "icons/out/KSA_Monogram_and_Icons/02_Icons/SVG/Line_White" / f"ksa-icon-{name}.svg"
    if not f.exists():
        return ""
    text = f.read_text()
    inner = re.sub(r"^.*?<svg[^>]*>", "", text, flags=re.S)
    inner = re.sub(r"</svg>\s*$", "", inner, flags=re.S)
    inner = inner.replace("#FFFFFF", colour).replace("#ffffff", colour)
    return (f'<g stroke-width="2" stroke-linecap="butt" stroke-linejoin="miter" stroke-miterlimit="4">{inner}</g>')


def shape_defs(source: Path):
    """Returns a list of (id, subcategory, name, description, tags, svg_text, w, h)."""
    S = []
    deep, water, saf, slate, fog, mist, white = C["deep"], C["water"], C["saffron"], C["slate"], C["fog"], C["mist"], C["white"]
    text_attr = f'font-family="{FONT}"'

    # Identifier parts
    S.append(("blade-left", "Identifier parts", "Left blade", "The identifier's left blade in Open Water. The blades meet at the split; keep the 4-unit gap.",
              ["blade", "identifier", "open water", "teal"], svg_doc(44, 60, f'<path fill="{water}" d="M0 0 L30 0 L44 26.25 L44 59.3 Z"/>', "Left blade"), 44, 60))
    S.append(("blade-right", "Identifier parts", "Right blade", "The identifier's right blade in Beacon Saffron. Mirror of the left blade.",
              ["blade", "identifier", "saffron"], svg_doc(44, 60, f'<path fill="{saf}" d="M0 0 L30 0 L44 26.25 L44 59.3 Z" transform="translate(44 0) scale(-1 1)"/>', "Right blade"), 44, 60))
    S.append(("blades", "Identifier parts", "Blade pair", "Both blades with the split between them, without the stem.",
              ["blades", "identifier", "split"], svg_doc(92, 60, f'<path fill="{water}" d="M0 0 L30 0 L44 26.25 L44 59.3 Z"/><path fill="{saf}" d="M92 0 L62 0 L48 26.25 L48 59.3 Z"/>', "Blade pair"), 92, 60))
    S.append(("stem", "Identifier parts", "Stem", "The identifier's stem in Deep Current: the V that carries the blades.",
              ["stem", "identifier", "deep current"], svg_doc(28, 49, f'<path fill="{deep}" d="M0 0 L14 19 L28 0 L28 49 L0 49 Z"/>', "Stem"), 28, 49))
    S.append(("delta", "Identifier parts", "A trapezoid (delta)", "The A's trapezoid from the monogram. Stack upright and inverted for the Delta pattern.",
              ["delta", "trapezoid", "monogram", "triangle"], svg_doc(90, 100, f'<path fill="{deep}" d="M0 100 L31 0 L59 0 L90 100 Z"/>', "A trapezoid"), 90, 100))
    S.append(("chevron-wake", "Identifier parts", "Chevron wake", "Two strokes converge but never touch: the split at the heart of the identifier, as a line device.",
              ["chevron", "wake", "lines", "split"], svg_doc(160, 100, f'<g fill="none" stroke-width="6"><path stroke="{water}" d="M4 4 L72 92"/><path stroke="{saf}" d="M156 4 L88 92"/></g>', "Chevron wake"), 160, 100))

    # Rules and dividers
    S.append(("split-rule", "Rules & dividers", "Split rule", "A hairline rule broken by the identifier's split: line, gap, line, with a saffron beacon at the break.",
              ["rule", "divider", "line", "split"], svg_doc(640, 12, f'<rect x="0" y="5" width="306" height="2" fill="{deep}"/><rect x="334" y="5" width="306" height="2" fill="{deep}"/><rect x="314" y="0" width="12" height="12" fill="{saf}"/>', "Split rule"), 640, 12))
    S.append(("blade-rule", "Rules & dividers", "Blade rule", "A heavy rule that ends on the blade angle, Open Water with a saffron tip.",
              ["rule", "divider", "blade", "heading"], svg_doc(640, 16, f'<path fill="{water}" d="M0 0 H600 L608 16 H0 Z"/><path fill="{saf}" d="M616 0 H632 L640 16 H624 Z"/>', "Blade rule"), 640, 16))
    S.append(("confluence-divider", "Rules & dividers", "Confluence divider", "A section divider band: the two blades meet above a Deep Current rule.",
              ["divider", "section", "confluence", "band"], svg_doc(640, 64, f'<rect x="0" y="60" width="640" height="2" fill="{deep}"/><path fill="{water}" d="M276 0 L296 0 L318 44 L318 56 Z"/><path fill="{saf}" d="M364 0 L344 0 L322 44 L322 56 Z"/>', "Confluence divider"), 640, 64))
    S.append(("route-line", "Rules & dividers", "Route line", "A dashed Storm Slate route with waypoint diamonds and a saffron destination. Use for journeys and roadmaps.",
              ["route", "dashed", "journey", "roadmap", "waypoints"],
              svg_doc(640, 40, f'<path fill="none" stroke="{slate}" stroke-width="2" stroke-dasharray="6 4" d="M20 20 H620"/>'
                              + "".join(f'<rect x="{x - 8}" y="12" width="16" height="16" fill="{white}" stroke="{slate}" stroke-width="2" transform="rotate(45 {x} 20)"/>' for x in (20, 170, 320, 470))
                              + f'<rect x="612" y="12" width="16" height="16" fill="{saf}" transform="rotate(45 620 20)"/>', "Route line"), 640, 40))
    corner = lambda x, y, sx, sy: f'<path fill="none" stroke="{deep}" stroke-width="2" d="M{x} {y + 28 * sy} V{y} H{x + 28 * sx}"/>'
    S.append(("corner-marks", "Rules & dividers", "Corner marks", "Four registration-style corner marks to frame an exhibit, a photo or a quote.",
              ["frame", "corners", "marks", "exhibit"], svg_doc(320, 200, corner(1, 1, 1, 1) + corner(319, 1, -1, 1) + corner(1, 199, 1, -1) + corner(319, 199, -1, -1), "Corner marks"), 320, 200))

    # Labels and badges
    S.append(("cut-corner-label", "Badges & stamps", "Cut-corner label", "A Sea Mist label with a blade-cut corner. Replace the text; the cut rises 24 units.",
              ["label", "tag", "cut corner", "eyebrow"],
              svg_doc(240, 48, f'<path fill="{mist}" d="M0 0 H216 L240 24 V48 H0 Z"/><text x="16" y="30" {text_attr} font-size="14" font-weight="600" letter-spacing="2" fill="{deep}">[SECTION LABEL]</text>', "Cut-corner label"), 240, 48))
    S.append(("beacon-square", "Markers", "Beacon square", "The saffron beacon: a small square that marks the one highlight on a page or slide.",
              ["beacon", "saffron", "highlight", "square"], svg_doc(24, 24, f'<rect width="24" height="24" fill="{saf}"/>', "Beacon square"), 24, 24))
    S.append(("numbered-marker", "Markers", "Numbered marker", "A Deep Current circle with a number, for callouts on exhibits and screens.",
              ["number", "marker", "callout", "circle"],
              svg_doc(40, 40, f'<circle cx="20" cy="20" r="19" fill="{deep}"/><text x="20" y="26" {text_attr} font-size="17" font-weight="700" text-anchor="middle" fill="{white}">01</text>', "Numbered marker"), 40, 40))
    S.append(("waypoint-diamond", "Markers", "Waypoint diamond", "A white diamond with a Storm Slate outline, the waypoint on routes and timelines.",
              ["waypoint", "diamond", "milestone", "marker"],
              svg_doc(40, 40, f'<rect x="8" y="8" width="24" height="24" fill="{white}" stroke="{slate}" stroke-width="2" transform="rotate(45 20 20)"/>', "Waypoint diamond"), 40, 40))

    # Cluster badges
    for num, name, short, hexc, icon in CLUSTERS:
        body = (f'<path fill="{hexc}" d="M0 0 H296 L320 24 V64 H0 Z"/>'
                f'<g transform="translate(16 16) scale(1.3333)">{icon_body(source, icon, white)}</g>'
                f'<text x="64" y="27" {text_attr} font-size="11" font-weight="600" letter-spacing="2" fill="{white}" fill-opacity="0.85">0{num}</text>'
                f'<text x="64" y="47" {text_attr} font-size="16" font-weight="700" fill="{white}">{name.replace("&", "&amp;")}</text>')
        S.append((f"badge-cluster-{num}", "Badges & stamps", f"Cluster badge · {short}", f"Service cluster {num}, {name}, in its cluster colour with the cluster icon.",
                  ["badge", "cluster", short.lower(), icon], svg_doc(320, 64, body, f"Cluster badge {num}"), 320, 64))

    # Status stamps
    stamps = [("draft", "Draft", slate, "Draft"), ("for-discussion", "For discussion", C["tide"], "For discussion"), ("confidential", "Confidential", C["clay"], "Confidential"), ("final", "Final", C["kelp"], "Final")]
    for sid, label, col, txt in stamps:
        body = (f'<rect x="1.5" y="1.5" width="197" height="37" fill="none" stroke="{col}" stroke-width="3"/>'
                f'<rect x="6" y="6" width="188" height="28" fill="none" stroke="{col}" stroke-width="1"/>'
                f'<text x="100" y="25" {text_attr} font-size="13" font-weight="700" letter-spacing="2.5" text-anchor="middle" fill="{col}">{txt.upper()}</text>')
        S.append((f"stamp-{sid}", "Badges & stamps", f"Status stamp · {label}", f"A double-ruled stamp reading {label}. Place top right of covers and exhibits.",
                  ["stamp", "status", sid.replace("-", " ")], svg_doc(200, 40, body, f"Stamp {label}"), 200, 40))
    return S


# generated shape id -> slide-library shape ids it corresponds to (several badges/stamps share one demo slide)
SHAPE_SLIDE_ALIAS = {
    "blades": ("blade-pair",), "cut-corner-label": ("content-label",), "route-line": ("waypoint-route",),
    "corner-marks": ("frame-corners",), "waypoint-diamond": ("waypoint-route",),
    **{f"badge-cluster-{n}": ("cluster-badge",) for n in range(1, 7)},
    **{f"stamp-{s}": ("status-stamp",) for s in ("draft", "for-discussion", "confidential", "final")},
}


def build_shapes(source: Path, slide_index: dict):
    d = ASSETS / "shapes"
    used_slides = set()
    reset_dir(d / "svg")
    reset_dir(d / "preview")
    for sid, sub, name, desc, tags, svg, w, h in shape_defs(source):
        f = d / "svg" / f"ksa-shape-{sid}.svg"
        f.write_text(svg, encoding="utf-8")
        prev = d / "preview" / f"{sid}.png"
        raster(f, prev, 320 if w >= 120 else 160)
        it = add_item(
            id=f"shape.{sid}", category="shapes", subcategory=sub, name=name, description=desc,
            tags=tags_from(*tags, "shape", limit=8),
            preview=rel(prev), formats={"svg": rel(f)},
            insert=dict(SVG_INSERT), hosts=ALL_HOSTS, size={"w": w, "h": h}, editable=True,
            note="Inserts as a vector. In PowerPoint, right-click the picture and choose Convert to Shape to edit the geometry.",
        )
        entry = next((slide_index[k] for k in ("shape." + sid, *("shape." + a for a in SHAPE_SLIDE_ALIAS.get(sid, ()))) if k in slide_index), None)
        if entry:
            # attach only the slide data; keep the generated name, preview and description
            apply_slide_entry(it, {k: entry[k] for k in ("slideIndex", "sourceSlideIds", "file") if k in entry})
            it["note"] = "In PowerPoint this inserts the editable shape slide from the KSA slide library; elsewhere it inserts the vector."
            used_slides.add(entry["id"])
    # shape slides that none of the generated shapes claimed become items of their own
    for eid, e in slide_index.items():
        if CAT_ALIAS.get(str(e.get("category", "")).lower()) == "shapes" and eid not in used_slides:
            add_slide_item(eid, e, "shapes")
        if sid == "badge-cluster-1":
            it["featured"] = True


# ---------------------------------------------------------------- 6. slide-library categories
SLIDE_LIBRARY = "assets/templates/KSA_Slide_Library.pptx"

CHARTS = [
    ("column", "Column", "Single-series column chart with the last bar highlighted in Beacon Saffron.", "ColumnClustered", {"highlightLast": True}),
    ("column-stacked", "Stacked column", "Stacked columns in the categorical order, no more than four segments.", "ColumnStacked", {}),
    ("column-100", "100 percent stacked column", "Share of total per category, labels inside segments.", "ColumnStacked100", {}),
    ("bar", "Horizontal bar", "Ranked horizontal bars, largest first, one highlight.", "BarClustered", {"highlightLast": False, "sort": "desc"}),
    ("bar-stacked", "Stacked bar", "Horizontal stacked bars for composition across a few categories.", "BarStacked", {}),
    ("line", "Single line", "One 2px Open Water line, saffron end-point, benchmark labelled.", "Line", {"highlightLast": True, "markers": "end"}),
    ("line-multi", "Multi-line", "Up to five lines with direct labels at the line ends, no legend.", "Line", {"directLabels": True}),
    ("area", "Area", "Area from a zero baseline with a 12 percent fill fading to 0.", "Area", {}),
    ("forecast", "Forecast", "Actuals in a solid line, forecast dotted after the last actual, with a band.", "Line", {"forecast": True}),
    ("donut", "Donut", "A single donut with 18 percent ring thickness and the headline number in the middle.", "Doughnut", {"holeSize": 82}),
    ("scatter", "Scatter", "Dot plot of two measures, Riverstone context dots and one saffron highlight.", "XYScatter", {"highlightLast": True}),
    ("waterfall", "Waterfall", "Bridge from start to end, increases in Open Water, decreases in Red Clay, totals in Deep Current.", "Waterfall", {}),
    ("slope", "Slope", "Two-point lines comparing a start and an end state, labelled at both ends.", "LineMarkers", {"directLabels": True}),
    ("small-multiples", "Small multiples", "The same chart repeated per category, one question per panel; others ghosted in Fog.", "Line", {"panels": 6}),
]
DIAGRAMS = [
    ("process-3", "Process, 3 steps", "Processes", "Three chevron steps with titles and one-line descriptions."),
    ("process-5", "Process, 5 steps", "Processes", "Five chevron steps on one row with numbered markers."),
    ("value-chain", "Value chain", "Processes", "A primary chain of blades with supporting activities below."),
    ("swimlane", "Swimlane flow", "Processes", "A three-lane flow with hand-offs across functions."),
    ("cycle-4", "Cycle, 4 stages", "Cycles", "Four stages in a loop with directional arrows."),
    ("flywheel", "Flywheel", "Cycles", "A reinforcing loop with the driver in the centre."),
    ("matrix-2x2", "2x2 matrix", "Matrices", "Four quadrants with axis labels and a highlighted quadrant."),
    ("risk-heatmap", "Risk heatmap, 5x5", "Matrices", "Likelihood against impact with the KSA risk scale."),
    ("funnel-4", "Funnel, 4 stages", "Funnels", "Four narrowing stages with volumes and conversion."),
    ("pyramid-3", "Pyramid, 3 tiers", "Funnels", "Three tiers from foundation to ambition."),
    ("hub-spoke", "Hub and spoke", "Maps", "A central hub with six spokes, one per service cluster."),
    ("stakeholder-map", "Stakeholder map", "Maps", "Influence against interest with named stakeholder markers."),
    ("journey-map", "Journey map", "Maps", "A route line with waypoints, pain points and moments that matter."),
    ("org-tree", "Organisation tree", "Maps", "A three-level tree with the cut-corner label on each node."),
    ("decision-tree", "Decision tree", "Maps", "Branching choices with outcomes at the leaves."),
    ("horizons", "Three horizons", "Roadmaps", "Horizon 1, 2 and 3 as rising bands with initiatives."),
    ("gantt", "Gantt plan", "Roadmaps", "Workstreams against months with milestones as diamonds."),
    ("pillars-4", "Four pillars", "Structures", "Four pillars under one roof: a strategy house."),
]
INFOGRAPHICS = [
    ("big-number", "Big number", "Numbers", "One number, one line: 300 Expanded with a supporting sentence."),
    ("big-number-trio", "Big number trio", "Numbers", "Three headline numbers side by side with context lines."),
    ("kpi-tiles", "KPI tiles", "Numbers", "Six metric cards with sparklines and change chips."),
    ("percentage-ring", "Percentage ring", "Numbers", "A single share as an 18 percent ring with the number inside."),
    ("progress-bars", "Progress bars", "Numbers", "Five labelled bars against a target line."),
    ("timeline-horizontal", "Timeline, horizontal", "Timelines", "A route line with dated waypoints and short captions."),
    ("timeline-vertical", "Timeline, vertical", "Timelines", "A vertical spine with milestones and descriptions."),
    ("milestone-ribbon", "Milestone ribbon", "Timelines", "A ribbon of phases with the current phase in saffron."),
    ("comparison-2", "Comparison, two options", "Comparisons", "Two columns comparing options on the same criteria."),
    ("before-after", "Before and after", "Comparisons", "Current state against target state with the delta."),
    ("pros-cons", "Pros and cons", "Comparisons", "Two lists with verdict marks."),
    ("scorecard-rag", "RAG scorecard", "Scorecards", "Workstreams rated red, amber, green with a comment column."),
    ("checklist", "Checklist", "Scorecards", "A list of criteria with check marks and owners."),
    ("icon-grid", "Icon grid", "Lists", "Six icons with titles and one-line descriptions on a 3x2 grid."),
    ("stat-callout", "Stat callout", "Lists", "A quote-style callout with one statistic and its source."),
    ("quote-block", "Quote block", "Lists", "A serif italic quote with attribution and the saffron mark."),
]
LAYOUTS = [
    ("cover", "Cover", "Openers", "Project name, subtitle and date on the chart-contours pattern."),
    ("agenda", "Agenda", "Openers", "Numbered agenda with saffron marks for the current item."),
    ("divider", "Section divider", "Openers", "Big section number and title on the chevron-wake pattern."),
    ("action-title", "Action title and exhibit", "Content", "One message in the title, proved by the exhibit, with a source line."),
    ("insight", "Insight", "Content", "Title, exhibit and so-what panel on the right."),
    ("two-column", "Two columns", "Content", "Text left, exhibit right on the 12-column grid."),
    ("three-columns", "Three columns", "Content", "4 + 4 + 4 columns with icons, titles and text."),
    ("text-sidebar", "Text with sidebar", "Content", "Body text with a Sea Mist sidebar for definitions or sources."),
    ("full-bleed", "Full-bleed image", "Content", "Edge-to-edge photograph with a Deep Current caption band."),
    ("table", "Table", "Content", "A KSA-styled table with a highlighted row."),
    ("big-number", "Big number", "Statements", "One number, one line, in 300 Expanded."),
    ("quote", "Quote", "Statements", "Serif italic quote at 72/90 with attribution."),
    ("team", "Team", "People", "Four profiles with photo frames and cut-corner labels."),
    ("contact", "Contact", "Closers", "Offices, email and website with the identifier."),
    ("appendix", "Appendix divider", "Closers", "A quiet divider for the appendix section."),
    ("closing", "Closing", "Closers", "Thank you with contacts on the contours pattern."),
]
REPORT_LAYOUTS = [
    ("cover", "Report cover", "Covers", "Title, standfirst, date and the identifier on the contours pattern."),
    ("contents", "Contents", "Front matter", "Numbered contents with section rules."),
    ("executive-summary", "Executive summary", "Front matter", "Key messages as numbered statements with a big number."),
    ("chapter-opener", "Chapter opener", "Chapters", "Chapter number, title and one-paragraph standfirst."),
    ("body-two-column", "Two-column body", "Chapters", "Two text columns with pull quotes in the margin."),
    ("exhibit-page", "Exhibit page", "Chapters", "A full-width exhibit with title, source and a so-what paragraph."),
    ("table-page", "Table page", "Chapters", "A KSA-styled table with notes beneath."),
    ("callout-page", "Callout page", "Chapters", "A Sea Mist callout panel for a case note or definition."),
    ("quote-page", "Quote page", "Chapters", "A single serif quote with attribution."),
    ("methodology", "Methodology and sources", "Back matter", "Approach, sources and limitations in a structured list."),
    ("letter", "Letter page", "Correspondence", "Letterhead page with address block and signature area."),
    ("back-cover", "Back cover", "Covers", "Contacts and the wordmark on Deep Current."),
]
TEMPLATES = [
    ("corporate-presentation", "Corporate presentation", "KSA_Corporate_Presentation.pptx", "The KSA corporate deck: who we are, service clusters, how we work, contacts."),
    ("service-proposal-pptx", "Service proposal (deck)", "KSA_Service_Proposal.pptx", "Proposal deck: context, approach, team, timeline and commercials."),
    ("service-proposal-docx", "Service proposal (document)", "KSA_Service_Proposal.docx", "Proposal document with cover, scope, approach, team and terms."),
    ("thought-leadership", "Thought leadership report", "KSA_Thought_Leadership.docx", "Long-form report with chapter openers, exhibits and callouts."),
    ("slide-library", "Slide library", "KSA_Slide_Library.pptx", "Every insertable slide: layouts, charts, diagrams, infographics, shapes and effects."),
    ("report-layouts", "Report layouts", "KSA_Report_Layouts.docx", "Every Word page layout in one document."),
    ("excel-charts", "Excel charts workbook", "KSA_Excel_Charts.xlsx", "Styled chart examples and a data sheet to copy from."),
    ("email-templates", "Email templates", "KSA_Email_Templates.html", "Signature, announcement and follow-up email blocks."),
    ("office-theme", "Office theme", "KSA_Office_Theme.thmx", "The KSA colour and font theme for PowerPoint, Word and Excel."),
]
TEMPLATE_HOSTS = {".pptx": ["powerpoint"], ".docx": ["word"], ".xlsx": ["excel"], ".html": ["outlook"], ".thmx": DOC_HOSTS}
TEMPLATE_NOTE = {
    "powerpoint": "Inserts every slide of the template after the current slide, keeping the KSA formatting.",
    "word": "Opens as a new document.",
    "excel": "Opens as a new workbook.",
    "outlook": "Inserts the HTML block into the message you are writing.",
}


def load_index(path: Path):
    """Reads an index file written by the templates owner. Tolerates a few shapes:
    a list of entries, or an object with "slides" / "items" / "entries" (and an optional top-level "file").
    Each entry: id (or itemId), slideIndex (int or list; also index/slide), sourceSlideIds (or slideIds), preview, name,
    subcategory, tags, description, spec, file, hosts, insert."""
    if not path.exists():
        return {}, None
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except Exception as e:
        warn(f"could not parse {path.name}: {e}")
        return {}, None
    top_file = None
    entries = data
    if isinstance(data, dict):
        top_file = data.get("file")
        entries = data.get("slides") or data.get("blocks") or data.get("items") or data.get("entries") or data.get("layouts") or []
    out = {}
    for e in entries:
        if not isinstance(e, dict):
            continue
        eid = e.get("id") or e.get("itemId")
        if not eid:
            continue
        if top_file and not e.get("file"):
            e = {**e, "file": top_file}
        out[str(eid)] = e
    print(f"  read {path.name}: {len(out)} entries")
    return out, top_file


def apply_slide_entry(it, e):
    idx = e.get("slideIndex", e.get("index", e.get("slide")))
    if idx is not None:
        it["slideIndex"] = [int(i) for i in (idx if isinstance(idx, list) else [idx])]
    ids = e.get("sourceSlideIds") or e.get("slideIds")
    if ids:
        it["sourceSlideIds"] = [str(i) for i in ids]
    for k in ("preview", "name", "subcategory", "description", "tags", "spec", "file", "hosts", "note", "badge"):
        if e.get(k) not in (None, "", []):
            it[k] = e[k]
    if "slideIndex" in it or "sourceSlideIds" in it:
        it.setdefault("file", SLIDE_LIBRARY)
        it.setdefault("insert", {})["powerpoint"] = "slide"
    if it.get("insert", {}).get("powerpoint") == "slide" and "powerpoint" not in it.get("hosts", []):
        it["hosts"] = ["powerpoint"] + it.get("hosts", [])


def preview_path(item_id):
    return f"assets/templates/previews/{item_id}.png"


CAT_ALIAS = {"chart": "charts", "charts": "charts", "diagram": "diagrams", "diagrams": "diagrams", "info": "infographics",
             "infographic": "infographics", "infographics": "infographics", "layout": "layouts", "layouts": "layouts",
             "shape": "shapes", "shapes": "shapes", "effect": "effects", "effects": "effects", "report": "report-layouts",
             "report-layout": "report-layouts", "report-layouts": "report-layouts", "template": "templates", "templates": "templates"}
FEATURED = {"chart.column", "chart.column-highlight", "diagram.process", "diagram.process-chevrons", "diagram.process-3",
            "layout.action-title", "layout.action-exhibit", "tpl.corporate-presentation", "info.big-number-trio"}
# Excel chart specs keyed by slide-library chart id; anything unknown falls back to a guess from the id
CHART_SPECS = {
    "chart.column": {"chartType": "ColumnClustered", "highlightLast": True},
    "chart.column-highlight": {"chartType": "ColumnClustered", "highlightLast": True},
    "chart.column-grouped": {"chartType": "ColumnClustered", "highlightLast": False},
    "chart.column-stacked": {"chartType": "ColumnStacked", "highlightLast": False},
    "chart.column-100": {"chartType": "ColumnStacked100", "highlightLast": False},
    "chart.bar": {"chartType": "BarClustered", "highlightLast": False, "sort": "desc"},
    "chart.bar-sorted": {"chartType": "BarClustered", "highlightLast": False, "sort": "desc", "highlightFirst": True},
    "chart.bar-stacked": {"chartType": "BarStacked", "highlightLast": False},
    "chart.bullet": {"chartType": "BarClustered", "highlightLast": False, "targetSeries": 2},
    "chart.line": {"chartType": "Line", "highlightLast": True, "markers": "end"},
    "chart.line-benchmark": {"chartType": "Line", "highlightLast": True, "benchmarkSeries": 2, "benchmarkDash": True},
    "chart.line-multi": {"chartType": "Line", "highlightLast": False, "directLabels": True},
    "chart.area": {"chartType": "Area", "highlightLast": False},
    "chart.forecast": {"chartType": "Line", "highlightLast": True, "forecast": True},
    "chart.donut": {"chartType": "Doughnut", "highlightLast": False, "holeSize": 82},
    "chart.scatter": {"chartType": "XYScatter", "highlightLast": True},
    "chart.waterfall": {"chartType": "Waterfall", "highlightLast": False},
    "chart.slope": {"chartType": "LineMarkers", "highlightLast": False, "directLabels": True},
    "chart.small-multiples": {"chartType": "Line", "highlightLast": False, "panels": 4},
    "chart.combo": {"chartType": "ColumnClustered", "highlightLast": False, "lineSeries": 2, "note": "secondary axis is declared on the slide; Excel builds the column part"},
}


def guess_chart_spec(iid, name):
    key = (iid + " " + name).lower()
    for word, ctype in (("waterfall", "Waterfall"), ("donut", "Doughnut"), ("doughnut", "Doughnut"), ("scatter", "XYScatter"), ("area", "Area"),
                        ("stacked column", "ColumnStacked"), ("column-stacked", "ColumnStacked"), ("bar-stacked", "BarStacked"), ("bar", "BarClustered"),
                        ("line", "Line"), ("column", "ColumnClustered")):
        if word in key:
            return {"chartType": ctype, "highlightLast": ctype == "ColumnClustered"}
    return {"chartType": "ColumnClustered", "highlightLast": True}


def finish_preview(it):
    """Fallback preview path; the checker reports it as pending while the templates owner has not produced it yet."""
    it.setdefault("preview", preview_path(it["id"]))
    if not (ROOT / it["preview"]).exists():
        PENDING.append(it["preview"])
    it.setdefault("formats", {"png": it["preview"]})
    if it["id"] in FEATURED:
        it["featured"] = True
    return it


def add_slide_item(eid, e, cat):
    """One catalogue item for a slide-library entry (charts, diagrams, infographics, layouts, effect demos)."""
    if cat == "charts":
        spec = dict(CHART_SPECS.get(eid) or guess_chart_spec(eid, e.get("name", "")))
        spec.setdefault("title", e.get("name", eid))
        it = add_item(id=eid, category=cat, subcategory=e.get("subcategory", "Chart presets"), name=e.get("name", eid),
                      description=e.get("description", ""), tags=e.get("tags") or tags_from(e.get("name", eid), "chart"),
                      spec=spec, insert={"powerpoint": "slide", "word": "png", "excel": "chart"}, hosts=DOC_HOSTS,
                      file=SLIDE_LIBRARY, editable=True,
                      note="PowerPoint inserts the native chart slide; Excel builds a styled chart from the selected range; Word inserts a picture.")
    else:
        note = {"effects": "Inserts a demo slide with the effect applied to a sample shape or picture; copy the styling from there.",
                "layouts": "Inserts the layout as a new slide after the current one."}.get(cat, "Inserts an editable grouped-shape slide from the KSA slide library.")
        it = add_item(id=eid, category=cat, subcategory=e.get("subcategory", "Other"), name=e.get("name", eid),
                      description=e.get("description", ""), tags=e.get("tags") or tags_from(e.get("name", eid), cat),
                      insert={"powerpoint": "slide"}, hosts=["powerpoint"], file=SLIDE_LIBRARY, editable=bool(e.get("grouped", True)), note=note)
    if e.get("grouped"):
        it["badge"] = "Grouped"
    apply_slide_entry(it, e)
    return finish_preview(it)


def build_slide_categories(slide_index: dict, report_index: dict):
    # ---- slide library: charts, diagrams, infographics, layouts, effect demos
    if slide_index:
        for eid, e in slide_index.items():
            cat = CAT_ALIAS.get(str(e.get("category") or eid.split(".")[0]).lower())
            if cat is None:
                warn(f"index entry {eid} has unknown category {e.get('category')}; skipped")
                continue
            if cat == "shapes":
                continue  # attached to the generated SVG shapes in build_shapes()
            add_slide_item(eid, e, cat)
    else:
        warn("slide-library-index.json absent: using the built-in fallback lists (ids will change once the index ships)")
        for sid, name, desc, chart_type, extra in CHARTS:
            e = {"name": name, "description": desc, "subcategory": "Chart presets"}
            CHART_SPECS.setdefault(f"chart.{sid}", {"chartType": chart_type, "highlightLast": extra.get("highlightLast", False), **{k: v for k, v in extra.items() if k != "highlightLast"}})
            add_slide_item(f"chart.{sid}", e, "charts")
        for cat, defs, prefix in (("diagrams", DIAGRAMS, "diagram"), ("infographics", INFOGRAPHICS, "info"), ("layouts", LAYOUTS, "layout")):
            for sid, name, sub, desc in defs:
                add_slide_item(f"{prefix}.{sid}", {"name": name, "subcategory": sub, "description": desc}, cat)

    # ---- report layouts (Word OOXML blocks)
    if report_index:
        for eid, e in report_index.items():
            it = add_item(id=eid, category="report-layouts", subcategory=e.get("subcategory") or "Report layouts", name=e.get("name", eid),
                          description=e.get("description", ""), tags=e.get("tags") or tags_from(e.get("name", eid), "word", "report"),
                          insert={"word": "ooxml"}, hosts=["word"], file=e.get("file") or f"assets/layouts/word/{eid}.xml", editable=True,
                          note="Inserts a full page at the cursor." if e.get("fullPage") else "Inserts the block as editable Word content at the cursor.")
            if e.get("fullPage"):
                it["badge"] = "Full page"
            if e.get("page"):
                it["page"] = e["page"]
            if e.get("preview"):
                it["preview"] = e["preview"]
            finish_preview(it)
            if not (ROOT / it["file"]).exists():
                PENDING.append(it["file"])
    else:
        warn("report-layouts-index.json absent: using the built-in fallback list")
        for sid, name, sub, desc in REPORT_LAYOUTS:
            iid = f"report.{sid}"
            it = add_item(id=iid, category="report-layouts", subcategory=sub, name=name, description=desc,
                          tags=tags_from(name, sub, "word", "report", "page"), insert={"word": "ooxml"}, hosts=["word"],
                          file=f"assets/layouts/word/{iid}.xml", editable=True, note="Inserts the page as editable Word content at the cursor.")
            finish_preview(it)
            if not (ROOT / it["file"]).exists():
                PENDING.append(it["file"])

    # ---- templates
    for sid, name, fname, desc in TEMPLATES:
        ext = Path(fname).suffix.lower()
        hosts = TEMPLATE_HOSTS.get(ext, DOC_HOSTS)
        file = f"assets/templates/{fname}"
        if ext == ".thmx":
            insert = {"default": "download"}
            note = "Downloads the theme file. In PowerPoint, Word or Excel choose Design, Themes, Browse for Themes and open it."
        elif ext == ".html":
            insert = {"outlook": "html", "default": "download"}
            note = TEMPLATE_NOTE["outlook"]
        else:
            insert = {"default": "template"}
            note = TEMPLATE_NOTE[hosts[0]]
        it = add_item(id=f"tpl.{sid}", category="templates", subcategory=ext.lstrip(".").upper(), name=name, description=desc,
                      tags=tags_from(name, ext.lstrip("."), "template"), insert=insert, hosts=hosts, file=file, editable=True, note=note)
        if ext == ".html":
            it["html"] = file
        # the templates owner names previews tpl-<id>.png (and tpl-service-proposal.png for the deck)
        for cand in (f"tpl.{sid}.png", f"tpl-{sid}.png", f"tpl-{sid.replace('-pptx', '')}.png"):
            if (ASSETS / "templates" / "previews" / cand).exists():
                it["preview"] = f"assets/templates/previews/{cand}"
                break
        if ext == ".html" and "preview" not in it and (ROOT / file).exists():
            it["preview"] = render_html_preview(ROOT / file, ASSETS / "templates" / "previews" / f"tpl-{sid}.png")
        finish_preview(it)
        if not (ROOT / file).exists():
            PENDING.append(file)


def render_html_preview(html: Path, out: Path):
    """Screenshot an HTML template with Playwright (320 px wide) when the templates owner has not supplied a preview."""
    if out.exists():
        return rel(out)
    try:
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            b = pw.chromium.launch()
            pg = b.new_page(viewport={"width": 640, "height": 360}, device_scale_factor=0.5)
            pg.goto(html.resolve().as_uri())
            pg.wait_for_timeout(300)
            out.parent.mkdir(parents=True, exist_ok=True)
            pg.screenshot(path=str(out))
            b.close()
        print(f"  rendered {rel(out)} from {html.name}")
    except Exception as e:
        warn(f"could not render a preview for {html.name}: {e}")
    return rel(out) if out.exists() else None


# ---------------------------------------------------------------- 7. effects
EFFECTS = [
    ("card", "Card", "A white card with a 1px Fog line, Archivo in Deep Current and the e1 shadow.",
     {"id": "card", "fill": C["white"], "line": C["fog"], "lineWeight": 1, "font": "Archivo", "color": C["deep"], "shadow": "e1"}),
    ("card-dark", "Dark card", "A Deep Current card with white Archivo text and no line.",
     {"id": "card-dark", "fill": C["deep"], "line": None, "font": "Archivo", "color": C["white"]}),
    ("beacon", "Beacon", "Beacon Saffron fill with Deep Current text: the one highlight on the slide.",
     {"id": "beacon", "fill": C["saffron"], "line": None, "color": C["deep"], "font": "Archivo"}),
    ("headline", "Headline", "Archivo Bold 28pt in Deep Current for action titles.",
     {"id": "headline", "font": "Archivo", "color": C["deep"], "bold": True, "size": 28}),
    ("standfirst", "Standfirst", "Source Serif 4 at 16pt in Storm Slate for standfirsts and quotes.",
     {"id": "standfirst", "font": "Source Serif 4", "color": C["slate"], "size": 16}),
    ("chart", "Chart styling", "Applies the KSA data rules to the selected chart: Open Water series, saffron highlight, Fog gridlines, zero baseline.",
     {"id": "chart"}),
    ("table", "Table styling", "Applies the KSA table style: Deep Current header, Fog rules, Archivo text, right-aligned numbers.",
     {"id": "table"}),
    ("shadow-e1", "Shadow e1", "Elevation 1: 4px offset, 12px blur at 12 percent.", {"id": "shadow", "shadow": "e1"}),
    ("shadow-e2", "Shadow e2", "Elevation 2: 8px offset, 24px blur at 14 percent.", {"id": "shadow", "shadow": "e2"}),
    ("shadow-e3", "Shadow e3", "Elevation 3: 16px offset, 40px blur at 16 percent.", {"id": "shadow", "shadow": "e3"}),
    ("ksa-theme", "KSA theme", "Applies the KSA theme colours and fonts to the whole document, deck or workbook.", {"id": "ksa-theme"}),
]
SHADOWS = {"e1": {"offsetY": 4, "blur": 12, "opacity": 0.12}, "e2": {"offsetY": 8, "blur": 24, "opacity": 0.14}, "e3": {"offsetY": 16, "blur": 40, "opacity": 0.16}}


def effect_preview_svg(sid, spec):
    deep, water, saf, slate, fog, mist, white = C["deep"], C["water"], C["saffron"], C["slate"], C["fog"], C["mist"], C["white"]
    bg = f'<rect width="320" height="180" fill="{mist}"/>'
    if sid.startswith("shadow-"):
        s = SHADOWS[spec["shadow"]]
        return svg_doc(320, 180, bg + f'<defs><filter id="sh" x="-30%" y="-30%" width="160%" height="180%"><feDropShadow dx="0" dy="{s["offsetY"] / 2}" stdDeviation="{s["blur"] / 4}" flood-color="{deep}" flood-opacity="{s["opacity"] * 2}"/></filter></defs>'
                       f'<rect x="80" y="45" width="160" height="90" fill="{white}" filter="url(#sh)"/><text x="160" y="96" font-family="{FONT}" font-size="14" text-anchor="middle" fill="{slate}">{spec["shadow"]}</text>')
    if sid in ("card", "card-dark", "beacon"):
        fill = spec["fill"]
        line = f' stroke="{spec["line"]}" stroke-width="1"' if spec.get("line") else ""
        return svg_doc(320, 180, bg + f'<rect x="40" y="40" width="240" height="100" fill="{fill}"{line}/><text x="60" y="78" font-family="{FONT}" font-size="16" font-weight="700" fill="{spec["color"]}">Title in Archivo</text><text x="60" y="104" font-family="{FONT}" font-size="12" fill="{spec["color"]}" fill-opacity="0.8">Body text on the {spec["id"].replace("-", " ")} fill.</text>')
    if sid == "headline":
        return svg_doc(320, 180, bg + f'<text x="24" y="86" font-family="{FONT}" font-size="26" font-weight="700" fill="{deep}">One message</text><text x="24" y="118" font-family="{FONT}" font-size="26" font-weight="700" fill="{deep}">per slide.</text>')
    if sid == "standfirst":
        return svg_doc(320, 180, bg + f'<text x="24" y="80" font-family="{SERIF}" font-size="16" font-style="italic" fill="{slate}">Good advice is a decision a board</text><text x="24" y="104" font-family="{SERIF}" font-size="16" font-style="italic" fill="{slate}">can defend, not a study it has to read.</text>')
    if sid == "chart":
        bars = "".join(f'<rect x="{50 + i * 48}" y="{150 - h}" width="28" height="{h}" fill="{saf if i == 4 else water}"/>' for i, h in enumerate((40, 62, 55, 80, 104)))
        grid = "".join(f'<line x1="40" x2="300" y1="{y}" y2="{y}" stroke="{fog}" stroke-width="1"/>' for y in (60, 90, 120))
        return svg_doc(320, 180, bg + grid + bars + f'<line x1="40" x2="300" y1="150" y2="150" stroke="{C["river"]}" stroke-width="1"/>')
    if sid == "table":
        rows = "".join(f'<line x1="40" x2="280" y1="{y}" y2="{y}" stroke="{fog}"/>' for y in (92, 116, 140))
        cells = "".join(f'<text x="52" y="{y}" font-family="{FONT}" font-size="11" fill="{slate}">Row {i + 1}</text><text x="268" y="{y}" font-family="{FONT}" font-size="11" text-anchor="end" fill="{deep}">{(i + 1) * 128:,}</text>' for i, y in enumerate((86, 110, 134)))
        return svg_doc(320, 180, bg + f'<rect x="40" y="44" width="240" height="24" fill="{deep}"/><text x="52" y="60" font-family="{FONT}" font-size="11" font-weight="600" fill="{white}">Workstream</text><text x="268" y="60" font-family="{FONT}" font-size="11" font-weight="600" text-anchor="end" fill="{white}">Value</text>' + rows + cells)
    # theme
    sw = "".join(f'<rect x="{40 + i * 40}" y="60" width="40" height="40" fill="{c}"/>' for i, c in enumerate((deep, white, slate, mist, water, saf)))
    return svg_doc(320, 180, bg + sw + f'<text x="40" y="128" font-family="{FONT}" font-size="12" font-weight="700" fill="{deep}">Archivo</text><text x="110" y="128" font-family="{SERIF}" font-size="12" font-style="italic" fill="{slate}">Source Serif 4</text>')


def build_effects():
    d = ASSETS / "effects"
    reset_dir(d / "preview")
    presets = {}
    mask = svg_doc(1920, 1080, f'<path fill="#000" d="M0 0 H1920 V1080 H0 Z"/><path fill="#fff" d="M0 0 H1480 L1920 1080 H0 Z"/>', "Blade crop mask")
    (d / "blade-crop-mask.svg").write_text(mask, encoding="utf-8")
    for sid, name, desc, spec in EFFECTS:
        svg = d / "preview" / f"{sid}.svg"
        svg.write_text(effect_preview_svg(sid, spec), encoding="utf-8")
        prev = d / "preview" / f"{sid}.png"
        raster(svg, prev, 320)
        presets[sid] = spec
        hosts = DOC_HOSTS if sid not in ("chart", "table") else ["powerpoint", "excel", "word"]
        add_item(id=f"effect.{sid}", category="effects", subcategory="Shadows" if sid.startswith("shadow") else ("Type" if sid in ("headline", "standfirst") else ("Theme" if sid == "ksa-theme" else "Fills & styling")),
                 name=name, description=desc, tags=tags_from(name, "effect", "style", spec.get("id")),
                 preview=rel(prev), formats={"png": rel(prev)}, insert={"default": "effect"}, hosts=hosts, spec=spec, editable=False,
                 note="Select a shape, text, chart or table first, then apply.")
    (d / "presets.json").write_text(json.dumps({"version": "1.0.0", "shadows": SHADOWS, "presets": presets,
                                                "masks": {"blade": "assets/effects/blade-crop-mask.svg"},
                                                "duotone": {"shadow": C["deep"], "highlight": C["spray"]},
                                                "patternOverlay": {"opacity": 0.1, "note": "never stronger than 10 percent behind body text"}}, indent=1), encoding="utf-8")


# ---------------------------------------------------------------- write + raster
PENDING = []


def write_fontconfig(tmp: Path) -> Path:
    conf = tmp / "fonts.conf"
    dirs = [ASSETS / "fonts" / "Archivo" / "Static", ASSETS / "fonts" / "Source_Serif_4" / "Static", Path("/usr/share/fonts")]
    body = "".join(f"<dir>{d}</dir>" for d in dirs if d.exists())
    conf.write_text(f'<?xml version="1.0"?><!DOCTYPE fontconfig SYSTEM "fonts.dtd"><fontconfig>{body}<cachedir>{tmp / "fc-cache"}</cachedir></fontconfig>')
    return conf


def run_raster(skip: bool):
    if skip:
        print(f"skipping rasterisation ({len(RASTER_JOBS)} jobs)")
        return
    tmp = Path(tempfile.mkdtemp(prefix="ksa-raster-"))
    jobs = tmp / "jobs.json"
    jobs.write_text(json.dumps(RASTER_JOBS))
    env = dict(os.environ, FONTCONFIG_FILE=str(write_fontconfig(tmp)))
    node = shutil.which("node") or "/opt/node22/bin/node"
    print(f"rasterising {len(RASTER_JOBS)} previews with sharp ...")
    r = subprocess.run([node, str(ROOT / "tools" / "rasterise.js"), str(jobs)], env=env)
    if r.returncode != 0:
        warn("rasterise.js reported failures")
    shutil.rmtree(tmp, ignore_errors=True)


def write_library():
    def key(it):
        return (CAT_ORDER.get(it["category"], 99), it.get("subcategory", ""), it["name"].lower())
    items = sorted(ITEMS, key=key)
    lib = {
        "version": "1.0.0",
        "generated": datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z"),
        "categories": [{"id": i, "name": n, "icon": ic, "description": d} for i, n, ic, d in CATEGORIES],
        "items": items,
    }
    out = ASSETS / "library.json"
    out.write_text(json.dumps(lib, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    size = out.stat().st_size
    print(f"wrote {rel(out)}: {len(items)} items, {size / 1e6:.2f} MB")
    counts = {}
    for it in items:
        counts[it["category"]] = counts.get(it["category"], 0) + 1
    for cid, *_ in CATEGORIES:
        print(f"  {cid:16s} {counts.get(cid, 0)}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--source", default=str(DEFAULT_SOURCE), help="the scratchpad folder holding icons/, ind/, vg/ (S in the brief)")
    ap.add_argument("--skip-raster", action="store_true", help="do not run sharp (previews are left as they are)")
    ap.add_argument("--only", default="", help="comma list of sections to rebuild: logo,icons,industry,patterns,shapes,slides,effects")
    a = ap.parse_args()
    global SKIP_RASTER
    SKIP_RASTER = a.skip_raster
    source = Path(a.source).resolve()
    only = set(filter(None, a.only.split(",")))
    want = lambda s: not only or s in only
    print(f"ROOT   {ROOT}\nSOURCE {source}")

    slide_index, _ = load_index(ROOT / "tools" / "make-templates" / "slide-library-index.json")
    report_index, _ = load_index(ROOT / "tools" / "make-templates" / "report-layouts-index.json")
    if not slide_index:
        warn("tools/make-templates/slide-library-index.json not found: charts, diagrams, infographics, layouts and shape slides use the built-in list without slideIndex")
    if not report_index:
        warn("tools/make-templates/report-layouts-index.json not found: report layouts use the built-in list")

    if only:
        # partial rebuild: keep items of the sections we are not touching
        try:
            old = json.loads((ASSETS / "library.json").read_text(encoding="utf-8"))["items"]
        except Exception:
            old = []
        keep = {"logo": "logo", "icons": "icons", "industry-icons": "industry", "patterns": "patterns", "shapes": "shapes", "effects": "effects",
                "charts": "slides", "diagrams": "slides", "infographics": "slides", "layouts": "slides", "report-layouts": "slides", "templates": "slides"}
        ITEMS.extend(it for it in old if not want(keep.get(it["category"], "slides")))

    if want("logo"):
        build_logo()
    if want("icons"):
        build_icons(source)
    if want("industry"):
        build_industry(source)
    if want("patterns"):
        build_patterns(source)
    if want("shapes"):
        build_shapes(source, slide_index)
    if want("slides"):
        build_slide_categories(slide_index, report_index)
    if want("effects"):
        build_effects()

    run_raster(a.skip_raster)
    write_library()
    if PENDING:
        uniq = sorted(set(PENDING))
        print(f"PENDING from other contributors ({len(uniq)} files referenced but not present yet), e.g.:")
        for p in uniq[:12]:
            print("   " + p)
        if len(uniq) > 12:
            print(f"   ... and {len(uniq) - 12} more (run tools/check-library.py for the full list)")
    if WARNINGS:
        print(f"{len(WARNINGS)} warning(s).")


if __name__ == "__main__":
    main()
