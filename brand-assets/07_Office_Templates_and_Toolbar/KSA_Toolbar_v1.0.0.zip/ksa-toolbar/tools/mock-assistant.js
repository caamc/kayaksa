#!/usr/bin/env node
/* mock-assistant.js — a stand-in for the KSA Assistant proxy. No API key, no dependencies.
 *   node tools/mock-assistant.js            → http://localhost:8787
 *   PORT=9000 node tools/mock-assistant.js
 * Implements GET /health and POST /chat with the real response shape, canned answers and one sample action per host,
 * so the task-pane UI (context strip, markdown, action buttons) can be exercised end to end.
 * Put http://localhost:8787 into the add-in Settings → Assistant endpoint. */
const http = require("http");

const PORT = Number(process.env.PORT) || 8787;
const DELAY_MS = 600;

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization",
};

function send(res, status, body) {
  res.writeHead(status, { "content-type": "application/json; charset=utf-8", ...CORS });
  res.end(JSON.stringify(body));
}

function describe(ctx) {
  const s = ctx?.selection || {};
  switch (s.kind) {
    case "range": return `the ${s.rowCount || 0} × ${s.colCount || 0} range at ${s.address || "?"}${s.sampled ? " (sampled)" : ""}`;
    case "text": return `${s.words || 0} words of ${s.source === "document" ? "document" : "selected"} text`;
    case "shapes": return `${(s.shapes || []).length} text shape(s) and ${(s.tables || []).length} table(s) on ${s.slide ? "slide " + s.slide : "the slide"}`;
    case "message": return `the message "${s.subject || "(no subject)"}"`;
    default: return "no document context";
  }
}

/* A small, deterministic data pass so Excel answers feel real. */
function analyseRange(sel) {
  const rows = Array.isArray(sel.rows) ? sel.rows : [];
  if (rows.length < 2) return null;
  const header = rows[0].map((v) => String(v ?? ""));
  const body = rows.slice(1);
  const numericCols = header.map((_, c) => body.filter((r) => typeof r[c] === "number").length > body.length / 2);
  const col = numericCols.findIndex((ok, c) => ok && c > 0);
  if (col < 0) return null;
  const vals = body.map((r) => ({ label: String(r[0] ?? ""), v: typeof r[col] === "number" ? r[col] : null })).filter((x) => x.v !== null);
  if (!vals.length) return null;
  const sum = vals.reduce((a, x) => a + x.v, 0), mean = sum / vals.length;
  const max = vals.reduce((a, x) => (x.v > a.v ? x : a), vals[0]);
  const min = vals.reduce((a, x) => (x.v < a.v ? x : a), vals[0]);
  return { metric: header[col] || "value", n: vals.length, sum, mean, max, min, share: sum ? max.v / sum : 0 };
}
function inr(n) {
  const s = Math.round(Math.abs(n)).toString();
  if (s.length <= 3) return (n < 0 ? "-" : "") + s;
  const last3 = s.slice(-3), rest = s.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ",");
  return (n < 0 ? "-" : "") + rest + "," + last3;
}

function answer(host, ctx, question) {
  const q = question.toLowerCase();
  const seen = describe(ctx);
  const sel = ctx?.selection || {};
  switch (host) {
    case "excel": {
      const a = sel.kind === "range" ? analyseRange(sel) : null;
      const lead = a
        ? `**${a.max.label} leads on ${a.metric} at ${inr(a.max.v)}, ${(a.share * 100).toFixed(1)}% of the total** across ${a.n} rows; ${a.min.label} trails at ${inr(a.min.v)}. The mean is ${inr(a.mean)}.`
        : `I read ${seen}. Select a block with labels in the first column and numbers to the right for a fuller answer.`;
      if (/rag|scorecard/.test(q)) {
        return {
          reply: `${lead}\n\nA RAG scorecard needs explicit thresholds. Using tertiles of the selected values: green for the top third, amber for the middle, red for the bottom. Say the thresholds you prefer and I will apply those instead.\n\n| Band | Rule |\n|---|---|\n| Green | top third |\n| Amber | middle third |\n| Red | bottom third |`,
          actions: [{ type: "excel.rag", higherIsBetter: true, label: "Apply RAG (tertiles)" }],
        };
      }
      if (/outlier/.test(q)) {
        return {
          reply: a ? `${lead}\n\n- **${a.max.label}** sits ${((a.max.v / a.mean - 1) * 100).toFixed(0)}% above the mean, the clearest outlier.\n- **${a.min.label}** is ${((1 - a.min.v / a.mean) * 100).toFixed(0)}% below the mean.\n\nCheck both for data-entry errors before reading them as findings.` : lead,
          actions: a ? [{ type: "excel.chart", chartType: "bar", title: `${a.max.label} stands apart from the rest on ${a.metric}`, highlight: a.max.label }] : [],
        };
      }
      return {
        reply: `${lead}\n\nOne chart with one highlight tells this cleanly: a column chart, ${a ? a.max.label : "the leading category"} in Saffron, everything else in Open Water, zero baseline, values at the bar end.`,
        actions: [
          { type: "excel.chart", chartType: "column", title: a ? `${a.max.label} accounts for ${(a.share * 100).toFixed(0)}% of ${a.metric}` : "[Insight headline]", highlight: a ? a.max.label : 0 },
          { type: "excel.table", rows: [["Measure", "Value"], ["Rows", a ? a.n : 0], ["Total", a ? Math.round(a.sum) : 0], ["Mean", a ? Math.round(a.mean) : 0]], label: "Insert summary table" },
        ],
      };
    }
    case "powerpoint": {
      const text = (sel.shapes || []).map((s) => s.text).join(" ").slice(0, 120);
      const table = (sel.tables || [])[0];
      if (/exhibit/.test(q) || table) {
        return {
          reply: `I read ${seen}. An exhibit needs an insight headline, a unit line and a source. Here is a draft built from ${table ? "the table on the slide" : "placeholder rows"}.\n\n- **Headline:** [Category A] delivered most of the growth while the rest held flat\n- **Subtitle:** ₹ crore, FY24 to FY25\n- **Source:** [Source]; KSA analysis`,
          actions: [{ type: "ppt.exhibit", number: 1, title: "[Category A] delivered most of the growth while the rest held flat", subtitle: "₹ crore, FY24 to FY25", source: "[Source]", rows: table?.rows?.length ? table.rows : [["Category", "FY24", "FY25"], ["[Category A]", 420, 560], ["[Category B]", 310, 320], ["[Category C]", 180, 175]], chartType: "column" }],
        };
      }
      return {
        reply: `I read ${seen}${text ? `: "${text}${text.length >= 120 ? "…" : ""}"` : ""}.\n\nAn action title states the takeaway in one sentence. Suggested:\n\n**Three of six clusters already cover the market's fastest-growing risk needs**\n\nShorter alternative: **Risk demand is outgrowing the market's capacity to serve it**`,
        actions: [{ type: "ppt.title", text: "Three of six clusters already cover the market's fastest-growing risk needs" }],
      };
    }
    case "word": {
      if (/standfirst/.test(q)) {
        return {
          reply: `From ${seen}, a standfirst in Source Serif:\n\n*Indian boards are being asked to decide faster on less certain ground. The firms that cope are the ones that treat strategy and risk as one conversation.*`,
          actions: [{ type: "word.insert", style: "standfirst", text: "Indian boards are being asked to decide faster on less certain ground. The firms that cope are the ones that treat strategy and risk as one conversation." }],
        };
      }
      return {
        reply: `From ${seen}, three bullets:\n\n- **[Finding one]** stated as a result, with the number that proves it\n- **[Finding two]** and what it changes for the reader\n- **[Recommended next step]** with an owner and a date`,
        actions: [
          { type: "word.insert", style: "bullets", text: "- [Finding one] stated as a result, with the number that proves it\n- [Finding two] and what it changes for the reader\n- [Recommended next step] with an owner and a date" },
          { type: "copy", text: "[Finding one]\n[Finding two]\n[Recommended next step]", label: "Copy bullets" },
        ],
      };
    }
    case "outlook": {
      return {
        reply: `I read ${seen}. A short reply:\n\nThank you for your note. We can take this forward; I suggest a 30-minute call on [day] to agree scope and timing.\n\nKind regards,\n${ctx?.settings?.userName || "[Full Name]"}`,
        actions: [{ type: "outlook.insert", text: `Thank you for your note. We can take this forward; I suggest a 30-minute call on [day] to agree scope and timing.\n\nKind regards,\n${ctx?.settings?.userName || "[Full Name]"}` }],
      };
    }
    default:
      return {
        reply: `This is the **mock assistant** (no model behind it). It answers with canned text so the add-in UI can be tested.\n\n- In Excel it summarises the selected range and offers a chart\n- In PowerPoint it writes an action title or an exhibit slide\n- In Word it drafts bullets or a standfirst\n- In Outlook it drafts a reply\n\nDeploy the real proxy from \`server/cloudflare-worker\` when you are ready.`,
        actions: [{ type: "copy", text: "KSA Assistant mock reply" }],
      };
  }
}

const server = http.createServer((req, res) => {
  if (req.method === "OPTIONS") { res.writeHead(204, CORS); res.end(); return; }
  const url = new URL(req.url, `http://localhost:${PORT}`);
  if (req.method === "GET" && url.pathname === "/health") return send(res, 200, { ok: true, service: "ksa-assistant-mock", model: "mock", auth: false, keyConfigured: false });
  if (url.pathname !== "/chat") return send(res, 404, { error: { code: "not_found", message: "Use POST /chat or GET /health." } });
  if (req.method !== "POST") return send(res, 405, { error: { code: "method_not_allowed", message: "Use POST for /chat." } });
  let raw = "";
  req.on("data", (chunk) => { raw += chunk; if (raw.length > 5e6) req.destroy(); });
  req.on("end", () => {
    let body;
    try { body = JSON.parse(raw || "{}"); } catch { return send(res, 400, { error: { code: "bad_request", message: "The request body must be JSON." } }); }
    const messages = Array.isArray(body.messages) ? body.messages : [];
    const last = [...messages].reverse().find((m) => m && m.role === "user");
    if (!last) return send(res, 400, { error: { code: "bad_request", message: "messages must contain a user message." } });
    const host = body.context?.host || "hub";
    const out = answer(host, body.context, String(last.content || ""));
    console.log(`${new Date().toISOString()} ${host} · ${describe(body.context)} · "${String(last.content).slice(0, 60)}"`);
    setTimeout(() => send(res, 200, { reply: out.reply, actions: body.actions === false ? [] : out.actions, usage: { input_tokens: 0, output_tokens: 0 }, model: "mock" }), DELAY_MS);
  });
});

server.listen(PORT, () => {
  console.log(`KSA Assistant mock listening on http://localhost:${PORT}  (POST /chat, GET /health)`);
  console.log("Set the add-in Settings → Assistant endpoint to that URL. Ctrl+C to stop.");
});
