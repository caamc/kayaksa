#!/usr/bin/env node
/* rasterise.js: batch SVG/PNG -> PNG with sharp. Called by build-library.py.
 *
 *   node tools/rasterise.js jobs.json
 *
 * jobs.json is a JSON array of { src, out, width, [height], [background] }.
 *   src        absolute path to an .svg or .png
 *   out        absolute path of the PNG to write (parent folders are created)
 *   width      target width in px (height follows the aspect ratio unless given)
 *   background optional CSS colour painted behind transparent areas
 *
 * SVGs are rendered at the target resolution (not up-scaled from their intrinsic size)
 * by computing a density from the SVG's own width or viewBox.
 * sharp is resolved from the project first, then from /opt/npm-tools.
 */
const fs = require("fs");
const path = require("path");

function loadSharp() {
  const candidates = ["sharp", "/opt/npm-tools/node_modules/sharp"];
  for (const c of candidates) { try { return require(c); } catch (e) { /* try next */ } }
  console.error("sharp is not available. Install it (npm i sharp) or put it in /opt/npm-tools/node_modules.");
  process.exit(2);
}
const sharp = loadSharp();

function intrinsicWidth(svgText) {
  const w = /<svg[^>]*\swidth="([\d.]+)(px)?"/i.exec(svgText);
  if (w) return parseFloat(w[1]);
  const vb = /<svg[^>]*\sviewBox="([^"]+)"/i.exec(svgText);
  if (vb) { const p = vb[1].trim().split(/[\s,]+/).map(Number); if (p.length === 4 && p[2] > 0) return p[2]; }
  return 300;
}

async function run(job) {
  const isSvg = /\.svg$/i.test(job.src);
  let img;
  if (isSvg) {
    const text = fs.readFileSync(job.src, "utf8");
    const iw = intrinsicWidth(text);
    const density = Math.max(1, Math.min(2400, (72 * job.width) / iw));
    img = sharp(Buffer.from(text), { density });
  } else {
    img = sharp(job.src);
  }
  const resize = { width: job.width, fit: "inside", withoutEnlargement: false };
  if (job.height) { resize.height = job.height; resize.fit = "cover"; }
  img = img.resize(resize);
  if (job.background) img = img.flatten({ background: job.background });
  fs.mkdirSync(path.dirname(job.out), { recursive: true });
  await img.png({ compressionLevel: 9, palette: !!job.palette }).toFile(job.out);
}

async function main() {
  const file = process.argv[2];
  if (!file) { console.error("usage: rasterise.js jobs.json"); process.exit(1); }
  const jobs = JSON.parse(fs.readFileSync(file, "utf8"));
  let done = 0, failed = 0;
  const concurrency = 8;
  let i = 0;
  async function worker() {
    while (i < jobs.length) {
      const job = jobs[i++];
      try { await run(job); done++; }
      catch (e) { failed++; console.error(`FAILED ${job.src} -> ${job.out}: ${e.message}`); }
      if ((done + failed) % 500 === 0) console.log(`  rasterised ${done + failed}/${jobs.length}`);
    }
  }
  await Promise.all(Array.from({ length: concurrency }, worker));
  console.log(`rasterise: ${done} written, ${failed} failed`);
  if (failed) process.exit(1);
}
main();
