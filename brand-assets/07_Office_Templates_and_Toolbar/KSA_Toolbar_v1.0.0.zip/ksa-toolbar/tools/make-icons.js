/* make-icons.js — renders the manifest/Teams icons and the signature logo PNG from the SVG logo files.
 * Run: node tools/make-icons.js   (needs the `sharp` npm package available to node)
 *
 * Writes:
 *   manifest/icons/icon-16.png … icon-128.png   KSA app icon (identifier on a Deep Current rounded tile)
 *   manifest/icons/color.png                     192×192 Teams colour icon (same artwork)
 *   manifest/icons/outline.png                   32×32 Teams outline icon (white identifier, transparent)
 *   assets/logo/KSA_Logo_Full_FullColour.png     640px-wide logo for email signatures
 */
const fs = require("fs");
const path = require("path");
const sharp = require("sharp");

const ROOT = path.resolve(__dirname, "..");
const SRC_TILE = path.join(ROOT, "assets/logo/KSA_AppIcon_DeepCurrent_Rounded.svg");
const SRC_OUTLINE = path.join(ROOT, "assets/logo/KSA_Identifier_Mono-White.svg");
const SRC_LOGO = path.join(ROOT, "assets/logo/KSA_Logo_Full_FullColour.svg");
const OUT = path.join(ROOT, "manifest/icons");

async function square(src, size, out, opts = {}) {
  const svg = fs.readFileSync(src);
  const pad = Math.round(size * (opts.pad || 0));
  const inner = size - pad * 2;
  const buf = await sharp(svg, { density: 600 }).resize(inner, inner, { fit: "contain", background: { r: 0, g: 0, b: 0, alpha: 0 } }).png().toBuffer();
  await sharp({ create: { width: size, height: size, channels: 4, background: { r: 0, g: 0, b: 0, alpha: 0 } } })
    .composite([{ input: buf, left: pad, top: pad }]).png().toFile(out);
  console.log("wrote", path.relative(ROOT, out));
}

async function main() {
  fs.mkdirSync(OUT, { recursive: true });
  for (const size of [16, 32, 64, 80, 128]) await square(SRC_TILE, size, path.join(OUT, `icon-${size}.png`));
  await square(SRC_TILE, 192, path.join(OUT, "color.png"));
  await square(SRC_OUTLINE, 32, path.join(OUT, "outline.png"), { pad: 0.08 });
  const logoOut = path.join(ROOT, "assets/logo/KSA_Logo_Full_FullColour.png");
  await sharp(fs.readFileSync(SRC_LOGO), { density: 600 }).resize({ width: 640 }).png().toFile(logoOut);
  console.log("wrote", path.relative(ROOT, logoOut));
}

main().catch((e) => { console.error(e); process.exit(1); });
