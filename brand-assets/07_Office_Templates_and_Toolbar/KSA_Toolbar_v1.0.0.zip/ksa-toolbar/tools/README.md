# tools

Scripts that build the KSA Toolbar asset catalogue. Nothing here runs in the add-in; the add-in only reads the
files these scripts write under `assets/`.

| Script | Purpose |
| --- | --- |
| `build-library.py` | Copies and generates everything under `assets/` (except templates, Word layouts and fonts) and writes `assets/library.json`. |
| `rasterise.js` | Batch SVG/PNG to PNG with `sharp`. Called by `build-library.py`; can be run on its own with a job file. |
| `check-library.py` | Validates `assets/library.json`: schema, unique ids, referenced files, counts per category, size. |
| `make-templates/` | Owned by the templates contributor: pptxgenjs / docx-js scripts plus the two index files described below. |
| `set-base-url.py <url>` | Rewrites the add-in base URL in the three manifests (and `validDomains` in `manifest.json`). Idempotent. |
| `check-manifests.py` | Static checks for the manifests: well-formed XML, resid references, unique ids, string lengths, local files, JSON lint. |
| `serve.js` | Zero-dependency HTTPS dev server for the folder (HTTP fallback when no certificate; see its header). |
| `package-release.sh` | Zips the deployable site as `KSA_Toolbar_v<version>.zip`, excluding caches. |

## Rebuild

```bash
cd ksa-toolbar
python3 tools/build-library.py            # full build, about 40 s (2,350 previews)
python3 tools/check-library.py            # validate; exit code 1 on errors
```

Requirements: Python 3.8+ (standard library only), Node 18+ and the `sharp` package (resolved from the project or from
`/opt/npm-tools/node_modules`). Fonts for the previews are read from `assets/fonts` through a temporary fontconfig file, so
badges and stamps render in Archivo and Source Serif 4 without installing anything.

Options:

```
--source S         the folder holding the brand material (icons/, ind/, vg/); defaults to two levels above ROOT
--only a,b         rebuild only some sections: logo, icons, industry, patterns, shapes, slides, effects
                   ("slides" covers charts, diagrams, infographics, layouts, report-layouts and templates)
--skip-raster      write the catalogue without regenerating previews
```

Partial builds keep the untouched sections' items from the existing `library.json`.

## What the build writes

| Folder | Contents | Source |
| --- | --- | --- |
| `assets/logo/png`, `assets/logo/preview` | 1024 px PNG and 240 px preview of every logo SVG | the SVGs already in `assets/logo` |
| `assets/icons/svg/<variant>`, `png/<variant>`, `preview` | 48 icons x 6 variants (duotone, duotone-reversed, line-deep, line-black, line-white, badge), 256 px PNGs, 96 px previews | `S/icons/out/KSA_Monogram_and_Icons/02_Icons` |
| `assets/industry-icons/<slug>/svg/{duotone,line}`, `preview` | 45 industries x 48 icons, duotone and Line_DeepCurrent only, 96 px previews | `S/ind/out/KSA_Industry_Icons` + `KSA_Industry_Icon_Index.csv` |
| `assets/patterns/<slug>` | tile SVG, 1920x1080 PNG and 320 px preview for 11 patterns x 6 colourways | `S/vg/out/KSA_Brand_Patterns` |
| `assets/shapes/svg`, `preview` | generated editable SVG shapes (blades, stem, delta, chevron wake, rules, dividers, labels, cluster badges, stamps, markers) | generated in `shape_defs()` from the identifier geometry |
| `assets/effects` | `presets.json`, `blade-crop-mask.svg`, previews | generated; presets mirror `src/modules/brand.js` BRAND_PRESETS |
| `assets/library.json` | the catalogue | everything above plus the index files |

Owned by others and never touched here: `assets/templates/*` (including `previews/`), `assets/layouts/word/*`, `assets/fonts`.

## Index files from the templates owner

`build-library.py` reads two optional files. When they exist they are the ONLY source for charts, diagrams, infographics,
layouts, effect demo slides and report layouts (the built-in fallback lists in the script are ignored). When they are missing it
prints a warning and uses the fallback lists (`CHARTS`, `DIAGRAMS`, `INFOGRAPHICS`, `LAYOUTS`, `REPORT_LAYOUTS`), with `preview`
pointing at `assets/templates/previews/<item id>.png`; the checker then lists those files as PENDING rather than errors.

Charts get an Excel `spec` from `CHART_SPECS` (keyed by id) or a guess from the id and name; add a key there for a new chart id.
Shape slides (`shape.*`) are not items of their own: their `slideIndex`, `sourceSlideIds` and `file` are attached to the matching
generated SVG shape through `SHAPE_SLIDE_ALIAS` (for example the six cluster badges all point at `shape.cluster-badge`); an
unmatched shape slide becomes a slide item. Effects keep the preset items (`spec` from BRAND_PRESETS) and the index's
`effect.*` demo slides are added beside them with `insert.powerpoint: "slide"`.

`tools/make-templates/slide-library-index.json`

```json
{ "file": "assets/templates/KSA_Slide_Library.pptx",
  "slides": [
    { "id": "chart.column", "slideIndex": 3, "sourceSlideIds": ["258"], "preview": "assets/templates/previews/chart.column.png" },
    { "id": "shape.badge-cluster-1", "slideIndex": [40] },
    { "id": "diagram.swot", "category": "diagrams", "name": "SWOT", "subcategory": "Matrices", "slideIndex": 27, "tags": ["swot"] }
  ] }
```

* `id` must match the item id (`chart.*`, `diagram.*`, `info.*`, `layout.*`, `shape.*`). Ids not in the built-in lists are added
  as new items (give them `category`, `name` and `subcategory`).
* `slideIndex` is 1-based, an int or a list. `sourceSlideIds` are the numeric sldId strings from `ppt/presentation.xml`.
  Either one switches the PowerPoint insert kind to `slide` with `file` set to the slide library.
* Optional overrides: `preview`, `name`, `subcategory`, `description`, `tags`, `spec`, `file`, `hosts`, `note`, `badge`.
* A plain list of entries, or `items` / `entries` instead of `slides`, is accepted too.

`tools/make-templates/report-layouts-index.json` has the same shape with a `blocks` list, ids `report.*`, optional `file`
(default `assets/layouts/word/<id>.xml`), `preview`, `page` and `fullPage` (shown as a "Full page" badge).

Previews are taken from each index entry's `preview`. Template previews are looked up as `tpl.<id>.png`, `tpl-<id>.png` or
`tpl-<id without -pptx>.png` in `assets/templates/previews/`; the email template preview is rendered from the HTML with Playwright
if none exists. Run `python3 tools/check-library.py --list-pending` for anything still missing.

## Catalogue conventions

* Ids: `logo.<set>.<version>`, `icon.<name>`, `ind.<industry slug>.<icon key>`, `pattern.<slug>.<theme>`, `shape.<id>`,
  `chart.<id>`, `diagram.<id>`, `info.<id>`, `layout.<id>`, `report.<id>`, `effect.<id>`, `tpl.<id>`.
* Items are sorted by category (fixed order), then subcategory, then name.
* `dark: true` marks items drawn for dark backgrounds (reversed and white logos, dark pattern colourways); the pane shows them on
  Deep Current.
* `featured: true` puts an item on the Home screen.
* `subcategory` becomes the chip row in each category (icon groups, industries, pattern families, shape families).
* Tags are kept short (at most eight words) so `library.json` stays under 2 MB with the 2,160 industry icons included.
