#!/usr/bin/env python3
"""Rewrite the add-in base URL in every manifest.

The manifests ship with the placeholder https://ksa-toolbar.kayaksa.com. Run this once with the real origin
(and optional path prefix) of the static host, for example:

    python3 tools/set-base-url.py https://kayaksa.github.io/ksa-toolbar
    python3 tools/set-base-url.py https://localhost:3000            # local dev server (tools/serve.js)

It is safe to run again later with another URL: the current base is read from manifest/manifest.xml
(the DefaultSettings SourceLocation, minus /src/taskpane.html), so every manifest is rewritten consistently.
It also updates the matching entry in manifest.json "validDomains" when the host name changes.
Standard library only. Exit code 1 when nothing could be rewritten.
"""
import json
import os
import re
import sys
from urllib.parse import urlparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FILES = ["manifest/manifest.xml", "manifest/manifest-outlook.xml", "manifest/manifest.json"]
PLACEHOLDER = "https://ksa-toolbar.kayaksa.com"


def current_base():
    xml = open(os.path.join(ROOT, "manifest/manifest.xml"), encoding="utf-8").read()
    m = re.search(r'<SourceLocation DefaultValue="([^"]+)/src/taskpane\.html"', xml)
    if not m:
        sys.exit("could not find the DefaultSettings SourceLocation in manifest/manifest.xml")
    return m.group(1)


def main():
    if len(sys.argv) != 2 or not sys.argv[1].startswith("http"):
        print(__doc__)
        sys.exit(2)
    new = sys.argv[1].rstrip("/")
    u = urlparse(new)
    if u.scheme != "https" and u.hostname not in ("localhost", "127.0.0.1"):
        print("warning: Office requires HTTPS for add-in pages; only localhost may use http")
    old = current_base()
    if old == new:
        print(f"base URL is already {new}")
        return
    old_host = urlparse(old).hostname
    total = 0
    for rel in FILES:
        path = os.path.join(ROOT, rel)
        text = open(path, encoding="utf-8").read()
        n = text.count(old)
        text = text.replace(old, new)
        if rel.endswith(".json"):
            data = json.loads(text)
            domains = data.get("validDomains", [])
            if old_host in domains:
                domains[domains.index(old_host)] = u.hostname
                n += 1
            elif u.hostname not in domains:
                domains.insert(0, u.hostname)
                n += 1
            text = json.dumps(data, indent=2, ensure_ascii=False) + "\n"
        open(path, "w", encoding="utf-8").write(text)
        print(f"{rel}: {n} replacement(s)")
        total += n
    if total == 0:
        sys.exit(1)
    print(f"base URL set to {new} (was {old})")
    if old == PLACEHOLDER:
        print("next: rebuild the Teams package with python3 teams/build-package.py")


if __name__ == "__main__":
    main()
