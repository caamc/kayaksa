#!/usr/bin/env node
/* serve.js: zero-dependency dev server for the KSA Toolbar static site (ROOT = one level above this file).
 *
 *   node tools/serve.js                 HTTPS on https://localhost:3000 when a certificate is found, otherwise HTTP
 *   PORT=8443 node tools/serve.js       another port
 *   KSA_CERT=path KSA_KEY=path ...      certificate and key (PEM); default tools/certs/localhost.crt and .key
 *
 * Office loads add-in pages only over HTTPS (except http://localhost in some hosts), so make a certificate first:
 *
 *   mkdir -p tools/certs && openssl req -x509 -newkey rsa:2048 -nodes -days 825 \
 *     -keyout tools/certs/localhost.key -out tools/certs/localhost.crt -subj "/CN=localhost" \
 *     -addext "subjectAltName=DNS:localhost,IP:127.0.0.1"
 *
 * then trust tools/certs/localhost.crt (Windows: double-click > Install > Trusted Root Certification Authorities;
 * macOS: Keychain Access > System > import > Always Trust). The office-addin-dev-certs npm package does the same job
 * (npx office-addin-dev-certs install) and writes to ~/.office-addin-dev-certs/localhost.crt and localhost.key;
 * point KSA_CERT and KSA_KEY at those files to reuse them.
 *
 * Serves files with the right MIME types, CORS (*), no caching, byte ranges for media, and a directory listing
 * for folders without index.html. Paths outside ROOT are refused.
 */
"use strict";
const fs = require("fs");
const path = require("path");
const http = require("http");
const https = require("https");
const os = require("os");

const ROOT = path.resolve(__dirname, "..");
const PORT = Number(process.env.PORT || 3000);
const CERT = process.env.KSA_CERT || path.join(__dirname, "certs", "localhost.crt");
const KEY = process.env.KSA_KEY || path.join(__dirname, "certs", "localhost.key");

const MIME = {
  ".html": "text/html; charset=utf-8", ".htm": "text/html; charset=utf-8", ".css": "text/css; charset=utf-8",
  ".js": "text/javascript; charset=utf-8", ".mjs": "text/javascript; charset=utf-8", ".json": "application/json; charset=utf-8",
  ".map": "application/json; charset=utf-8", ".xml": "application/xml; charset=utf-8", ".txt": "text/plain; charset=utf-8",
  ".md": "text/markdown; charset=utf-8", ".csv": "text/csv; charset=utf-8", ".svg": "image/svg+xml", ".png": "image/png",
  ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif", ".webp": "image/webp", ".ico": "image/x-icon",
  ".avif": "image/avif", ".woff": "font/woff", ".woff2": "font/woff2", ".ttf": "font/ttf", ".otf": "font/otf",
  ".eot": "application/vnd.ms-fontobject", ".mp4": "video/mp4", ".webm": "video/webm", ".mp3": "audio/mpeg",
  ".wasm": "application/wasm", ".pdf": "application/pdf", ".zip": "application/zip",
  ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
  ".potx": "application/vnd.openxmlformats-officedocument.presentationml.template",
  ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  ".dotx": "application/vnd.openxmlformats-officedocument.wordprocessingml.template",
  ".xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  ".thmx": "application/vnd.ms-officetheme",
};

function send(res, status, body, headers) {
  res.writeHead(status, Object.assign({ "Content-Type": "text/plain; charset=utf-8" }, headers || {}));
  res.end(body);
}

function listing(dir, urlPath) {
  const entries = fs.readdirSync(dir, { withFileTypes: true }).sort((a, b) => a.name.localeCompare(b.name));
  const rows = entries.map((e) => {
    const name = e.name + (e.isDirectory() ? "/" : "");
    return `<li><a href="${encodeURIComponent(e.name)}${e.isDirectory() ? "/" : ""}">${name}</a></li>`;
  });
  return `<!doctype html><meta charset="utf-8"><title>${urlPath}</title>` +
    `<style>body{font:14px/1.5 Archivo,"Segoe UI",Arial,sans-serif;margin:24px;color:#0E2F3C}a{color:#17807E}</style>` +
    `<h1>${urlPath}</h1><ul>${urlPath !== "/" ? '<li><a href="../">../</a></li>' : ""}${rows.join("")}</ul>`;
}

function handler(req, res) {
  const headers = {
    "Access-Control-Allow-Origin": "*",
    "Access-Control-Allow-Methods": "GET, HEAD, OPTIONS",
    "Access-Control-Allow-Headers": "*",
    "Cache-Control": "no-store",
  };
  if (req.method === "OPTIONS") return send(res, 204, "", headers);
  if (req.method !== "GET" && req.method !== "HEAD") return send(res, 405, "Method not allowed", headers);

  let urlPath;
  try { urlPath = decodeURIComponent(new URL(req.url, "http://x").pathname); }
  catch { return send(res, 400, "Bad request", headers); }
  const file = path.normalize(path.join(ROOT, urlPath));
  if (!file.startsWith(ROOT)) return send(res, 403, "Forbidden", headers);

  let stat;
  try { stat = fs.statSync(file); } catch { return send(res, 404, `Not found: ${urlPath}`, headers); }

  if (stat.isDirectory()) {
    if (!urlPath.endsWith("/")) return send(res, 301, "", Object.assign({ Location: urlPath + "/" }, headers));
    const index = path.join(file, "index.html");
    if (fs.existsSync(index)) return stream(req, res, index, fs.statSync(index), headers);
    return send(res, 200, listing(file, urlPath), Object.assign({ "Content-Type": "text/html; charset=utf-8" }, headers));
  }
  return stream(req, res, file, stat, headers);
}

function stream(req, res, file, stat, headers) {
  const type = MIME[path.extname(file).toLowerCase()] || "application/octet-stream";
  const h = Object.assign({ "Content-Type": type, "Accept-Ranges": "bytes" }, headers);
  const range = /^bytes=(\d*)-(\d*)$/.exec(req.headers.range || "");
  let start = 0, end = stat.size - 1, status = 200;
  if (range && stat.size > 0) {
    start = range[1] ? Number(range[1]) : Math.max(0, stat.size - Number(range[2]));
    end = range[1] && range[2] ? Math.min(Number(range[2]), stat.size - 1) : end;
    if (start > end || start >= stat.size) return send(res, 416, "", Object.assign({ "Content-Range": `bytes */${stat.size}` }, headers));
    status = 206; h["Content-Range"] = `bytes ${start}-${end}/${stat.size}`;
  }
  h["Content-Length"] = end - start + 1;
  res.writeHead(status, h);
  if (req.method === "HEAD") return res.end();
  fs.createReadStream(file, { start, end }).on("error", () => res.destroy()).pipe(res);
}

function start() {
  const haveCert = fs.existsSync(CERT) && fs.existsSync(KEY);
  let server, scheme;
  if (haveCert) {
    server = https.createServer({ cert: fs.readFileSync(CERT), key: fs.readFileSync(KEY) }, handler);
    scheme = "https";
  } else {
    server = http.createServer(handler);
    scheme = "http";
  }
  server.on("error", (e) => {
    if (e.code === "EADDRINUSE") console.error(`Port ${PORT} is in use. Set PORT=<number> to use another one.`);
    else console.error(e.message);
    process.exit(1);
  });
  server.listen(PORT, () => {
    console.log(`KSA Toolbar dev server: ${scheme}://localhost:${PORT}/  (root ${ROOT})`);
    if (haveCert) {
      console.log(`certificate ${CERT}`);
    } else {
      console.log("No certificate found, serving plain HTTP. Office requires HTTPS for add-in pages;");
      console.log("create tools/certs/localhost.crt and .key (see the comment at the top of tools/serve.js)");
      console.log("or set KSA_CERT and KSA_KEY, then restart.");
    }
    console.log(`task pane:  ${scheme}://localhost:${PORT}/src/taskpane.html?hub=1`);
    console.log(`preview:    ${scheme}://localhost:${PORT}/src/preview.html`);
    console.log(`manifests:  python3 tools/set-base-url.py ${scheme}://localhost:${PORT}`);
    const nets = Object.values(os.networkInterfaces()).flat().filter((n) => n && n.family === "IPv4" && !n.internal);
    if (nets.length) console.log(`on the LAN: ${nets.map((n) => `${scheme}://${n.address}:${PORT}/`).join("  ")}`);
  });
}

if (require.main === module) start();
module.exports = { handler, MIME };
