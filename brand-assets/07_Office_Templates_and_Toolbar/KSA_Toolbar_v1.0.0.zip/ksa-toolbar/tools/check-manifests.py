#!/usr/bin/env python3
"""Static checks for the three manifests (no network, standard library only).

XML manifests: well-formed; every resid references a defined resource of the right kind; ids of Controls, Groups
and resources unique per VersionOverrides; ShortString <= 125, LongString <= 250, DisplayName <= 125,
Description <= 250; URLs absolute https; Version is four numbers; same Id in every manifest; referenced local
files (icons, pages) exist under ROOT. JSON manifest: parses; id, icons, lengths, actionId references, unique ids.
Exit code 1 on any error.
"""
import json
import os
import re
import sys
import xml.etree.ElementTree as ET
from urllib.parse import urlparse

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
NS_BT = "http://schemas.microsoft.com/office/officeappbasictypes/1.0"
LIMITS = {"ShortStrings": 125, "LongStrings": 250}
errors, notes = [], []


def err(msg): errors.append(msg)


def local(tag): return tag.split("}", 1)[1] if "}" in tag else tag


def check_local_file(url, where):
    """Every URL on the placeholder host must map to an existing file under ROOT."""
    u = urlparse(url)
    if u.scheme != "https" and u.hostname not in ("localhost", "127.0.0.1"):
        err(f"{where}: not https: {url}")
    path = os.path.join(ROOT, u.path.lstrip("/"))
    if u.hostname == "ksa-toolbar.kayaksa.com" and not os.path.exists(path):
        err(f"{where}: {u.path} does not exist under ROOT")


def check_xml(path):
    name = os.path.basename(path)
    try:
        tree = ET.parse(path)
    except ET.ParseError as e:
        err(f"{name}: not well-formed: {e}")
        return None
    root = tree.getroot()
    app_id = root.findtext("{http://schemas.microsoft.com/office/appforoffice/1.1}Id")
    version = root.findtext("{http://schemas.microsoft.com/office/appforoffice/1.1}Version")
    if not re.fullmatch(r"\d+\.\d+\.\d+\.\d+", version or ""):
        err(f"{name}: Version must be four numbers, got {version}")
    for el in root.iter():
        t = local(el.tag)
        if t == "DisplayName" and len(el.get("DefaultValue", "")) > 125:
            err(f"{name}: DisplayName longer than 125")
        if t == "Description" and el.get("DefaultValue") is not None and len(el.get("DefaultValue")) > 250:
            err(f"{name}: Description longer than 250")
        for attr in ("DefaultValue",):
            v = el.get(attr)
            if v and v.startswith("http") and t in ("IconUrl", "HighResolutionIconUrl", "SourceLocation", "Url", "Image"):
                check_local_file(v, f"{name}:{t}")
    # every VersionOverrides (nested included) has its own Resources scope
    for vo in [e for e in root.iter() if local(e.tag) == "VersionOverrides"]:
        res = {}
        kinds = {}
        direct_children = list(vo)
        resources = [c for c in direct_children if local(c.tag) == "Resources"]
        if not resources:
            err(f"{name}: VersionOverrides without Resources")
            continue
        for group in resources[0]:
            g = local(group.tag)
            for r in group:
                rid = r.get("id")
                if rid in res:
                    err(f"{name}: duplicate resource id {rid}")
                res[rid] = r.get("DefaultValue", "")
                kinds[rid] = g
                if g in LIMITS and len(res[rid]) > LIMITS[g]:
                    err(f"{name}: {g} {rid} is {len(res[rid])} chars (max {LIMITS[g]})")
                if g in ("Images", "Urls"):
                    check_local_file(res[rid], f"{name}:{rid}")
        # references: walk this VersionOverrides but not nested ones
        def walk(el, depth=0):
            for c in el:
                if local(c.tag) == "VersionOverrides":
                    continue
                yield c
                yield from walk(c, depth + 1)
        ids = {}
        expect = {"Label": "ShortStrings", "Title": "ShortStrings", "Description": "LongStrings",
                  "Image": "Images", "SourceLocation": "Urls", "FunctionFile": "Urls", "Runtime": "Urls",
                  "LearnMoreUrl": "Urls", "Page": "Urls", "Script": "Urls"}
        for el in walk(vo):
            t = local(el.tag)
            resid = el.get("resid")
            if resid is not None:
                if resid not in res:
                    err(f"{name}: {t} references undefined resid {resid}")
                elif t in expect and kinds[resid] != expect[t]:
                    err(f"{name}: {t} resid {resid} is a {kinds[resid]} resource, expected {expect[t]}")
            if t in ("Control", "Group", "CustomTab", "OfficeTab"):
                cid = el.get("id")
                key = (t if t != "OfficeTab" else "CustomTab", cid)
                if not cid:
                    err(f"{name}: {t} without id")
                elif key in ids:
                    # a CustomTab id repeats per host by design (one ribbon per host); Controls and Groups must not
                    if t != "CustomTab":
                        err(f"{name}: duplicate {t} id {cid}")
                ids[key] = True
                if cid and len(cid) > 125:
                    err(f"{name}: {t} id {cid} longer than 125")
            if t == "Control" and el.get(f"{{http://www.w3.org/2001/XMLSchema-instance}}type") == "Button":
                children = [local(c.tag) for c in el]
                if children[:4] != ["Label", "Supertip", "Icon", "Action"]:
                    err(f"{name}: Button {el.get('id')} children order {children}, expected Label, Supertip, Icon, Action")
            if t == "Icon":
                sizes = sorted(int(c.get("size")) for c in el)
                if sizes != [16, 32, 80]:
                    err(f"{name}: Icon sizes {sizes}, expected 16, 32, 80")
            if t == "Action" and el.get(f"{{http://www.w3.org/2001/XMLSchema-instance}}type") == "ShowTaskpane":
                if any(local(c.tag) == "TaskpaneId" for c in el):
                    notes.append(f"{name}: ShowTaskpane with TaskpaneId (not allowed with a shared runtime)")
        unused = [r for r in res if not any(e.get("resid") == r for e in walk(vo))]
        if unused:
            notes.append(f"{name}: unused resources {unused}")
    return app_id


def check_json(path):
    name = os.path.basename(path)
    try:
        m = json.load(open(path, encoding="utf-8"))
    except json.JSONDecodeError as e:
        err(f"{name}: invalid JSON: {e}")
        return None
    for key, limit in (("name.short", 30), ("name.full", 100), ("description.short", 80), ("description.full", 4000),
                       ("developer.name", 32)):
        a, b = key.split(".")
        if len(m.get(a, {}).get(b, "")) > limit:
            err(f"{name}: {key} longer than {limit}")
    if not re.fullmatch(r"[0-9a-f-]{36}", m.get("id", "")):
        err(f"{name}: id is not a GUID")
    for k in ("color", "outline"):
        if not os.path.exists(os.path.join(ROOT, "manifest", "icons", m["icons"][k])):
            err(f"{name}: icons.{k} file missing")
    for ext in m.get("extensions", []):
        actions = {}
        for rt in ext.get("runtimes", []):
            for a in rt.get("actions", []):
                if a["id"] in actions:
                    err(f"{name}: duplicate action id {a['id']}")
                actions[a["id"]] = a["type"]
            for k in ("page", "script"):
                if rt.get("code", {}).get(k):
                    check_local_file(rt["code"][k], f"{name}:runtime {rt['id']} {k}")
        seen = set()
        for rib in ext.get("ribbons", []):
            for tab in rib.get("tabs", []):
                for key in (("tab", tab["id"]),):
                    if key in seen: err(f"{name}: duplicate tab id {tab['id']}")
                    seen.add(key)
                if len(tab.get("label", "")) > 64: err(f"{name}: tab label {tab['id']} longer than 64")
                for g in tab.get("groups", []):
                    if ("group", g["id"]) in seen: err(f"{name}: duplicate group id {g['id']}")
                    seen.add(("group", g["id"]))
                    if len(g.get("label", "")) > 64: err(f"{name}: group label {g['id']} longer than 64")
                    for c in g.get("controls", []):
                        if ("control", c["id"]) in seen: err(f"{name}: duplicate control id {c['id']}")
                        seen.add(("control", c["id"]))
                        if c.get("actionId") not in actions:
                            err(f"{name}: control {c['id']} references unknown actionId {c.get('actionId')}")
                        if len(c.get("label", "")) > 64: err(f"{name}: control label {c['id']} longer than 64")
                        st = c.get("supertip", {})
                        if len(st.get("title", "")) > 64: err(f"{name}: supertip title {c['id']} longer than 64")
                        if len(st.get("description", "")) > 250: err(f"{name}: supertip description {c['id']} longer than 250")
                        if sorted(i["size"] for i in c.get("icons", [])) != [16, 32, 80]:
                            err(f"{name}: control {c['id']} icons must be 16, 32, 80")
                        for i in c.get("icons", []): check_local_file(i["url"], f"{name}:{c['id']} icon")
                    for i in g.get("icons", []): check_local_file(i["url"], f"{name}:{g['id']} icon")
    for t in m.get("staticTabs", []):
        check_local_file(t["contentUrl"], f"{name}:staticTab {t['entityId']}")
        host = urlparse(t["contentUrl"]).hostname
        if host not in m.get("validDomains", []):
            err(f"{name}: staticTab host {host} missing from validDomains")
    return m.get("id")


ids = {
    "manifest.xml": check_xml(os.path.join(ROOT, "manifest", "manifest.xml")),
    "manifest-outlook.xml": check_xml(os.path.join(ROOT, "manifest", "manifest-outlook.xml")),
    "manifest.json": check_json(os.path.join(ROOT, "manifest", "manifest.json")),
}
if len(set(ids.values())) != 1:
    err(f"add-in ids differ: {ids}")

for n in notes:
    print("note:", n)
for e in errors:
    print("error:", e)
print(f"{len(errors)} error(s); add-in id {ids['manifest.xml']}")
sys.exit(1 if errors else 0)
