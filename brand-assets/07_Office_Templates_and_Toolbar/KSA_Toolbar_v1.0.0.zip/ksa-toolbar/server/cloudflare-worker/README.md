# KSA Assistant proxy (Cloudflare Worker)

A small Worker that sits between the KSA Toolbar add-in and the Anthropic Messages API. The API key lives only here, as a Worker secret. The add-in sends the conversation plus the current selection; the Worker adds the KSA system prompt, calls the model, extracts any structured actions and returns `{ reply, actions, usage }`. It stores nothing.

## Deploy in five minutes

Prerequisites: Node 18+ and a Cloudflare account (the free plan is enough).

```bash
cd server/cloudflare-worker
npm install                                 # installs wrangler locally
npx wrangler login                          # opens the browser once
npx wrangler secret put ANTHROPIC_API_KEY   # paste your key (sk-ant-...)
npx wrangler secret put ASSISTANT_TOKEN     # optional: any long random string
npx wrangler deploy
```

`deploy` prints a URL such as `https://ksa-assistant.<account>.workers.dev`. Check it:

```bash
curl https://ksa-assistant.<account>.workers.dev/health
# {"ok":true,"service":"ksa-assistant","model":"claude-sonnet-4-5","auth":true,"keyConfigured":true}
```

Then in the add-in: **Settings → Assistant endpoint** = that URL (no trailing `/chat`), and **Assistant access token** = the value you gave `ASSISTANT_TOKEN` (leave blank if you did not set one). Save, open the **KSA Assistant** tab and ask a question.

## Configuration

| Where | Name | Purpose |
|---|---|---|
| secret | `ANTHROPIC_API_KEY` | Required. Never goes to the add-in and is never logged. |
| secret | `ASSISTANT_TOKEN` | Optional shared token. When set, every request must carry `Authorization: Bearer <token>`. |
| `wrangler.toml` `[vars]` | `MODEL` | Model id (default `claude-sonnet-4-5`, from `src/config.js`). Change it here only. |
| `wrangler.toml` `[vars]` | `ALLOWED_ORIGINS` | `*` (default) or a comma-separated list of exact origins, e.g. `https://toolbar.kayaksa.com`. Other origins get 403 and no CORS headers. |

Request limits live in `src/config.js` (`LIMITS`): 40 messages, 500 × 30 context rows, 60k characters of context, 6 actions of at most 200 × 30 cells. `max_tokens` is 2000 and the upstream call times out after 55 s.

## Local run

```bash
npx wrangler dev          # http://localhost:8787
```

Put `ANTHROPIC_API_KEY=...` in a `.dev.vars` file (git-ignored) for local secrets. If you just want to click around the UI without a key, run the mock instead: `node tools/mock-assistant.js` from the repository root (same port, canned replies).

## API

`POST /chat` with JSON:

```json
{ "messages": [ { "role": "user", "content": "Summarise this data" } ],
  "context": { "host": "excel",
               "selection": { "kind": "range", "address": "B2:F14", "rowCount": 13, "colCount": 5, "sampled": false, "rows": [["Region","FY24"],["North",120]] },
               "settings": { "userName": "[Full Name]" } },
  "actions": true }
```

Response: `{ "reply": "markdown-lite text", "actions": [ { "type": "excel.chart", ... } ], "usage": { "input_tokens": 1, "output_tokens": 1 } }`.
Errors are always JSON: `{ "error": { "code": "unauthorised", "message": "..." } }` with a matching HTTP status.

`GET /health` returns the model id and whether the key and token are configured (never their values).

## Files

- `src/index.js` routing, CORS, auth, error envelope
- `src/assistant-core.js` validation, Anthropic call, actions parsing (copied verbatim into `../azure-function/shared/`; keep the two in sync)
- `src/system-prompt.js` the KSA system prompt and context serialiser
- `src/config.js` model id, limits, timeouts
