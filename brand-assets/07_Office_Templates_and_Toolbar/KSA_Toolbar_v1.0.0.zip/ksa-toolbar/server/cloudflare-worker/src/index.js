/* index.js — KSA Assistant proxy as a Cloudflare Worker (ES module).
 * Routes: POST /chat, GET /health, OPTIONS (CORS preflight).
 * Secrets: ANTHROPIC_API_KEY (required), ASSISTANT_TOKEN (optional shared secret the add-in sends as a Bearer token).
 * Vars:    MODEL (default in config.js), ALLOWED_ORIGINS ("*" or a comma-separated list of origins). */
import { DEFAULT_MODEL } from "./config.js";
import { HttpError, validateRequest, callAnthropic, parseReply, corsHeaders, checkToken, errorBody } from "./assistant-core.js";

export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const origin = request.headers.get("Origin") || "";
    const cors = corsHeaders(origin, env.ALLOWED_ORIGINS);
    const json = (status, body) => new Response(JSON.stringify(body), { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...cors.headers } });

    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors.headers });
    if (!cors.allowed) return json(403, errorBody("origin_not_allowed", "This origin is not allowed to use the assistant proxy."));

    if (url.pathname === "/health" && request.method === "GET") {
      return json(200, { ok: true, service: "ksa-assistant", model: env.MODEL || DEFAULT_MODEL, auth: !!env.ASSISTANT_TOKEN, keyConfigured: !!env.ANTHROPIC_API_KEY });
    }
    if (url.pathname !== "/chat") return json(404, errorBody("not_found", "Use POST /chat or GET /health."));
    if (request.method !== "POST") return json(405, errorBody("method_not_allowed", "Use POST for /chat."));
    if (!checkToken(request.headers.get("Authorization"), env.ASSISTANT_TOKEN)) return json(401, errorBody("unauthorised", "The access token is missing or wrong. Set it in the add-in Settings."));

    try {
      let body;
      try { body = await request.json(); } catch { throw new HttpError(400, "bad_request", "The request body must be JSON."); }
      const { messages, context } = validateRequest(body);
      const model = env.MODEL || DEFAULT_MODEL;
      const upstream = await callAnthropic({ apiKey: env.ANTHROPIC_API_KEY, model, messages, context });
      const { reply, actions } = parseReply(upstream.text, context.host);
      return json(200, { reply, actions: body.actions === false ? [] : actions, usage: upstream.usage, model: upstream.model });
    } catch (e) {
      if (e instanceof HttpError) return json(e.status, errorBody(e.code, e.message));
      console.error("unhandled", String(e?.message || e).slice(0, 200));
      return json(500, errorBody("internal", "Something went wrong in the assistant proxy."));
    }
  },
};
