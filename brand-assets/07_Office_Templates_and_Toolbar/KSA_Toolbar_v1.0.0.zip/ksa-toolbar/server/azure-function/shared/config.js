/* config.js — the only place a model id lives. Override at deploy time with the MODEL variable (wrangler.toml [vars]). */
export const DEFAULT_MODEL = "claude-sonnet-4-5";
export const ANTHROPIC_URL = "https://api.anthropic.com/v1/messages";
export const ANTHROPIC_VERSION = "2023-06-01";
export const MAX_TOKENS = 2000;
export const UPSTREAM_TIMEOUT_MS = 55000;

/* Request and response caps (keep prompts bounded and actions safe to execute). */
export const LIMITS = {
  messages: 40,            // 20 turns
  messageChars: 24000,
  contextRows: 500,
  contextCols: 30,
  contextChars: 60000,     // serialised selection sent to the model
  textChars: 20000,        // Word / Outlook / PowerPoint text
  actions: 6,
  actionRows: 200,
  actionCols: 30,
  actionCell: 200,
  actionText: 20000,
  actionShort: 400,
};
