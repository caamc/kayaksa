/* assistant-core.js — request validation, Anthropic call, reply parsing and action validation.
 * Pure functions, no secrets: shared verbatim by the Cloudflare Worker and the Azure Function (server/azure-function/shared/). */
import { ANTHROPIC_URL, ANTHROPIC_VERSION, MAX_TOKENS, UPSTREAM_TIMEOUT_MS, LIMITS } from "./config.js";
import { buildSystemPrompt } from "./system-prompt.js";

export class HttpError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}

/* ---------- inbound validation ---------- */
export function validateRequest(body) {
  if (!body || typeof body !== "object") throw new HttpError(400, "bad_request", "Send a JSON body with messages and context.");
  const raw = Array.isArray(body.messages) ? body.messages : null;
  if (!raw || !raw.length) throw new HttpError(400, "bad_request", "messages must be a non-empty array.");
  const messages = [];
  for (const m of raw.slice(-LIMITS.messages)) {
    const role = m?.role === "assistant" ? "assistant" : m?.role === "user" ? "user" : null;
    const content = typeof m?.content === "string" ? m.content.trim() : "";
    if (!role || !content) continue;
    const text = content.length > LIMITS.messageChars ? content.slice(0, LIMITS.messageChars) + " [truncated]" : content;
    // Anthropic requires alternating roles starting with user; merge same-role neighbours.
    const last = messages[messages.length - 1];
    if (last && last.role === role) last.content += "\n\n" + text; else messages.push({ role, content: text });
  }
  while (messages.length && messages[0].role !== "user") messages.shift();
  if (!messages.length) throw new HttpError(400, "bad_request", "No user message found.");
  if (messages[messages.length - 1].role !== "user") messages.pop();
  return { messages, context: normaliseContext(body.context) };
}

function str(v, max) { return typeof v === "string" ? v.slice(0, max) : typeof v === "number" ? String(v) : ""; }
function cellValue(v) { return typeof v === "number" && isFinite(v) ? v : typeof v === "boolean" ? v : str(v, LIMITS.actionCell); }
function rows2d(v, maxRows, maxCols) {
  if (!Array.isArray(v)) return [];
  return v.slice(0, maxRows).map((r) => (Array.isArray(r) ? r : [r]).slice(0, maxCols).map(cellValue));
}

export function normaliseContext(c) {
  const host = ["excel", "powerpoint", "word", "outlook", "hub"].includes(c?.host) ? c.host : "hub";
  const s = c?.selection && typeof c.selection === "object" ? c.selection : { kind: "none" };
  const out = { host, settings: { userName: str(c?.settings?.userName, 80) }, selection: { kind: "none" } };
  switch (s.kind) {
    case "range":
      out.selection = { kind: "range", address: str(s.address, 60), sheet: str(s.sheet, 60), rowCount: Number(s.rowCount) || 0, colCount: Number(s.colCount) || 0, sampled: !!s.sampled, rows: rows2d(s.rows, LIMITS.contextRows, LIMITS.contextCols) };
      break;
    case "text":
      out.selection = { kind: "text", source: s.source === "document" ? "document" : "selection", words: Number(s.words) || 0, text: str(s.text, LIMITS.textChars) };
      break;
    case "shapes":
      out.selection = {
        kind: "shapes", slide: Number(s.slide) || null, scope: s.scope === "slide" ? "slide" : "selection",
        shapes: (Array.isArray(s.shapes) ? s.shapes : []).slice(0, 40).map((x) => ({ name: str(x?.name, 80), type: str(x?.type, 40), text: str(x?.text, LIMITS.textChars) })),
        tables: (Array.isArray(s.tables) ? s.tables : []).slice(0, 10).map((t) => ({ name: str(t?.name, 80), rows: rows2d(t?.rows, LIMITS.contextRows, LIMITS.contextCols) })),
      };
      break;
    case "message":
      out.selection = { kind: "message", subject: str(s.subject, 300), text: str(s.text, LIMITS.textChars) };
      break;
    default:
      break;
  }
  return out;
}

/* ---------- upstream call ---------- */
export async function callAnthropic({ apiKey, model, messages, context, fetchImpl = fetch }) {
  if (!apiKey) throw new HttpError(500, "not_configured", "The proxy has no ANTHROPIC_API_KEY secret. Ask whoever deployed it to set one.");
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), UPSTREAM_TIMEOUT_MS);
  let res;
  try {
    res = await fetchImpl(ANTHROPIC_URL, {
      method: "POST",
      headers: { "content-type": "application/json", "x-api-key": apiKey, "anthropic-version": ANTHROPIC_VERSION },
      body: JSON.stringify({ model, max_tokens: MAX_TOKENS, system: buildSystemPrompt(context, LIMITS), messages }),
      signal: controller.signal,
    });
  } catch (e) {
    if (e?.name === "AbortError") throw new HttpError(504, "upstream_timeout", "The model took too long to answer. Try a smaller selection or ask again.");
    throw new HttpError(502, "upstream_unreachable", "The proxy could not reach the model service.");
  } finally { clearTimeout(timer); }

  if (!res.ok) {
    let detail = "";
    try { detail = (await res.json())?.error?.message || ""; } catch { /* ignore */ }
    const friendly = {
      400: "The request was rejected by the model service" + (detail ? ": " + detail : "."),
      401: "The proxy's API key was rejected. Check the ANTHROPIC_API_KEY secret.",
      403: "The proxy's API key is not allowed to use this model.",
      404: "The configured model id was not found. Check the MODEL variable.",
      413: "The selection is too large for one request. Select fewer rows.",
      429: "The assistant is busy right now. Wait a moment and try again.",
      529: "The model service is overloaded. Try again shortly.",
    }[res.status] || "The model service returned an error. Try again shortly.";
    console.error("anthropic error", res.status, detail.slice(0, 200)); // status + message only; never the key
    throw new HttpError(res.status === 429 ? 429 : 502, "upstream_error", friendly);
  }
  const data = await res.json();
  const text = (data.content || []).filter((b) => b.type === "text").map((b) => b.text).join("\n");
  const usage = data.usage ? { input_tokens: data.usage.input_tokens, output_tokens: data.usage.output_tokens } : undefined;
  return { text, usage, model: data.model, stop_reason: data.stop_reason };
}

/* ---------- reply parsing and action validation ---------- */
const ACTIONS_RE = /```actions\s*([\s\S]*?)```/i;
const ENUMS = {
  chartType: ["column", "bar", "line", "donut", "doughnut", "area", "stackedColumn", "stackedBar"],
  style: ["standfirst", "body", "bullets", "heading"],
};
/* field: s = short string, t = long text, r = rows, n = number, b = boolean, e:<enum> = enum, o:thresholds = {green, amber}. "!" = required. */
const SCHEMA = {
  "excel.chart": { chartType: "e:chartType", title: "s", highlight: "s", range: "s", rows: "r" },
  "excel.table": { rows: "r!", range: "s" },
  "excel.rag": { range: "s", thresholds: "o:thresholds", higherIsBetter: "b" },
  "ppt.exhibit": { title: "s!", subtitle: "s", source: "s", rows: "r", chartType: "e:chartType", number: "n" },
  "ppt.title": { text: "s!" },
  "word.insert": { text: "t", html: "t", style: "e:style" },
  "word.replace": { text: "t!" },
  "outlook.insert": { text: "t", html: "t" },
  copy: { text: "t!" },
};
const HOST_PREFIX = { excel: "excel", powerpoint: "ppt", word: "word", outlook: "outlook" };

export function sanitiseAction(a, host) {
  if (!a || typeof a !== "object") return null;
  const type = String(a.type || "");
  const schema = SCHEMA[type];
  if (!schema) return null;
  if (type !== "copy" && host && HOST_PREFIX[host] !== type.split(".")[0]) return null;
  const out = { type };
  for (const [key, spec] of Object.entries(schema)) {
    const required = spec.endsWith("!");
    const kind = spec.replace("!", "");
    const v = a[key];
    let clean;
    if (v === undefined || v === null) clean = undefined;
    else if (kind === "s") clean = str(v, LIMITS.actionShort) || undefined;
    else if (kind === "t") clean = str(v, LIMITS.actionText) || undefined;
    else if (kind === "n") clean = Number.isFinite(Number(v)) ? Number(v) : undefined;
    else if (kind === "b") clean = typeof v === "boolean" ? v : undefined;
    else if (kind === "r") { clean = rows2d(v, LIMITS.actionRows, LIMITS.actionCols); if (!clean.length) clean = undefined; }
    else if (kind.startsWith("e:")) { const list = ENUMS[kind.slice(2)]; clean = list.includes(String(v)) ? String(v) : undefined; }
    else if (kind === "o:thresholds") { const g = Number(v?.green), am = Number(v?.amber); clean = Number.isFinite(g) && Number.isFinite(am) ? { green: g, amber: am } : undefined; }
    if (required && clean === undefined) return null;
    if (clean !== undefined) out[key] = clean;
  }
  if (type === "word.insert" && !out.text && !out.html) return null;
  if (type === "outlook.insert" && !out.text && !out.html) return null;
  if (a.label !== undefined) { const l = str(a.label, 40).trim(); if (l) out.label = l; }
  return out;
}

export function parseReply(text, host) {
  let reply = String(text || "");
  const actions = [];
  const m = reply.match(ACTIONS_RE);
  if (m) {
    reply = (reply.slice(0, m.index) + reply.slice(m.index + m[0].length)).trim();
    try {
      const parsed = JSON.parse(m[1].trim());
      const list = Array.isArray(parsed) ? parsed : parsed && typeof parsed === "object" ? [parsed] : [];
      for (const a of list.slice(0, LIMITS.actions)) { const clean = sanitiseAction(a, host); if (clean) actions.push(clean); }
    } catch (e) {
      console.warn("actions block was not valid JSON", String(e.message || e).slice(0, 120));
    }
  }
  return { reply: reply || "I could not produce a reply. Please try again.", actions };
}

/* ---------- CORS and auth ---------- */
export function corsHeaders(origin, allowedOrigins) {
  const list = String(allowedOrigins || "*").split(",").map((s) => s.trim()).filter(Boolean);
  const any = list.includes("*");
  const ok = any || (origin && list.includes(origin));
  const h = {
    "Access-Control-Allow-Methods": "POST, GET, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type, Authorization",
    "Access-Control-Max-Age": "86400",
  };
  if (any) h["Access-Control-Allow-Origin"] = "*";
  else if (ok) { h["Access-Control-Allow-Origin"] = origin; h.Vary = "Origin"; }
  return { headers: h, allowed: !!ok || !origin };
}

export function checkToken(authHeader, expected) {
  if (!expected) return true;
  const given = String(authHeader || "").replace(/^Bearer\s+/i, "").trim();
  if (given.length !== expected.length) return false;
  let diff = 0;
  for (let i = 0; i < expected.length; i++) diff |= given.charCodeAt(i) ^ expected.charCodeAt(i);
  return diff === 0;
}

export function errorBody(code, message) { return { error: { code, message } }; }
