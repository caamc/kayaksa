/* chat/index.js — KSA Assistant proxy as an Azure Function (HTTP trigger, Node 18+, ES module).
 * App settings: ANTHROPIC_API_KEY (required), ASSISTANT_TOKEN (optional), MODEL (optional), ALLOWED_ORIGINS (optional, default "*"). */
import { DEFAULT_MODEL } from "../shared/config.js";
import { HttpError, validateRequest, callAnthropic, parseReply, corsHeaders, checkToken, errorBody } from "../shared/assistant-core.js";

export default async function chat(context, req) {
  const env = process.env;
  const origin = req.headers?.origin || "";
  const cors = corsHeaders(origin, env.ALLOWED_ORIGINS);
  const reply = (status, body) => { context.res = { status, headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...cors.headers }, body: JSON.stringify(body) }; };

  if (req.method === "OPTIONS") { context.res = { status: 204, headers: cors.headers, body: "" }; return; }
  if (!cors.allowed) return reply(403, errorBody("origin_not_allowed", "This origin is not allowed to use the assistant proxy."));
  if (req.method !== "POST") return reply(405, errorBody("method_not_allowed", "Use POST for /chat."));
  if (!checkToken(req.headers?.authorization, env.ASSISTANT_TOKEN)) return reply(401, errorBody("unauthorised", "The access token is missing or wrong. Set it in the add-in Settings."));

  try {
    const body = typeof req.body === "string" ? safeJson(req.body) : req.body;
    if (!body) throw new HttpError(400, "bad_request", "The request body must be JSON.");
    const { messages, context: ctx } = validateRequest(body);
    const model = env.MODEL || DEFAULT_MODEL;
    const upstream = await callAnthropic({ apiKey: env.ANTHROPIC_API_KEY, model, messages, context: ctx });
    const parsed = parseReply(upstream.text, ctx.host);
    reply(200, { reply: parsed.reply, actions: body.actions === false ? [] : parsed.actions, usage: upstream.usage, model: upstream.model });
  } catch (e) {
    if (e instanceof HttpError) return reply(e.status, errorBody(e.code, e.message));
    context.log.error("unhandled", String(e?.message || e).slice(0, 200));
    reply(500, errorBody("internal", "Something went wrong in the assistant proxy."));
  }
}
function safeJson(s) { try { return JSON.parse(s); } catch { return null; } }
