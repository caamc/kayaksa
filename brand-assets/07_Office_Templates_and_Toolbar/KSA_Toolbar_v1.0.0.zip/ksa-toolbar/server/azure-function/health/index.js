/* health/index.js — GET /health: reports the model id and whether secrets are configured (never their values). */
import { DEFAULT_MODEL } from "../shared/config.js";
import { corsHeaders } from "../shared/assistant-core.js";

export default async function health(context, req) {
  const env = process.env;
  const cors = corsHeaders(req.headers?.origin || "", env.ALLOWED_ORIGINS);
  if (req.method === "OPTIONS") { context.res = { status: 204, headers: cors.headers, body: "" }; return; }
  context.res = {
    status: 200,
    headers: { "content-type": "application/json; charset=utf-8", "cache-control": "no-store", ...cors.headers },
    body: JSON.stringify({ ok: true, service: "ksa-assistant", model: env.MODEL || DEFAULT_MODEL, auth: !!env.ASSISTANT_TOKEN, keyConfigured: !!env.ANTHROPIC_API_KEY }),
  };
}
