# KSA Assistant proxy (Azure Function)

The same proxy as `../cloudflare-worker`, packaged as an Azure Functions app for teams that keep everything in Azure. Two HTTP functions, no npm dependencies, Node 18 or newer (global `fetch`). `shared/` holds verbatim copies of the Worker's `config.js`, `system-prompt.js` and `assistant-core.js`; change them in one place and copy across.

Routes (the `routePrefix` is empty in `host.json`, so there is no `/api`):

- `POST /chat` chat completion with actions
- `GET /health` model id and whether the secrets are configured

## Deploy

Prerequisites: Azure CLI, Azure Functions Core Tools v4, Node 18+.

```bash
cd server/azure-function

# 1. Resources (names are examples; pick your own region and names)
az group create -n ksa-tools -l centralindia
az storage account create -n ksaassistantstore -g ksa-tools -l centralindia --sku Standard_LRS
az functionapp create -n ksa-assistant -g ksa-tools -s ksaassistantstore \
   --consumption-plan-location centralindia --runtime node --runtime-version 20 --functions-version 4

# 2. Settings (the key is stored as an app setting; use Key Vault references if your policy requires it)
az functionapp config appsettings set -n ksa-assistant -g ksa-tools --settings \
   ANTHROPIC_API_KEY="sk-ant-..." ASSISTANT_TOKEN="<long random string>" MODEL="claude-sonnet-4-5" ALLOWED_ORIGINS="https://toolbar.kayaksa.com"

# 3. Publish
func azure functionapp publish ksa-assistant
```

Check `https://ksa-assistant.azurewebsites.net/health`, then put `https://ksa-assistant.azurewebsites.net` (no trailing `/chat`) into the add-in **Settings → Assistant endpoint**, and the token into **Assistant access token**.

## Run locally

```bash
cp local.settings.example.json local.settings.json   # then fill in ANTHROPIC_API_KEY
func start                                            # http://localhost:7071
```

Point the add-in at `http://localhost:7071` (Office task panes need HTTPS for the add-in itself, but the proxy call is an ordinary `fetch`, so a localhost HTTP proxy works during development on the desktop).

## Settings

| App setting | Purpose |
|---|---|
| `ANTHROPIC_API_KEY` | Required. Never returned to the add-in and never logged. |
| `ASSISTANT_TOKEN` | Optional. When set, requests must carry `Authorization: Bearer <token>`. |
| `MODEL` | Model id. Default comes from `shared/config.js` (`claude-sonnet-4-5`). |
| `ALLOWED_ORIGINS` | `*` or a comma-separated list of exact origins. Others get 403. |

`host.json` sets `routePrefix` to `""` so the paths match the Worker. If you prefer `/api/chat`, remove that line and put `https://<app>.azurewebsites.net/api` in the add-in Settings.

The functions use the Azure Functions Node.js v3 programming model (`function.json` next to `index.js`) with ES modules (`"type": "module"` in `package.json`), which the Functions 4.x runtime supports on Node 18+.
