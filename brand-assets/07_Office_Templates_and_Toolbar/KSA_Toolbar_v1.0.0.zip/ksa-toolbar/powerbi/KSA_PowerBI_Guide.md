# KSA Power BI theme and asset pack

Office add-ins do not run inside Power BI, so the KSA look is delivered there as a report theme, an icon pack and this layout guide. The target look is `report-layout.png` (1920 x 1080): logo top left, a row of KPI cards, one chart with a single Saffron highlight, a table with a Deep Current header.

## Files

| File | Purpose |
|---|---|
| `KSA_PowerBI_Theme.json` | Report theme: colours, text classes and `visualStyles` defaults for every visual |
| `icons/duotone/*.png` | The 48 KSA service icons, 256 px, Open Water and Beacon Saffron on transparent, for light backgrounds |
| `icons/line-white/*.png` | The same 48 icons as white line art, for Deep Current panels and buttons |
| `report-layout.png`, `report-layout.html` | The reference page and its source (render it again with `node powerbi/render-layout.js`) |

## 1. Import the theme

Power BI Desktop: **View > Themes > Browse for themes** and pick `KSA_PowerBI_Theme.json`. Every new visual then starts with the KSA defaults; existing visuals that were formatted by hand keep their manual settings (reset them with **Format > Reset to default**). To check the theme, open **View > Themes > Customize current theme**; the name reads "Kayak Strategic Advisors".

Fonts: Archivo is not a Power BI built-in font. On Desktop it renders when Archivo is installed on the PC (`assets/fonts/Archivo`), and the Power BI service renders it when the viewer has it installed, otherwise it falls back to Segoe UI, which has similar proportions. Keep Archivo in the theme; do not switch to a web-safe font only for the service.

What the theme sets:

- Data colours in the KSA categorical order: Open Water, Tidewater Blue, Kelp Green, Storm Slate, Estuary Sand, Dusk Plum, Shallows, then #9AAD5A. Series one is always Open Water.
- Sentiment: good Kelp Green, neutral Burnished Gold, bad Red Clay (KPI and waterfall visuals use them). Divergent scale: Spray, Fog, Deep Current.
- Text classes: titles Archivo 12 Deep Current, labels Archivo 10 Storm Slate, callouts Archivo 28 Deep Current, headers Archivo 12.
- `visualStyles."*"`: white backgrounds, no borders, no shadows, left-aligned titles, Fog 1 px gridlines on the value axis only, value axis starting at zero, legend at the top without a title, 2 px lines without markers.
- Cards: 28 pt values with a 3 px Open Water accent bar on the left; multi-row cards the same.
- Slicers: Fog outline, Archivo 10, no "Select all"; the new button slicer fills Open Water when selected.
- Table and matrix: Deep Current header with white text, Sea Mist banding, horizontal Fog grid only, totals in Sea Mist bold.
- Donut inner radius 82 % (an 18 % ring), waterfall in Kelp Green, Red Clay and Deep Current totals.
- Buttons: Open Water fill, Deep Lagoon on hover, 6 px corners.

Only one highlight per chart: the theme cannot know which bar to highlight, so set it by hand (**Format > Columns > Colours > fx** or a conditional measure that returns `"#EE9B1E"` for the chosen category and `"#17807E"` for the rest).

## 2. Page setup

- **Standard dashboard pages: 16:9**, 1920 x 1080 px (**Format page > Canvas settings > Type: Custom**, width 1920, height 1080). This is also the size of `report-layout.png`.
- **Printed or PDF reports: A4 landscape**, 1123 x 794 px at 96 dpi (or 1587 x 1123 for a sharper export). Keep the same 32 px margins so paginated pages match the deck.
- Canvas background white, wallpaper (the area outside the canvas) Sea Mist #EEF4F1; the theme sets both.

### Layout grid

- Outer margin 32 px on all four sides.
- 12-column grid inside the margins, 24 px gutters (on 1920 wide that is columns of 130 px).
- Row rhythm: header 72 px, gap 24, KPI row 150 px, gap 24, main row to the bottom margin.
- Visuals snap to the grid; no two visuals touch. Keep **View > Gridlines** and **Snap to grid** on with the 8 px default.

## 3. Report header pattern

Top left: `assets/logo/KSA_Logo_Full_FullColour.png` as an Image visual, 48 px high (the identifier alone, `KSA_Identifier_FullColour.png`, when space is tight). Next to it a text box with the report title in Archivo 26 semibold Deep Current and a one-line subtitle in Archivo 13 Storm Slate: client in square brackets until it is known, period, "Prepared by Kayak Strategic Advisors". Slicers for period, region and cluster sit at the right end of the header as single-select dropdowns or the button slicer. A 1 px Fog line (a Shape visual, line, Fog) closes the header. Footer: a text box in Archivo 11 Riverstone with "Kayak Strategic Advisors · Confidential · Prepared for [Client]" on the left and page number and refresh date on the right (`"Data refreshed " & FORMAT(MAX('Refresh'[Time]), "D MMM YYYY")` in a measure).

On dark title pages use `KSA_Logo_Full_Reversed.png` on Deep Current with the white line icons.

## 4. KPI card layout

Four cards in the KPI row, each three grid columns wide and 150 px high:

- Card visual (the new card) with the accent bar on the left in Open Water (set by the theme). Replace the accent with the cluster colour when a page belongs to one service cluster.
- Inside the card: a 44 px Sea Mist rounded square with the matching KSA icon (`icons/duotone`), then label (Archivo 13 Storm Slate), value (Archivo 40 semibold Deep Current), and a delta pill (Archivo 13 in Sea Mist: Kelp Green when good, Burnished Gold when flat, Red Clay when bad).
- One figure per card. Indian number grouping (`#,##,##0`) for INR values; say the unit in the label ("Revenue, INR crore"), never in the number.
- Six or more KPIs: use two rows rather than smaller cards.

## 5. Chart rules

- Primary series Open Water; one Beacon Saffron highlight per chart; context series Riverstone; benchmark or plan lines dashed Storm Slate 2 px.
- Gridlines Fog 1 px on the value axis only; zero baseline; no axis titles when the title says the unit.
- No pies, no 3D, no dual axes (a combo chart uses one value axis). Donut only for a part-of-whole with up to five slices.
- Bars sorted by value unless the categories have a natural order; data labels on when there are 12 or fewer bars.
- Title: what the chart shows plus the unit ("Revenue by business unit, INR crore"). Subtitle or a text box below the title with the message in one sentence. Source line in Riverstone 11 at the bottom of the visual.
- Chart margins: the visual's own padding 16 px, title left-aligned to the data, legend top.

## 6. Using the icons

- Image visual: **Insert > Image**, choose the PNG, lock aspect ratio, 24 to 48 px tall. Use `duotone` on white and Sea Mist, `line-white` on Deep Current.
- In cards and tables: load the icons into the model as a table with an `Icon URL` column pointing at the hosted add-in (`https://<base>/assets/icons/png/duotone/ksa-icon-strategy.png`), set the column's **Data category** to Image URL, and drop it into a table, matrix or the new card's image slot. Conditional icons (RAG arrows, cluster markers) work the same way with a measure returning the URL.
- Names follow the add-in: `ksa-icon-<name>.png`; the six cluster icons are strategy, regulatory, risk, technology, briefcase, globe.
- Power BI's built-in conditional icons (Format > Cell elements > Icons) are fine for RAG; set their colours to Kelp Green, Beacon Saffron and Red Clay.

## 7. A Power BI custom visual would be a separate project

A packaged visual (`.pbiviz`, built with `pbiviz` and the Power BI visuals SDK, TypeScript and D3) is the only way to ship a KSA-branded visual that users drag onto a page. It is not part of this add-in. If it is commissioned, it would contain:

- `pbiviz.json` with the KSA name, GUID, icon (`manifest/icons/icon-32.png` style) and support URL.
- `capabilities.json` describing data roles (category, value, highlight, benchmark) and the formatting cards (highlight category, benchmark value, label units, source line).
- `src/visual.ts`: a D3 render of the KSA column, bar and line exhibits with the rules above baked in (zero baseline, Fog gridlines, single Saffron highlight, dashed benchmark, Archivo), plus a KPI tile and the RAG scorecard table.
- Styles from `assets/library.json` colour tokens, the embedded Archivo font files and a theme-aware legend.
- Certification is optional; an uncertified visual installs from a file or the organisation's visuals store (**Power BI admin portal > Organisational visuals**).

Until then, the theme plus the layout rules get the standard visuals to roughly the same look, which is what `report-layout.png` demonstrates.
