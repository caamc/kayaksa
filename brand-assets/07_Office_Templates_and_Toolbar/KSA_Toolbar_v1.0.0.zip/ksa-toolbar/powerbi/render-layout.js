#!/usr/bin/env node
/* Renders powerbi/report-layout.html to powerbi/report-layout.png at 1920 x 1080 with Playwright (dev tool only). */
const path = require("path");
const { chromium } = require("playwright");
(async () => {
  const html = path.resolve(__dirname, "report-layout.html");
  const out = path.resolve(__dirname, "report-layout.png");
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1920, height: 1080 }, deviceScaleFactor: 1 });
  await page.goto("file://" + html);
  await page.evaluate(() => document.fonts.ready);
  await page.screenshot({ path: out, clip: { x: 0, y: 0, width: 1920, height: 1080 } });
  await browser.close();
  console.log("wrote", out);
})();
