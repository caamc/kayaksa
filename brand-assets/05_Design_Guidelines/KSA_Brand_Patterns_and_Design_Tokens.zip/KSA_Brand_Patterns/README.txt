KAYAK STRATEGIC ADVISORS · BRAND PATTERNS
Version 1.0 · from the KSA Design & Visual Guidelines, section 05 (pages 22-27)

WHAT IS IN THIS FOLDER
11 seamless patterns x 6 colourways. Each pattern folder holds, per colourway:
  KSA_Pattern_NN_Name_<colourway>_tile.svg        One seamless repeat as vector. Use as a pattern swatch in Illustrator, Figma, InDesign or CSS.
  KSA_Pattern_NN_Name_<colourway>_tile_1024.png   The same repeat as a 1024 px wide PNG, for tools that need a bitmap swatch.
  KSA_Pattern_NN_Name_<colourway>_1920x1080.svg   A full HD background at the default scale, as vector.
  KSA_Pattern_NN_Name_<colourway>_1920x1080.png   A full HD background for slides, video and web heroes.
  KSA_Pattern_NN_Name_<colourway>_3840x2160.png   A 4K background at twice the default scale, so it looks the same as HD on a 4K screen.

THE ELEVEN PATTERNS

  Family A · Geometric repeats
  01 Confluence        source: Identifier tile 120 x 84 units, default 50 px wide
     The identifier's two blades, repeated in a half-drop. Teal and saffron meet in every unit.
  02 Paddle rhythm     source: Identifier tile 96 x 52 units, default 35 px wide
     Left and right blades stack in a herringbone, held apart by the identifier's split. A kinetic supergraphic for covers and banners.
  03 Delta             source: Monogram   tile 268 x 216 units, default 54 px wide
     The A's trapezoid, upright and inverted, interlocks like a river delta. A structured texture for print and packaging.
  04 Monogram canvas   source: Monogram   tile 720 x 440 units, default 86 px wide
     The KSA monogram and the identifier in a heritage half-drop. Reserved for premium moments: gifting, events, packaging, lining papers.

  Family B · Line patterns
  05 Wake lines        source: Favicon    tile 48 x 90 units, default 67 px wide
     Hairlines on the blade angle, drawn from the favicon. The quietest pattern: backgrounds, overlays, UI surfaces.
  06 Chevron wake      source: Favicon    tile 32 x 8 units, default 48 px wide
     Two strokes converge but never touch, the split at the heart of the identifier. Ideal for section openers and bands.
  07 K-lattice         source: Wordmark   tile 40 x 64 units, default 30 px wide
     A lattice drawn on the angle of the K's arms (58°). Saffron nodes mark points of decision.
  08 Pinstripe         source: Identifier tile 96 x 8 units, default 96 px wide
     Stem and split as a tailored pinstripe: line, gap, line. Understated texture for letterheads, folders and slide margins.

  Family C · Atmospheric
  09 Current           source: Monogram   tile 160 x 48 units, default 144 px wide
     Flow lines traced from the monogram's S. Calm movement for large backgrounds and thought-leadership covers.
  10 Soundings         source: Chart      tile 48 x 41.57 units, default 41 px wide
     A field of soundings, like depth marks on a nautical chart. One beacon in each field. Works behind data and dashboards.
  11 Chart contours    source: Chart      tile 200 x 200 units, default 320 px wide
     Depth contours from a navigation chart, generated to repeat seamlessly. The signature backdrop for reports and keynotes.

COLOURWAYS AND STRENGTH
  brand-dark / brand-light    DISPLAY, 100%. Open Water and Beacon Saffron on Deep Current or Sea Mist. Covers, supergraphics, packaging, event walls.
  accent-dark / accent-light  ACCENT. Base shapes or lines at 10-22%, one saffron unit at 85-90%. Section openers, banners, social.
  tonal-dark / tonal-light    TONAL, 6-16%. One colour, tone on tone. Backgrounds behind UI, charts and type.

OPACITY RULES
  - Never place body text on a pattern stronger than 10%. Tonal fill patterns ship at 7-9%; for line patterns
    behind text, set the layer to about 60% (16% x 0.6 = 10%) or use a calmer pattern.
  - Behind UI and text, use line or atmospheric patterns at 6-16% (tonal files).
  - Display strength (brand-*) is for covers and supergraphics with large type only, never behind paragraphs.
  - Do not lower the opacity of a brand-* file to fake a tonal one: use the tonal file, it is tuned per pattern.

SCALE (tile width, min-max)
  Pattern             Print mm   Screen px @1x
  Confluence             10-30          40-120
  Paddle rhythm           8-24           32-96
  Delta                  12-40          48-160
  Monogram canvas        24-60          80-240
  Wake lines             10-24          48-120
  Chevron wake            6-16           36-96
  K-lattice               6-18           30-90
  Pinstripe              18-48          72-192
  Current               36-120         120-480
  Soundings              10-30          36-100
  Chart contours        60-200         240-960
  Hairlines never thinner than 0.1 mm in print or 0.5 px on screen. Scale uniformly: never stretch, rotate or skew.

COMBINING, CROPPING, MASKING
  - One pattern per spread, slide or screen.
  - Never let two patterns touch.
  - Never combine a pattern with a photograph.
  - Crop flat on the trim and bleed off at least one edge. No fades, vignettes or blurs.
  - Mask only with a blade from the identifier, at its own 62 degree angle. No circles or free shapes.
  - Never place the logo on a geometric repeat (family A); give it a solid panel.
  - Keep the colours as supplied. Do not recolour a pattern outside the six colourways.

COLOUR VALUES
  Deep Current #0E2F3C · Open Water #17807E · Beacon Saffron #EE9B1E · Sea Mist #EEF4F1 · Shallows #5DB2AB · Teal on dark #3FB0A9

Questions: the KSA brand team.
